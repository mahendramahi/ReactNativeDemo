//"react-native-camera": "^1.3.1",
import { AppRegistry, UIManager } from 'react-native';
import App from './src/App';
import bgMessaging from './src/firebase/bgMessaging';


// Enable LayoutAnimation for Android
UIManager.setLayoutAnimationEnabledExperimental &&
 UIManager.setLayoutAnimationEnabledExperimental(true);

AppRegistry.registerComponent('twcCoachNew', () => App);
// New task registration
AppRegistry.registerHeadlessTask('RNFirebaseBackgroundMessage', 
() => bgMessaging); 
