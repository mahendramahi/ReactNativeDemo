package com.wellnesscorner.coach.transloaditModule;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.transloadit.android.sdk.AndroidTransloadit;
import com.transloadit.sdk.async.AssemblyProgressListener;
import com.transloadit.sdk.exceptions.LocalOperationException;
import com.transloadit.sdk.exceptions.RequestException;
import com.transloadit.sdk.response.AssemblyResponse;
import com.transloadit.android.sdk.AndroidAsyncAssembly;
import org.json.JSONException;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;

/*
* @Mahendra Sharma on 7Feb2019
* */

public class TransloaditModule extends ReactContextBaseJavaModule {

    /// Key
    private static final String KEY_IMAGE_MEAL = "KEY_IMAGE_MEAL";
    private static final String KEY_IMAGE_PROFILE = "KEY_IMAGE_PROFILE";
    private static final String KEY_IMAGE_VIDEO_POST = "KEY_IMAGE_VIDEO_POST";
    private static final String KEY_TEAM_PROFILE_IMAGE = "KEY_TEAM_PROFILE_IMAGE";
    private static final String KEY_CHAT_MEDIA = "KEY_CHAT_MEDIA";

    /// values
    private static final String PATH_IMAGE_MEAL = "mealimages";
    private static final String PATH_IMAGE_PROFILE = "memberimages";
    private static final String PATH_IMAGE_VIDEO_POST = "socialpostfile";
    private static final String PATH_TEAM_PROFILE_IMAGE = "teamimages";
    private static final String PATH_CHAT_MEDIA = "chatmedia";


    public Context mContext;
    public Callback callback;
    public ReactApplicationContext reactContext;
    public AndroidTransloadit transloadit;
    public AndroidAsyncAssembly androidAsyncAssembly;
    public MyAssemblyProgressListener myAssemblyProgressListener;


    public TransloaditModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return "Transloadit";
    }

    @Nullable
    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<>();
        constants.put(KEY_IMAGE_MEAL, PATH_IMAGE_MEAL);
        constants.put(KEY_IMAGE_PROFILE, PATH_IMAGE_PROFILE);
        constants.put(KEY_IMAGE_VIDEO_POST, PATH_IMAGE_VIDEO_POST);
        constants.put(KEY_TEAM_PROFILE_IMAGE, PATH_TEAM_PROFILE_IMAGE);
        constants.put(KEY_CHAT_MEDIA, PATH_CHAT_MEDIA);
        return constants;
    }

    @ReactMethod
    public void submitAssembly(String transloaditKey, String transloaditSecrateKey, String uri, String filename, String extention,
                               String pathForServer, String templateid, Callback callback) {
        System.out.println(" Submit Assembly Called");
        this.callback = callback;
        AssemblyProgressListener listener = new MyAssemblyProgressListener();
        transloadit = new AndroidTransloadit(transloaditKey, transloaditSecrateKey);
        androidAsyncAssembly = transloadit.newAssembly(listener, getCurrentActivity());

        try {
            androidAsyncAssembly.addFile(getReactApplicationContext().getContentResolver().openInputStream(Uri.parse(uri)), "file");
            System.out.println(" Submit Assembly FileAdded");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            // showError(e);
            System.out.println(" File Not Found Exception==" + e.toString());
        }

        Map<String, Object> fields = new HashMap<>();

        androidAsyncAssembly.addOption("template_id", templateid);
        fields.put("filename", filename);
        fields.put("path", pathForServer);

        androidAsyncAssembly.addOption("fields", fields);
        System.out.println(" Submit Assembly Task Start");
        CreateAssemblyTask createAssemblyTask = new CreateAssemblyTask();
        createAssemblyTask.execute(true);
    }

    @SuppressLint("StaticFieldLeak")
    private class CreateAssemblyTask extends AsyncTask<Boolean, Void, AssemblyResponse> {

        @Override
        protected void onPostExecute(AssemblyResponse response) {
            if (response == null && myAssemblyProgressListener != null) {
                callback.invoke(response.json().toString(), null);
                //myAssemblyProgressListener.onUploadFailed(new Exception(""));
            }
            // activity.setStatus("Your androidAsyncAssembly is running on " + response.getUrl());
            // activity.setPauseButtonEnabled(true);
        }

        @Override
        protected void onCancelled(AssemblyResponse assemblyResponse) {
            super.onCancelled(assemblyResponse);
            myAssemblyProgressListener.onUploadFailed(new Exception(""));
            /*try {
                androidAsyncAssembly.pauseUpload();
            } catch (LocalOperationException e) {
                e.printStackTrace();
            }*/

        }

        @Override
        protected AssemblyResponse doInBackground(Boolean... params) {
            System.out.println(" Submit Assembly doInBg");
            try {
                return androidAsyncAssembly.save(true);
            } catch (LocalOperationException e) {
                // showError(e);
            } catch (RequestException e) {
                callback.invoke(e.toString(), null);
                e.printStackTrace();
                //  showError(e);
                // mListener.onUploadFailed(e);
            }

            return null;
        }
    }

    public class MyAssemblyProgressListener  implements AssemblyProgressListener {
        @Override
        public void onUploadFinished() {
            //callback.invoke("onUploadFinished", null);
            System.out.println("upload finished!!! waiting for execution ...");
        }

        @Override
        public void onUploadPogress(long uploadedBytes, long totalBytes) {
            System.out.println("uploaded: " + uploadedBytes + " of: " + totalBytes);
        }

        @Override
        public void onAssemblyFinished(AssemblyResponse response) {
            try {
                callback.invoke(null, response.json().toString());//.json());
                System.out.println("Assembly finished with status: " + response.json());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUploadFailed(Exception exception) {
            System.out.println("upload failed :(");
            callback.invoke(exception.toString(),null);
            exception.printStackTrace();
        }

        @Override
        public void onAssemblyStatusUpdateFailed(Exception exception) {
            System.out.println("unable to fetch status update :(");
            callback.invoke(exception.toString(),null);
            exception.printStackTrace();
        }
    }
}

//        Transloadit transloadit = new Transloadit(transloaditKey, transloaditSecrateKey);
//
//        Steps steps = new Steps();
//
//        Map<String, Object> stepOptions = new HashMap<>();
//        stepOptions.put("width", width);
//        stepOptions.put("height", height);
//        steps.addStep("resize", "/image/resize", stepOptions);
//
//        Map<String, Object> templateOptions = new HashMap<>();
//        templateOptions.put("steps", steps.toMap());
//        templateOptions.put("name", "MY_NEW_TEMPLATE_NAME");
//
//        try {
//            Response response = transloadit.updateTemplate("TEMPLATE_ID", templateOptions);
//
//        } catch (RequestException | LocalOperationException e) {
//            System.out.println("onAssembly error ==" + e.toString());
//        }
//    }

//}