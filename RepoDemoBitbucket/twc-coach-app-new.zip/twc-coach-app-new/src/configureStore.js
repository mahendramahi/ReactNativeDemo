import ReduxThunk from 'redux-thunk';
import { createStore, applyMiddleware, compose } from 'redux';
import applyAppStateListener from 'redux-enhancer-react-native-appstate';
import reducers from './reducers';
import firebase from 'react-native-firebase';

export const firebaseRN = () => {
        firebase.messaging().hasPermission().then((enable) => {
                if (enable) {
                        firebase.messaging().getToken().then((token) => {
                                console.log(token);
                                return token;
                        });
                } else {
                        firebase.messaging().requestPermission();   
                }
        }).catch((err) => {
                console.log(err);
        });
};

export const store = createStore(reducers, {}, compose(
        applyAppStateListener(),
        applyMiddleware(ReduxThunk)
        ));
