import axios from 'axios';
import { AsyncStorage, Platform } from 'react-native';
import { showToast } from './../components/Utility';
import { EXPIRED_ACCESS_TOKEN, IPADDRESS } from './../actions/types';
import { REFRESH_TOKEN } from './../constant/api';

export const responseHandler = (route, data, dispatch, actionType) => {
    return new Promise(async(resolve, reject) => {
        fetch(route, data).then(response => {
            response.json();
            const resBody = response._bodyText;
            const resStatus = response.status;
            dispatch({ type: actionType });
            const responseObj = JSON.parse(resBody);
            if (resStatus === 200) {
                resolve(responseObj);
            } else if (resStatus === 401) {
                reject('401 token Expire Error');
                showToast(EXPIRED_ACCESS_TOKEN);
            }
        }).catch(error => {
            dispatch({ type: actionType });
            if (error.toString().includes('401')) {
                reject('401 token Expire Error');
                showToast(EXPIRED_ACCESS_TOKEN);
            }
        });
    });
};

export const axiosWithoutDispatch = (route) => {
    console.log('request:- ' + JSON.stringify(route));
    return new Promise(async(resolve, reject) => {
        axios(route).then((res) => {
            console.log('response:- ' + JSON.stringify(res));
            resolve(res);
            }).catch(error => {
                if (error.toString().includes('401')) {
                    AsyncStorage.getItem('token').then(data => {
                        const requestBundle = {
                            token: data,
                            ipAddress: IPADDRESS,
                            devicePlatform: (Platform.OS === 'ios') ? 3 : 2,
                        };
                        const req = {
                            method: 'POST',
                            url: REFRESH_TOKEN,
                            data: requestBundle,
                            json: true
                        };
                        axios(req)
                        .then((reqResponse) => {
                            if (reqResponse.status === 200) {
                                const tokendata = reqResponse.data.data.token.value;
                                AsyncStorage.setItem('token', tokendata);
                                route.headers.Authorization = `Bearer ${tokendata}`;
                                //fetchData(requestData, url, dispatch, action);
                                axios(route).then((resAfterRefresh) => {
                                    console.log('responseAfter401:- ' + JSON.stringify(resAfterRefresh));
                                    resolve(resAfterRefresh);
                                }).catch((errorr) => {
                                    reject(errorr);
                                });
                            } else {
                                reject('');
                                showToast('Internal Server Error');
                            }
                        }).catch((er) => {
                            reject('');
                            showToast('Internal Server Error');
                        });
                    });
                } else {
                    reject(error);
                }
            });
        });
    };

            //     console.log(error);
            //     if (error.toString().includes('401')) {
            //         reject('401 token Expire Error');
            //     } else {
            //     reject(error);
            // }
         
