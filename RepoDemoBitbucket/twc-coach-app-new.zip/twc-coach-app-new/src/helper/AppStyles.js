//import Colors from './Colors';

// const AppStyles = {
//     fab: {
//         zIndex: 5,
//         position: 'absolute',
//         width: 50,
//         height: 50,
//         alignItems: 'center',
//         justifyContent: 'center',
//         right: 15,
//         bottom: 10, 
//         borderRadius: 30, 
//         elevation: 8 
//       },
//       fabImage: {
//         resizeMode: 'contain',
//         width: 50,
//         height: 50,
//       }
// };

import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  spinnerTextStyle: {
    color: '#FFF'
  },
});
