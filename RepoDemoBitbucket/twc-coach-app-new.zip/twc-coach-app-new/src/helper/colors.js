export const colors = {
    red: '#FF0000',
};
