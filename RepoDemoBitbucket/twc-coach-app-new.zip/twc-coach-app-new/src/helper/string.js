export const string = {
    //////// sensitive Data (Never Change)
    Bearer: 'Bearer ',
    METHOD_POST: 'POST',
    ///////

    log_url: 'URL:-----',
    log_RequestData: 'requestData:-----',
    log_Response: 'Response:-----',

};
