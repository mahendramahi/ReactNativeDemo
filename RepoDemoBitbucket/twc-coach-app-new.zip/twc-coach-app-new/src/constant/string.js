export const TRANSLOADIT_BASEURL = 'https://api2.transloadit.com/assemblies';
export const MEDIA_TYPE_IMAGE = 1;
export const MEDIA_TYPE_VIDEO = 2;
export const MEDIA_TYPE_PDF = 5;
export const FOLDER_TYPE_MEMBER_IMAGE = 1;
export const FOLDER_TYPE_COACH_IMAGE = 2;
export const FOLDER_TYPE_CIRCLE_IMAGE = 3;
export const FOLDER_TYPE_SOCIAL_POSTFILE = 4;
export const FOLDER_TYPE_CHAT_MEDIA = 17;

export const TRANSLOADIT_MEDIA_TYPE_IMAGE = 1;
export const TRANSLOADIT_MEDIA_TYPE_VIDEO = 3;

        // [Description("memberimages")]
        // MemberImages = 1,
        // [Description("memberimages")]
        // CoachImages = 2,
        // [Description("circleimages")]
        // CircleImages = 3,
        // [Description("socialpostfile")]
        // SocialPostFile = 4,
        // [Description("ArticleImages")]
        // ArticleImages = 5,
        // [Description("goalhabitimages")]
        // GoalHabitImages = 6,
        // [Description("SlideImages")]
        // SlideImages = 7,
        // [Description("WorkShopImages")]
        // ProgramImages = 8,
        // [Description("challengeimages")]
        // ChallengeImages = 9,
        // [Description("quizimages")]
        // QuizImages = 10,
        // [Description("healthdocuments")]
        // HealthDocuments = 11,
        // [Description("discussionimages")]
        // DiscussionImages = 12,
        // [Description("videos")]
        // Videos = 13,
        // [Description("VideoConverImages")]
        // VideoConverImages = 14,
        // [Description("pdf")]
        // pdf = 15,
        // [Description("teamimages")]
        // TeamImages = 16,
        // [Description("chatmedia")]
        // ChatMedia = 17,
        // [Description("partnerimages")]
        // PartnerImages = 18,
        // [Description("circlecategories")]
        // CircleCategoryImages = 19,
        // [Description("foodimages")]
        // FoodImages = 20,
        // [Description("mealimages")]
        // MealImages = 21,
        // [Description("programtaskmedia")]
        // pdfvideotask=22


export const HARDWARE_ACTIONS = 'hardwareBackPress';
export const TOKEN_REFRESH_PLATFORM_IOS = '3';
export const TOKEN_REFRESH_PLATFORM_ANDROID = '2';

export const NO_INTERNET_CONNECTED = 'NO INTERNET CONNECTED';

/// Post Related Toast
export const POST_CRAETED_MSG = 'Post Created Successfully.';

//  Error Messages
export const ASK_QUESTION_FOR_POLL = 'Please Ask any question.';
export const POLL_MANDATORY_OPTION = 'Please provide minimum required options.';

export const APP_DONT_HAVE_TOKEN = 'Session Expire. Please Login Again'; 

/// date Formates
export const DTAE_FORMATE_MMMM_DD_YYYY = 'MMMM, dd YYYY';

/// String Key Word 
export const KEY_TAKE_PHOTO = 'Take Photo';
export const KEY_CHOOSE_FROM_LIBRARY = 'Choose from Library';
