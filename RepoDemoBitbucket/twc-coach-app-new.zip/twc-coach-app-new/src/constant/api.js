import Config from 'react-native-config';


// 1.home Circle Api
export const HOME_CIRCLE_URL = `${Config.API_URL}coach/circles`;


// 2.Home Feed Api
export const HOME_FEED_URL = `${Config.API_URL}coach/posts`;


// Login APi 
export const LOGIN_URL = `${Config.API_URL}coach/login`;

///Token Refresh
export const REFRESH_TOKEN = `${Config.API_URL}refreshtoken`;

//// Base Image Url For Circle
export const IMAGE_BASE_URL_CIRCLE = `${Config.IMAGE_BASE_URL}circleimages/`;

/////  Post Hi-Fi update 
export const POST_HIFI_URL = `${Config.API_URL}post/high-five`;

/// Get Circle List for Create post
export const GET_CIRCLES = `${Config.API_URL}coach/circles`;


////file uploader
export const FILEUPLOADER_URL = `${Config.API_URL}value/UploadFileToServer`;
////////

/// create post
export const CREATE_POST = `${Config.API_URL}post/create`;

/// get Comments on post
export const POST_COMMENTS = `${Config.API_URL}post/comments`;

///get coach.profile
export const GET_COACH_PROFILE = `${Config.API_URL}coach/home/getcoachprofile`;

//// save Comment on post Screen
export const SAVE_COMMENT_ON_POST = `${Config.API_URL}post/save-comment`;

/// hifi on Comment post SCreen
export const HIFI_ON_COMMENT = `${Config.API_URL}social/comments/High-Five`;

/// get Notifications listStyle
export const GET_NOTIFICATIOS = `${Config.API_URL}notification`;

////TWC Circles CoachesList
export const GET_COACHES_LIST = `${Config.API_URL}Circle/Coaches`;

/////TWC circles Members listStyle
export const GET_MEMBERS_LIST = `${Config.API_URL}Circle/members`;

//// TWC Circle Post by id
export const GET_CIRCLE_POST_LIST = `${Config.API_URL}Circle/posts`;

/// TWC Post Poll Option ans 
export const UPDATE_POLL_ANSWER = `${Config.API_URL}poll/answer`;

// Read Mark to Notifications
export const NOTIFICATION_MARK_READ = `${Config.API_URL}notification/read`;

/// Hashtags List on Create post
export const GET_HASHTAGS_LIST = `${Config.API_URL}post/hashtags`;

//// Search hashTags from post 
export const SEARCH_HASHTAGS_BYPOST = `${Config.API_URL}SearchHashtag`;

///// Search User Tag from Post
export const SEARCH_USERNAME_BYPOST = `${Config.API_URL}post/create-post/tags`;

//// /post/high-five/members
export const GET_HIFI_MEMBER_LIST = `${Config.API_URL}post/high-five/members`;

////// socket URL
export const SOCKET_URL = Config.CHAT_SOCKET_URL;
