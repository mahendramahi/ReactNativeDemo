import { AsyncStorage } from 'react-native';
import { POST_COMMENTS, SAVE_COMMENT_ON_POST,
    HIFI_ON_COMMENT, GET_CIRCLE_POST_LIST } from './../constant/api';
import { axiosWithoutDispatch } from './../helper/ApiHandler';
import { COMMENTLIST_LOADING, COMMENTLIST_LOADED,
     NEW_COMMENT_ADDED, NEW_COMMENT_ADDED_REPLY, LOAD_CHNAGES,
     PREVIOUS_COMMENT, ADD_HIFI_ON_COMMENT_UPDATE,
     ADD_HIFI_ON_COMMENT, UPDATE_COMMENT_COUNT, GET_POST_DETAIL,
     REMOVE_POST_DETAIL, ADDED_REPLY_UPDATE } from './../actions/types';

export const getCommentsData = (argPageNo, argPageSize, argPostId, argScrollView) => {
    const requestForPostComment = {
        PageIndex: argPageNo,
        PageSize: argPageSize,
        Id: argPostId
    };
    return dispatch => {
        dispatch({ type: COMMENTLIST_LOADING }); 
        if (argPageNo === 0) {
            callApi(
                requestForPostComment,
                POST_COMMENTS, dispatch,
                COMMENTLIST_LOADED, argScrollView
            );
        } else {
            callApi(
                requestForPostComment,
                POST_COMMENTS, dispatch,
                PREVIOUS_COMMENT, null
            );
        }
    };
};

export const getPostDetail = (notificationData) => dispatch => {
    dispatch({ type: COMMENTLIST_LOADING });
    const request = {
        PageIndex: 1,
        PageSize: 10,
        PostContentTypeId: notificationData.type,
        PostIdentity: notificationData.identity,
        Id: notificationData.circleIdentity,
    };
    getDetail(
        request,
        GET_CIRCLE_POST_LIST,
        dispatch,
        GET_POST_DETAIL
    );
};

export const UpdateCommentCount = (post) => dispatch => {
    dispatch({ type: UPDATE_COMMENT_COUNT, payload: post });
};

export const addHifiOnComment = (argCommentId, argScrollView, updateBody) => dispatch => {
    dispatch({ type: ADD_HIFI_ON_COMMENT_UPDATE, payload: updateBody });
    const request = {
        Id: argCommentId
    };
        callApi(
            request,
            HIFI_ON_COMMENT,
            dispatch,
            ADD_HIFI_ON_COMMENT, argScrollView
        );
};

export const clearCommentList = () => dispatch => {
    dispatch({ type: 'clearCommentList' });
};


export const saveComment = (argComment, argCommentId, argId, argScrollView,
    argTagTypeArray) => dispatch => {
    dispatch({ type: COMMENTLIST_LOADING });
    let isHasTagsStatus = false;
    let commentForSend = argComment;
    if (argTagTypeArray && argTagTypeArray.length > 0) {
        isHasTagsStatus = true;
        const lol = argTagTypeArray.map(async(item) => {
            const temptext = `@${item.TagName}`;
            if (commentForSend.includes(temptext)) {
                commentForSend = commentForSend.replace(`@${item.TagName}`, `{{${item.TagIndex}}}`);
                return true;
            }
        });
    }
    const requestAddComment = {
        Comments: commentForSend,
        commentId: (argCommentId === null) ? '' : argCommentId,
        Id: argId,
        isReply: false,
        isHasTags: isHasTagsStatus,
        tagTypeValue: argTagTypeArray,
    };
    if (argCommentId === null) {
        callApi(
            requestAddComment,
            SAVE_COMMENT_ON_POST,
            dispatch,
            NEW_COMMENT_ADDED, argScrollView
        );   
    } else {
        callApiForReply(
            requestAddComment,
            SAVE_COMMENT_ON_POST,
            dispatch,
            NEW_COMMENT_ADDED_REPLY, argScrollView, argCommentId
        );   
    }
};


export const saveCommentReply = (argComment, argReply, argId, argScrollView,
    argTagTypeArray) => dispatch => {
    dispatch({ type: COMMENTLIST_LOADING }); 

    let isHasTagsStatus = false;
    let commentForSend = argComment;
    if (argTagTypeArray && argTagTypeArray.length > 0) {
        isHasTagsStatus = true;
        const lol = argTagTypeArray.map(async(item) => {
            const temptext = `@${item.TagName}`;
            if (commentForSend.includes(temptext)) {
                commentForSend = commentForSend.replace(`@${item.TagName}`, `{{${item.TagIndex}}}`);
                return true;
            }
        });
    }

    const requestAddComment = {
        Comments: commentForSend,
        commentId: argReply.CommentIdentity,
        Id: argId,
        isReply: true,
        isHasTags: isHasTagsStatus,
        tagTypeValue: argTagTypeArray,
    };
        callApiForReply(
            requestAddComment,
            SAVE_COMMENT_ON_POST,
            dispatch,
            NEW_COMMENT_ADDED_REPLY, argScrollView, argReply
        );   
};

const callApi = (request, url, dispatch, action, argScrollView) => {
    AsyncStorage.getItem('token').then(data => {
          const route = {
              method: 'POST',
              url,
              data: request,
              headers: {
                  Authorization: 'Bearer ' + data
              },
              json: true
          };
         axiosWithoutDispatch(route)
         .then((response) => {
             if (response.status === 200) {
              if (action === NEW_COMMENT_ADDED) {
                    dispatch({ type: action, payload: [response.data.data.comment] });
               } else {
                dispatch({ type: action, payload: response.data.data });
               }
            //    else if (action === ADD_HIFI_ON_COMMENT) {
            //             const update = {
            //                 argCommentId: request.Id,
            //                 data: response.data.data
            //             };
            //           dispatch({ type: action, payload: response.data.data });
            //       }
             } else {
              //dispatch({ type: action, payload: [] });
             }
         })
         .catch((error) => {
          dispatch({ type: action, payload: [] });
          console.log('commentsError:-' + JSON.stringify(error));
         });
      });
  };

  
const callApiForReply = (request, url, dispatch, action, argScrollView, argreply) => {
    AsyncStorage.getItem('token').then(data => {
          const route = {
              method: 'POST',
              url,
              data: request,
              headers: {
                  Authorization: `Bearer ${data}`
              },
              json: true
          };
         axiosWithoutDispatch(route)
         .then((response) => {
             if (response.status === 200) {
              if (action === NEW_COMMENT_ADDED_REPLY) {
                const updateBody = argreply.comment;
                updateBody.subComment.push(response.data.data.comment);
                dispatch({ type: ADDED_REPLY_UPDATE, payload: updateBody });
               }
             }
         })
         .catch((error) => {
          dispatch({ type: action, payload: [] });
          console.log('commentsError:-' + JSON.stringify(error));
         });
      });
  };

export const removePostDetailObj = () => dispatch => {
    dispatch({ type: REMOVE_POST_DETAIL });
};

const getDetail = (request, url, dispatch, action) => {
      AsyncStorage.getItem('token').then(data => {
            const route = {
                method: 'POST',
                url,
                data: request,
                headers: {
                    Authorization: 'Bearer ' + data
                },
                json: true
            };
           axiosWithoutDispatch(route)
           .then((response) => {
               if (response.status === 200) {
                dispatch({ type: action, payload: response.data.data });
               } else {
                dispatch({ type: action, payload: {} });                   
               }
           }).catch((error) => {
            dispatch({ type: action, payload: [] });
            //console.log('commentsError:-' + JSON.stringify(error));
           });
        });
    };
