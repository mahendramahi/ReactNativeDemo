export const LOGIN_INPUT_CHANGED = 'login_input_changed';
export const LOGIN_SUCCESS = 'login_success';
export const LOGIN_FAIL = 'login_fail';
export const LOGIN_INITIATED = 'login_initiated';

export const HOME_LOADING = 'home_loading';
export const HOME_LOADING_CLEAR = 'home_loading_clear';
export const FEED_LOADING = 'feed_loading';
export const FEED_LOADING_START = 'feed_loading_start';
export const FEED_LOADING_CLEAR = 'feed_loading_clear';
export const FEED_LOADING_ERROR = 'feed_loading_error';
export const FEED_POLL_UPDATE = 'feed_poll_update';
export const FEED_BLANK = 'feed_blank';

export const LOGOUT = 'logout';
export const LOGOUT_INITIATED = 'logout_initiated';

/// PostType
export const HIFI_UPDATE = 'hifi_update';
export const HIFI_ID = 'hifi_ID';
export const HIFI_UPDATE_FEED = 'hifi_update_feed';

//Create Post constants
export const POST_UPLOADING = 'post_uploading';
export const POST_UPLOADED = 'post_uploaded';

///api error types
export const EXPIRED_ACCESS_TOKEN = 'expired access token '; 
export const IPADDRESS = '192.168.1.80';

///CommentList Api
export const COMMENTLIST_LOADING = 'comment_loading';
export const COMMENTLIST_LOADED = 'comment_loaded';
export const NEW_COMMENT_ADDED = 'new_comment_add';
export const NEW_COMMENT_ADDED_REPLY = 'new_comment_add_reply';
export const ADDED_REPLY_UPDATE = 'add_reply_update';
export const LOAD_CHNAGES = 'load_changes';
export const ADD_HIFI_ON_COMMENT = 'add_hifi_comment';
export const ADD_HIFI_ON_COMMENT_UPDATE = 'add_hifi_comment_update';
export const PREVIOUS_COMMENT = 'previous_comment';
export const UPDATE_COMMENT_COUNT = 'update_comment_count';
export const GET_POST_DETAIL = 'get_post_details';
export const REMOVE_POST_DETAIL = 'remove_post_details';
 
///Notifcations Api
export const NOTIFICATION_LOADING = 'notification_loading'; //otification
export const NOTIFICATION_LOADED = 'notification_loaded';
export const NOTIFICATION_LOAD_PAGEING = 'notification_load_pageing';
export const NOTIFICATION_CLEAR = 'notification_clear';
export const NOTIFICATION_READ_ACTION = 'notification_read_action';

///// TWC Circle CoachesList
export const COACHES_LIST_LOADING = 'coaches_list_loading'; //oaches
export const COACHES_LIST_LOADED = 'coaches_list_loaded'; //oaches
export const CIRCLE_COACH_CLEAR = 'circle_coach_clear';

export const TOTAL_MEMBER_COUNT = 'total_member_count';
///// TWC Circle MembersList
export const MEMBERS_LIST_LOADING = 'members_list_loading'; //oaches
export const MEMBERS_LIST_REMOVE_LOADING = 'members_list_remove_loading'; //oaches
export const MEMBERS_LIST_LOADED = 'members_list_loaded'; //oaches
export const MEMBERS_LIST_LOADMORE_LOADED = 'members_list_loadmore_loaded';
export const CIRCLE_MEMBER_CLEAR = 'circle_member_clear';

///// TWC Circle MembersList
export const POST_LIST_LOADING = 'post_list_loading'; //
export const POST_LIST_LOADED = 'post_list_loaded'; //
export const POST_PAGING_LOADING = 'post_paging_loading';
export const POST_PAGING_LOADED = 'post_paging_loaded';
export const CIRCLE_HOME_CLEAR = 'circle_home_clear';

///// TWC HashTags Key Event
export const HASHTAG_POST_LOADING = 'hashtag_post_loading';
export const HASHTAG_POST_LOADED = 'hashtag_post_loaded';
export const HASHTAG_POST_CLEAR = 'hashtag_post_clear';

export const HASHTAG_CIRCLE_LOADING = 'hashtag_circle_loading';
export const HASHTAG_CIRCLE_LOADED = 'hashtag_circle_loaded';

/// hifi member List Data 
export const HIFI_MEMBER_LIST_LOADING = 'hifi_member_list_loading';
export const HIFI_MEMBER_LIST_LOADED = 'hifi_member_list_loaded';

/// selectCircles List Tag
export const MYCIRCLE_LIST_LOADED = 'mycircle_list_loaded';
export const MYCIRCLE_LIST_UPDATE = 'mycircle_list_update';

//// Socket Action or reducer type 
export const SOCKET_CONNECTED = 'socket_connected';
export const SOCKET_DISCONNECTED = 'socket_disconnected';
export const SOCKET_CONNECT = 'socket_connect';
export const SOCKET_DISCONNECT = 'socket_disconnect';
export const SOCKET_CONNECTING = 'socket_connecting';
export const SOCKET_CONNECTING_ERROR = 'socket_connecting_error';
export const SOCKET_UNREAD_COUNT = 'socket_unread_count';
export const SOCKET_CHAT_LIST = 'socket_chat_list';
export const SOCKET_IS_COACH = 'COACH';
export const IS_COACH = true;
export const IS_MEMBER = true;
export const USER_MESSAGE_HISTORY_LOADED = 'user_mesagges_history_loaded';
export const SOCKET_CLIENT_RECEIVER_DETAIL = 'soket_client_receiver_detail';
export const SOKET_CLIENT_USER_ONLINE = 'socket_client_user_online';
export const SOCKET_USER_ISTYPING = 'socket_user_istyping';
export const SOCKET_NEW_MESSAGE = 'socket_new_message';
export const SOCKET_SEND_NEW_MESSAGE = 'socket_send_new_message';
export const SOCKET_CHAT_DELIVER = 'socket_chat_deliver';
export const SOCKET_DELETE_USER_MEDIA_MSG = 'socket_delete_user_media_msg';


////socket Emmiter and Listner
export const EMIT_SERVER_USER_ONLINE = 'server_user_online';
export const CLIENT_USER_ONLINE = 'client_user_online';

export const CONNECT_ERROR = 'connect_error';

export const EMIT_SERVER_GET_UNREADCHATCOUNT = 'server_get_unreadchatcount';
export const CLIENT_BIND_UNREADCHATCOUNT = 'client_bind_unreadchatcount';

export const EMIT_SERVER_GET_CHAT_LIST = 'server_get_chat_list';
export const CLIENT_BIND_CHAT_LIST = 'client_bind_chat_list';

export const EMIT_SERVER_INIT_RECEIVER = 'server_init_receiver';

export const CLIENT_INIT_CHAT = 'client_init_chat';

export const CLIENT_MESSAGES = 'client_messages';
export const EMIT_SERVER_INIT_CHAT = 'server_init_chat';

export const CLIENT_SET_CHAT = 'client_set_chat';
export const EMIT_SERVER_GET_CHAT = 'server_get_chat';
export const CLIENT_DISCONNECT_CHAT_SESSION = 'client_disconnect_chat_session';

//chat window

export const EMIT_SERVER_GET_RECEIVER_DETAILS = 'server_get_receiver_details';
export const CLIENT_RECEIVER_DETAIL_LISTENER = 'client_receiver_details';

export const CLIENT_MESSAGE_HISTORY = 'client_messages_history';
export const EMIT_SERVER_MESSAGE_HISTORY = 'server_message_history';

export const EMIT_LOAD_HISTORY = 'load_history';

export const EMIT_SERVER_CHAT_DELIVER = 'server_chat_deliver';
export const CLIENT_CHAT_DELIVER = 'client_chat_deliver';

export const CLIENT_CHAT_TYPING = 'client_chat_typing';
export const SERVER_CHAT_TYPING = 'server_chat_typing';

export const SERVER_SEND = 'server_send';

/// Type to Clear Chat List Item
export const CLEAR_CHAT_MSG = 'clear_chat_MSG';
