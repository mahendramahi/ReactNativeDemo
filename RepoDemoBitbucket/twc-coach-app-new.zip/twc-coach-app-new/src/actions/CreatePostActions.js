import { AsyncStorage } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { MEDIA_TYPE_IMAGE, FOLDER_TYPE_SOCIAL_POSTFILE,
     POST_CRAETED_MSG } from '../constant/string';
import { FILEUPLOADER_URL, CREATE_POST, GET_HASHTAGS_LIST } from '../constant/api';
import { POST_UPLOADING, POST_UPLOADED } from './types';
import { showToast } from './../components/Utility';
import { axiosWithoutDispatch } from './../helper/ApiHandler';

let onActionBack = null;

export const onActionAssigne = (func) => dispatch => {
    onActionBack = func;
};

export const showProgressBar = () => dispatch => {
    dispatch({ type: POST_UPLOADING });
};

export const stopProgressBar = () => dispatch => {
    dispatch({ type: 'progressStop' });
};

export const newMediaUploadHandler = (media, postText,
    circlesIds, mediaType, argTagValue, argTagTypeValue) => dispatch => {
    const postMedia = [{
        Data: media.fileName,
        Desc: '',
        Height: media.fileHeight,
        MediaType: mediaType,
        Title: '',
        Width: media.fileWidth
    }];
    submitPostRequest(postMedia, postText, circlesIds, argTagValue, argTagTypeValue, dispatch);
};

export const mediaUpload = (media, base64, postText, circlesIds) => {
    const ext = media.fileName.split('.');
    const mediaData = new FormData();
    mediaData.append('MediaType', MEDIA_TYPE_IMAGE);
    mediaData.append('FolderType', FOLDER_TYPE_SOCIAL_POSTFILE);
    mediaData.append('Data', base64);
    mediaData.append('FileName', media.fileName);
    mediaData.append('Extension', `.${ext[1]}`);

    return dispatch => {
        dispatch({ type: POST_UPLOADING });
        AsyncStorage.getItem('token').then(data => {
            const url = FILEUPLOADER_URL;
            const request = {
                method: 'POST',
                url,
                data: mediaData,
                headers: {
                    Authorization: `Bearer ${data}`
                },
                json: true
            };
            axiosWithoutDispatch(request)
            .then((uploaderResponse) => {
                if (uploaderResponse.data != null && uploaderResponse.data.data[0] !== '') {
                            const uploadedFileName = uploaderResponse.data.data[0];
                            const { fileHeight, fileWidth } = media;
        
                            const postMedia = [{
                                Data: uploadedFileName,
                                Desc: '',
                                Height: fileHeight,
                                MediaType: 1,
                                Title: '',
                                Width: fileWidth
                            }];
                           // submitPostRequest(postMedia, postText, circlesIds, dispatch);
                        } else {
                            dispatch({ type: 'progressStop' });
                            showToast(uploaderResponse.error.message);
                        }
            }).catch(error => {
                console.log(error);
            });
            // fetch(FILEUPLOADER_URL, request).then(response => {
            //     console.log('FileUpload Transloadit ==' + FILEUPLOADER_URL + '==' + JSON.stringify(response));
            //     const uploaderResponse = JSON.parse(response._bodyText);
            //     if (uploaderResponse.data != null && uploaderResponse.data[0] !== '') {
            //         const uploadedFileName = uploaderResponse.data[0];
            //         const { fileHeight, fileWidth } = media;

            //         const postMedia = [{
            //             Data: uploadedFileName,
            //             Desc: '',
            //             Height: fileHeight,
            //             MediaType: 1,
            //             Title: '',
            //             Width: fileWidth
            //         }];
            //         submitPostRequest(postMedia, postText, circlesIds, dispatch);
            //     } else {
            //         dispatch({ type: 'progressStop' });
            //         showToast(uploaderResponse.error.message);
            //     }
            // }).catch(error => {
            //     console.log(request);
            //     console.log(error);
            // });
        });
    };
};

export const submitUrlMediaPost = (postMedia, postText, circlesIds,
    argTagValues, argTagTypeValue) => dispatch => {
        dispatch({ type: POST_UPLOADING });
        submitPostRequest(postMedia, postText, circlesIds, argTagValues, argTagTypeValue, dispatch);
};

export const submitPollPost = (contentData, circlesIds) => {
   
    return dispatch => {
        dispatch({ type: POST_UPLOADING });
        const requestData = {
            ContentData: contentData,
            ContentTypeId: 5,
            IsHasMedia: false,
            IsHasTags: false,
            PostFor: 2,
            Id: circlesIds,
        };
        submitPost(requestData, dispatch, POST_UPLOADED);
    };
};

const submitPostRequest = (postMedia, postText, circlesIds, argHashTagValues,
    argTagTypeValue, dispatch) => {
        let textForPost = postText;
        let valIsHasTags = false;
        if (argTagTypeValue.length > 0) {
            valIsHasTags = true;
            const lol = argTagTypeValue.map(async(item) => {
                const temptext = `@${item.TagName}`;
                if (textForPost.includes(temptext)) {
                    textForPost = textForPost.replace(`@${item.TagName}`, `{{${item.TagIndex}}}`);
                    return true;
                }
            });
        }
    const requestData = {
        IsHasMedia: true,
        IsHasTags: valIsHasTags,
        MediaTypeValue: postMedia,
        PostFor: 2,
        PostText: textForPost,
        TagTypeValue: argTagTypeValue,
        hashTagValue: argHashTagValues,
        Id: circlesIds,
    };
    submitPost(requestData, dispatch, POST_UPLOADED);
};

export const submitPostWithoutMedia = (postText, circlesIds,
    argHashTagValue, argTagTypeValue) => dispatch => {
    dispatch({ type: POST_UPLOADING });
    let textForPost = postText;
    let valIsHasTags = false;
    if (argTagTypeValue.length > 0) {
        valIsHasTags = true;
        const lol = argTagTypeValue.map(async(item) => {
            const temptext = `@${item.TagName}`;
            if (textForPost.includes(temptext)) {
                textForPost = textForPost.replace(`@${item.TagName}`, `{{${item.TagIndex}}}`);
                return true;
            }
        });
    }
    const requestData = {
        IsHasMedia: false,
        IsHasTags: valIsHasTags,
        MediaTypeValue: [],
        PostFor: 2,
        PostText: textForPost,
        TagTypeValue: argTagTypeValue,
        hashTagValue: argHashTagValue,
        Id: circlesIds,
    };
        submitPost(requestData, dispatch, POST_UPLOADED);
};

const submitPost = (requestData, dispatch, action) => {
    console.log('data===' + JSON.stringify(requestData));
    AsyncStorage.getItem('token').then(data => {
        const url = CREATE_POST;
        const authOptions = {
            method: 'POST',
            url,
            data: requestData,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
        axiosWithoutDispatch(authOptions)
        .then((response) => {
            dispatch({ type: action });
            showToast(POST_CRAETED_MSG);
            onActionBack(true);
            Actions.pop({ refresh: true });
        }).catch((error) => {
            dispatch({ type: action });
            if (error.toString().includes('401')) {
                showToast('401 token Expire Error');
            } else {
            console.log(error);
        }
        });
        // responseHandler(CREATE_POST, request, dispatch, action).then((res) => {
        //     showToast(POST_CRAETED_MSG);
        //     Actions.pop({ refresh: true });
        // }).catch(error => {
        //     if (error.toString().includes('401')) {
        //     }
        // });
    });
};
