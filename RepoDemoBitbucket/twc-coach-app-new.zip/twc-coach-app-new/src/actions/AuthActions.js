import bcrypt from 'react-native-bcrypt';
import isaac from 'isaac';
import DeviceInfo from 'react-native-device-info';
import axios from 'axios';
import firebase from 'react-native-firebase';
import { Actions } from 'react-native-router-flux';
import { AsyncStorage, Platform } from 'react-native';
import { LOGIN_INPUT_CHANGED, LOGIN_SUCCESS, LOGIN_FAIL, LOGIN_INITIATED } from './types';
import { LOGIN_URL } from '../constant/api';
import { setAsyncStorage } from './../components/Utility';
import { CreateSocketConnectionDispatch } from './SocketAction';

export const loginInputChanged = ({ prop, value }) => {
    return ({
        type: LOGIN_INPUT_CHANGED,
        payload: { prop, value }
    });
};

export const showProgress = () => dispatch => {
    dispatch({ type: LOGIN_INITIATED });
};

export const loginUser = ({ email, password, token, ip }) => dispatch => {
    bcrypt.setRandomFallback((len) => {
        const buf = new Uint8Array(len);
        return Object.keys(buf).map(() => Math.floor(isaac.random() * 256));
    });
    const salt = '$2b$10$D31OvpfY4hGdALJj6eT0iu';
    const passwordHash = bcrypt.hashSync(password, salt);

    const loginObj = {
        Email: email,
        Password: passwordHash,
        MobileInfo: {
            DeviceId: DeviceInfo.getUniqueID(),
            DevicePlatform: (Platform.OS === 'ios') ? 3 : 2,
            RegToken: token,
            UsingVersion: DeviceInfo.getVersion(),
            IPAddress: ip
        }
    };
    const url = LOGIN_URL;
    //login email - coach.test@mailinator.com, password - 123456
    console.log('LoginObject === ', loginObj);
    console.log(LOGIN_URL);
   // return (dispatch) => {
        axios.post(url, loginObj)
            .then(response => {
                console.log('LoginResponse ==' + JSON.stringify(response));
                const { data } = response.data;
                const userData = {
                    token: data.token.value,
                    fcmToken: token,
                    UserImage: data.image,
                    UserScreenName: data.screenName,
                    UserEmail: data.email,
                    UserFirstName: data.firstName,
                    UserLastName: data.lastName,
                    UserIdentityId: data.identityId,
                };
                AsyncStorage.setItem('userData', JSON.stringify(userData))
                .then(() => {
                    dispatch({ type: LOGIN_SUCCESS });
                    try {
                    firebase.crashlytics().setUserIdentifier(data.email);
                    } catch (error) {
                        console.log(error);
                    }
                    setAsyncStorage('token', data.token.value);
                    setAsyncStorage('UserImage', data.image);
                    setAsyncStorage('UserScreenName', data.screenName);
                    setAsyncStorage('UserEmail', data.email);
                    setAsyncStorage('UserFirstName', data.firstName);
                    setAsyncStorage('UserLastName', data.lastName);
                    setAsyncStorage('UserIdentityId', data.identityId);
                    
                    CreateSocketConnectionDispatch(dispatch);
                    Actions.main(); 
                });
            })
            .catch(response => {
                console.log('Respose :---' + response);
                dispatch({ type: LOGIN_FAIL });
            });
       // };
    };
