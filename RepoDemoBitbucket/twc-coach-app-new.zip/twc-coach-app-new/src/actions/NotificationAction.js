
import { AsyncStorage } from 'react-native';
import { GET_NOTIFICATIOS, NOTIFICATION_MARK_READ, GET_CIRCLE_POST_LIST } from './../constant/api';
import { axiosWithoutDispatch } from './../helper/ApiHandler';
import { NOTIFICATION_LOADING, NOTIFICATION_LOADED,
   NOTIFICATION_LOAD_PAGEING, NOTIFICATION_CLEAR, NOTIFICATION_READ_ACTION,
   GET_POST_DETAIL } from './../actions/types';
import { Actions } from 'react-native-router-flux';

export const getNotificatios = (argPageNo, argPageSize) => {
   const event = argPageNo === 1 ? NOTIFICATION_LOADED : NOTIFICATION_LOAD_PAGEING;
   const request = {
      PageIndex: argPageNo,
      PageSize: argPageSize
   };
   return dispatch => {
      if (event !== NOTIFICATION_LOAD_PAGEING) {
      dispatch({ type: NOTIFICATION_LOADING });
      }
      fetchApi(
         request, GET_NOTIFICATIOS,
         dispatch, event
      );
   };
};

export const clearNotification = () => dispatch => {
   dispatch({ type: NOTIFICATION_CLEAR });
};

export const actionPerformAfterClickItem = (notificationItem) => dispatch => {
   const request = {
      Identity: notificationItem.identity,
      Type: notificationItem.type
   };
   fetchApi(
      request, NOTIFICATION_MARK_READ,
      dispatch, NOTIFICATION_READ_ACTION
   );
};

export const getPostDetailsById = (notificationData) => dispatch => {
   dispatch({ type: NOTIFICATION_LOADING });
   const request = {
       PageIndex: 1,
       PageSize: 10,
       PostContentTypeId: notificationData.type,
       PostIdentity: notificationData.identity,
       Id: notificationData.circleIdentity,
   };
   fetchApi(
       request,
       GET_CIRCLE_POST_LIST,
       dispatch,
       GET_POST_DETAIL, notificationData
   );
};

const fetchApi = (request, url, dispatch, action, notificationItem) => {
   AsyncStorage.getItem('token').then(data => {
         const route = {
             method: 'POST',
             url,
             data: request,
             headers: {
                 Authorization: 'Bearer ' + data
             },
             json: true
         };

        axiosWithoutDispatch(route)
        .then((response) => {
         dispatch({ type: 'hideLoading' });  
           //console.log('Notification Res' + JSON.stringify(response));
           if (response.status === 200 && action === GET_POST_DETAIL) {
            Actions.postDetail({ postData: response.data.data[0], notificationData: notificationItem, callbackFunction: null });
            } else if (response.status === 200 && action !== NOTIFICATION_READ_ACTION) {
               dispatch({ type: action, payload: response.data.data });
            } else {
             dispatch({ type: action, payload: [] });
            }
        })
        .catch((error) => {
         dispatch({ type: action, payload: [] });
        });
     });
 };

