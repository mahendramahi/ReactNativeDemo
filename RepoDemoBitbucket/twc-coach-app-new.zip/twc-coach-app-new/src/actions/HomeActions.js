import { AsyncStorage, Platform } from 'react-native';
import Toast from 'react-native-simple-toast';
import { Actions } from 'react-native-router-flux';
import { HOME_LOADING, FEED_LOADING, FEED_LOADING_START,
    HIFI_UPDATE_FEED, EXPIRED_ACCESS_TOKEN, IPADDRESS,
    FEED_POLL_UPDATE, FEED_BLANK, HOME_LOADING_CLEAR, FEED_LOADING_CLEAR } from './types';
import { HOME_FEED_URL, HOME_CIRCLE_URL, REFRESH_TOKEN,
    UPDATE_POLL_ANSWER } from '../constant/api';
import { axiosWithoutDispatch } from './../helper/ApiHandler';
import { showToast } from '../components/Utility';

export const loadHome = () => {
    const requestData = {
        PageIndex: 1,
        SearchTerm: '',
        SortBy: 'circle'
    };
    return dispatch => {
        fetchData(
            requestData, 
            HOME_CIRCLE_URL,
            dispatch,
            HOME_LOADING 
        );
    };
};

export const clearHomePage = () => dispatch => {
dispatch({ type: HOME_LOADING_CLEAR });
dispatch({ type: FEED_LOADING_CLEAR });
};

export const getFeed = (pageForFeed) => dispatch => {
    const event = pageForFeed === 1 ? FEED_LOADING_START : FEED_LOADING;
    if (pageForFeed === 1) {
        dispatch({ type: FEED_BLANK });
    }
    const requestData = {
        PageIndex: pageForFeed,
    };
    //return dispatch => {
        fetchData(
            requestData,
            HOME_FEED_URL,
            dispatch,
            event
        );
    //};
};

export const updateHifiFeed = (post) => {
    return dispatch => {
        dispatch({ type: HIFI_UPDATE_FEED, payload: post });
    };
};

export const updatePollOption = (post, item, position) => dispatch => {
    // post is index item of list
    const requestData = {
        QIdentity: post.contentData.identity,
        AIdentity: item.identity,
    };
        fetchData(
            requestData,
            UPDATE_POLL_ANSWER,
            dispatch,
            FEED_POLL_UPDATE, post, position
        );
};

export const UpdatePoll = (data) => dispatch => {
    dispatch({ type: FEED_POLL_UPDATE, payload: data });
};

const fetchData = (requestData, url, dispatch, action, argItem, argPosition) => {
    AsyncStorage.getItem('token').then(data => {
        const authOptions = {
            method: 'POST',
            url,
            data: requestData,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
        axiosWithoutDispatch(authOptions)
        .then((response) => {
            if (action === FEED_POLL_UPDATE) {
                if (response.status === 200) {
                    while (argItem.contentData.answer.length > 0) {
                        argItem.contentData.answer.pop();
                    }
                    response.data.data.map(item => {
                        argItem.contentData.answer.push(item);
                    });
                    dispatch({ type: action, payload: argItem });
                } else {
                   // console.log('Res:-onPollSelection ==' + JSON.stringify(response.status));
                }
            } else {
            dispatch({ type: action, payload: response.data.data });                
            }
        }).catch((error) => {
            console.log(error);
            if (error.toString().includes('401')) {
                const requestBundle = {
                    token: data,
                    ipAddress: IPADDRESS,
                    devicePlatform: (Platform.OS === 'ios') ? 3 : 2,
                };
                const req = {
                    method: 'POST',
                    url: REFRESH_TOKEN,
                    data: requestBundle,
                    json: true
                };
                axiosWithoutDispatch(req)
                .then((response) => {
                    if (response.status === 200) {
                        const tokendata = response.data.data.token.value;
                        //console.log('tokenVal:' + tokendata);
                        AsyncStorage.setItem('token', tokendata);
                        fetchData(requestData, url, dispatch, action);
                    } else {
                        Toast.show('Internal Server Error');
                    }
                }).catch((er) => {
                    console.log(er);
                });
            }
        });
        });
};
