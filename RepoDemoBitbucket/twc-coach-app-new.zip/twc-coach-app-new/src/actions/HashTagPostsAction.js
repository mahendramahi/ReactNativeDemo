
import { SEARCH_HASHTAGS_BYPOST } from '../constant/api';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { HASHTAG_POST_LOADING, HASHTAG_POST_LOADED,
    HASHTAG_POST_CLEAR, HASHTAG_CIRCLE_LOADING, HASHTAG_CIRCLE_LOADED } from './types';
import { getAsyncStorage, showToast } from '../components/Utility';
import { APP_DONT_HAVE_TOKEN } from '../constant/string';


export const getHashTagPostList = (argPageNo, argPageSize, argType, tag) => dispatch => {
    const tempTag = tag.replace('#', '');
    const request = {
        keyword: tempTag,
        pageIndex: argPageNo,
        pageSize: argPageSize,
        type: argType
    };
    const event1 = HASHTAG_POST_LOADING;
    const event2 = HASHTAG_POST_LOADED;
    //if (argPageNo === 1) { event1 = HASHTAG_POST_LOADING; event2 = HASHTAG_POST_LOADED; } else { event1 = POST_PAGING_LOADING; event2 = POST_PAGING_LOADED; }
    dispatch({ type: event1 });
    callApi(request, SEARCH_HASHTAGS_BYPOST, dispatch, event2);
};


export const getHashTagCircleList = (argPageNo, argPageSize, argType, tag) => dispatch => {
    const tempTag = tag.replace('#', '');
    const request = {
        keyword: tempTag,
        pageIndex: argPageNo,
        pageSize: argPageSize,
        type: argType
    };
    const event1 = HASHTAG_CIRCLE_LOADING;
    const event2 = HASHTAG_CIRCLE_LOADED;
    //if (argPageNo === 1) { event1 = HASHTAG_POST_LOADING; event2 = HASHTAG_POST_LOADED; } else { event1 = POST_PAGING_LOADING; event2 = POST_PAGING_LOADED; }
    dispatch({ type: event1 });
    callApi(request, SEARCH_HASHTAGS_BYPOST, dispatch, event2);
};

export const clearHashTagPost = () => dispatch => {
    dispatch({ type: HASHTAG_POST_CLEAR });
    };
    

const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
               if (action === HASHTAG_POST_LOADED) {
                dispatch({ type: action, payload: response.data.data.postData });
               } else {
                dispatch({ type: action, payload: response.data.data.circleData });
               }
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};
