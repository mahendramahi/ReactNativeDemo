import { HIFI_MEMBER_LIST_LOADED, HIFI_MEMBER_LIST_LOADING } from './types';
import { getAsyncStorage, showToast } from '../components/Utility';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { APP_DONT_HAVE_TOKEN } from '../constant/string';
import { GET_HIFI_MEMBER_LIST } from '../constant/api';

export const getHifiMemberList = (argPageIndex, argpageSize, argId) => dispatch => {
    dispatch({ type: HIFI_MEMBER_LIST_LOADING });
    const request = {
        PageIndex: argPageIndex,
        PageSize: argpageSize,
        Id: argId
    };
    callApi(request, GET_HIFI_MEMBER_LIST,
        dispatch, HIFI_MEMBER_LIST_LOADED);
};

const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: `Bearer ${data}`
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
               dispatch({ type: action, payload: response.data.data });
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};

