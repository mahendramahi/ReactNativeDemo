import { MYCIRCLE_LIST_LOADED, MYCIRCLE_LIST_UPDATE } from './types';
import { getAsyncStorage, showToast } from '../components/Utility';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { APP_DONT_HAVE_TOKEN } from '../constant/string';
import { GET_CIRCLES } from '../constant/api';

export const getMyCircleList = (argPageIndex, argpageSize) => dispatch => {
    const requestData = {
        PageSize: argpageSize,
        PageIndex: argPageIndex,
        SearchTerm: '',
        SortBy: 'circle',
    };
    callApi(requestData, GET_CIRCLES,
        dispatch, MYCIRCLE_LIST_LOADED);
};

export const updateListCheckStatus = (list) => dispatch => {
    dispatch({ type: MYCIRCLE_LIST_UPDATE, payload: list });
};


const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: `Bearer ${data}`
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
            const circleListData = response.data.data.data;
            circleListData.map(item => {
              item.check = false;
              return circleListData;
            });
            dispatch({ type: action, payload: circleListData });
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};

