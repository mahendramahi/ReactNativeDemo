import axios from 'axios';
import { AsyncStorage } from 'react-native';
import { POST_HIFI_URL } from '../constant/api';
import { HIFI_UPDATE, HIFI_ID } from './types';


export const updateHiFi = (PostId) => {
    const requestData = {
        Id: PostId
    };
    return dispatch => {
        dispatch({ type: HIFI_ID, payload: PostId });
        fetchHiFi(
            requestData,
            POST_HIFI_URL,
            dispatch,
            HIFI_UPDATE
        );
    };
};

const fetchHiFi = (requestData, url, dispatch, action) => {
    AsyncStorage.getItem('token').then(data => {
        const authOptions = {
            method: 'POST',
            url,
            data: requestData,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
        axios(authOptions).then(res => {
            dispatch({ type: action, payload: res.data.data });
            }).catch(error => console.log(error));
        });
};
