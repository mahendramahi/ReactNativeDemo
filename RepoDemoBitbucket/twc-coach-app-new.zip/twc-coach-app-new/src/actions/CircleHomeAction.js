
import { GET_CIRCLE_POST_LIST } from '../constant/api';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { POST_LIST_LOADING, POST_LIST_LOADED, POST_PAGING_LOADING,
    POST_PAGING_LOADED, CIRCLE_HOME_CLEAR, CIRCLE_COACH_CLEAR,
    CIRCLE_MEMBER_CLEAR } from './types';
import { getAsyncStorage, showToast } from '../components/Utility';
import { APP_DONT_HAVE_TOKEN } from '../constant/string';


export const getPostList = (argPageNo, argPageSize, argCircleId) => {
    const request = {
        PageIndex: argPageNo,
        PageSize: argPageSize,
        Id: argCircleId
    };
    let event1 = '';
    let event2 = '';
    if (argPageNo === 1) { event1 = POST_LIST_LOADING; event2 = POST_LIST_LOADED; } else { event1 = POST_PAGING_LOADING; event2 = POST_PAGING_LOADED; }
    
    return dispatch => {
        dispatch({ type: event1 });
        callApi(request, GET_CIRCLE_POST_LIST, dispatch, event2);
    };
};

export const clearCircleHome = () => dispatch => {
    dispatch({ type: CIRCLE_HOME_CLEAR });
    };

export const clearAllCircleDetails = () => dispatch => {
    dispatch({ type: CIRCLE_COACH_CLEAR });
    dispatch({ type: CIRCLE_HOME_CLEAR });
    dispatch({ type: CIRCLE_MEMBER_CLEAR });
};

const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
                dispatch({ type: action, payload: response.data.data });
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};
