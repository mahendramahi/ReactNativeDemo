
import { GET_MEMBERS_LIST } from '../constant/api';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { MEMBERS_LIST_LOADING, MEMBERS_LIST_LOADED,
     TOTAL_MEMBER_COUNT, MEMBERS_LIST_LOADMORE_LOADED, CIRCLE_MEMBER_CLEAR, MEMBERS_LIST_REMOVE_LOADING } from './types';
import { getAsyncStorage, showToast } from '../components/Utility';
import { APP_DONT_HAVE_TOKEN } from '../constant/string';


export const getCircleMmbersList = (argPageNo, argSearchTerms, argCircleId) => dispatch => {
    dispatch({ type: MEMBERS_LIST_LOADING });
    const request = {
        SearchTerm: argSearchTerms,
        pageIndex: argPageNo,
        Id: argCircleId
    };
    let event = '';
    if (argPageNo === 1) { event = MEMBERS_LIST_LOADED; } else { event = MEMBERS_LIST_LOADMORE_LOADED; }
   // return dispatch => {
       // dispatch({ type: MEMBERS_LIST_LOADING });
        callApi(request, GET_MEMBERS_LIST, dispatch, event);
   // };
};

// export const removeProgressBar = () => dispatch => {
//     dispatch({ type: MEMBERS_LIST_REMOVE_LOADING });
// };

export const clearCircleMembers = () => dispatch => {
    dispatch({ type: CIRCLE_MEMBER_CLEAR });
};

const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
        //dispatch({ type: MEMBERS_LIST_REMOVE_LOADING });
           if (response.status === 200) {
               if (action === MEMBERS_LIST_LOADED) {
                   dispatch({ type: TOTAL_MEMBER_COUNT, payload: response.data.data.totalMembers });
                   dispatch({ type: action, payload: response.data.data.circleMemberList });
                } else {
                    dispatch({ type: action, payload: response.data.data.circleMemberList });
                   // MEMBERS_LIST_LOADMORE_LOADED
                }
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            //dispatch({ type: MEMBERS_LIST_REMOVE_LOADING });
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
           // dispatch({ type: MEMBERS_LIST_REMOVE_LOADING });
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};
