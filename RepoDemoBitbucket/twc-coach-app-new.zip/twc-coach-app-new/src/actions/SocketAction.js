import React from 'react';
import firebase, { Firebase } from 'react-native-firebase';
import PushNotification from 'react-native-push-notification';
import { Platform, AsyncStorage } from 'react-native';
import { Actions } from 'react-native-router-flux';
//import SocketIOClient from 'react-native-socket.io-client';
import SocketIOClient from 'socket.io-client';
import { SOCKET_CONNECTED, SOCKET_CLIENT_RECEIVER_DETAIL,
    SOCKET_USER_ISTYPING, SOCKET_NEW_MESSAGE, SOCKET_SEND_NEW_MESSAGE,
    EMIT_SERVER_USER_ONLINE, CONNECT_ERROR,
    EMIT_SERVER_GET_UNREADCHATCOUNT, CLIENT_BIND_UNREADCHATCOUNT,
    EMIT_SERVER_GET_CHAT_LIST, CLIENT_BIND_CHAT_LIST,
    SOCKET_UNREAD_COUNT, SOCKET_CHAT_LIST,
    SOCKET_IS_COACH, IS_COACH,
    CLIENT_INIT_CHAT, CLIENT_MESSAGES, EMIT_SERVER_INIT_CHAT,
    EMIT_SERVER_INIT_RECEIVER, EMIT_SERVER_GET_RECEIVER_DETAILS,
    CLIENT_RECEIVER_DETAIL_LISTENER, CLIENT_USER_ONLINE,
    CLIENT_MESSAGE_HISTORY, EMIT_SERVER_MESSAGE_HISTORY,
    USER_MESSAGE_HISTORY_LOADED,
    CLIENT_SET_CHAT, EMIT_SERVER_GET_CHAT, CLIENT_DISCONNECT_CHAT_SESSION,
    CLIENT_CHAT_DELIVER, EMIT_SERVER_CHAT_DELIVER, CLIENT_CHAT_TYPING, SERVER_SEND,
    SOCKET_CHAT_DELIVER, SOKET_CLIENT_USER_ONLINE, SERVER_CHAT_TYPING,
    POST_UPLOADING, SOCKET_DELETE_USER_MEDIA_MSG, CLEAR_CHAT_MSG, EMIT_LOAD_HISTORY } from './types';
import { showToast, setAsyncStorage,
    getAsyncStorage } from './../components/Utility';
import { SOCKET_URL, FILEUPLOADER_URL } from './../constant/api';
import { store } from './../configureStore';
import { MEDIA_TYPE_IMAGE, FOLDER_TYPE_CHAT_MEDIA } from '../constant/string';
import { axiosWithoutDispatch } from '../helper/ApiHandler';

let token = '';//getAsyncStorage('token');
let fcmToken = '';
let UserFirstName = '';//getAsyncStorage('UserFirstName');
let UserLastName = '';//getAsyncStorage('UserLastName');
let UserImage = '';//getAsyncStorage('UserImage');
let UserIdentityId = '';//getAsyncStorage('UserIdentityId');
let ClientChatUser = '';
//console.ignoredYellowBox = ['Setting a timer'];


export const socketInit = () => {
   
};

export const CreateSocketConnectionDispatch = (dispatch) => {
    //console.log('socket ==== SocketConnection Call' + store.dispatch);
    SocketConnection(store.dispatch);
};

export const CreateSocketConnectionAction = () => dispatch => {
    //console.log('socket ==== SocketConnection Call');
    SocketConnection(store.dispatch);
};

///// Will improve letter
// export const SocketAfterLogin = (dispatch, argToken, argimage, argFirstName, argLastName, argIdentityId) => {
// token = argToken;
// UserFirstName = argFirstName;
// UserLastName = argLastName;
// UserImage = argimage;
// UserIdentityId = argIdentityId;
// console.log('socket === ' + token + '==' + UserIdentityId);
// SocketConnection(dispatch);
// };

const socketInitChat = () => {
    // Socket client init chat
    //console.log('socket ===== init chat' + store.dispatch);
    this.socket.off(CLIENT_INIT_CHAT);
    this.socket.on(CLIENT_INIT_CHAT, (args) => onInitChatListner(store.dispatch, args));
};

export const SocketConnection = async(dispatch) => {
    //console.log('socket === SocketConnectionCall');
    if (token === '' || token === null) {
    const userData = await getAsyncStorage('userData');
    //console.log('socket ==user Data Get on = ' + userData);
    token = JSON.parse(userData).token;
    fcmToken = JSON.parse(userData).fcmToken;
    UserFirstName = JSON.parse(userData).UserFirstName;
    UserLastName = JSON.parse(userData).UserLastName;
    UserImage = JSON.parse(userData).UserImage;
    UserIdentityId = JSON.parse(userData).UserIdentityId;
    }
    
    //console.log('tokenValue== ' + token);
    if (token != null && token !== '') {
        const options = { 
            forceNew: true,
            reconnectionDelay: 20,
            transports: ['websocket']
        };
        //console.log(SOCKET_URL);
        this.socket = SocketIOClient(SOCKET_URL, options);
        console.ignoredYellowBox = ['Setting a timer'];

        //console.log('socket === Token Get');
            this.socket.off('connect');
            this.socket.on('connect', (response) => onConnectListner(store.dispatch, response)); 
            
            // SOCKET disconnect listner
            this.socket.off('disconnect');
            this.socket.on('disconnect', (response) => onDisconnectListner(response));
            
            // SOCKET Error Reason get Here
            this.socket.off(CONNECT_ERROR);
            this.socket.on(CONNECT_ERROR, () => {
               // SocketConnection(store.dispatch);
                //console.log('socket == connection error');
            });

            this.socket.off('connect_timeout');
            this.socket.on('connect_timeout', (response) => onConnectionError(response));

            socketInitChat();      
            this.socket.connect();
        //console.log('socketConnecting Call====' + this.socket);
    } else {
        console.log('socket ==== User Not Log-in');
    }
};

export const getChatList = () => dispatch => {
    if (this.socket != null) {
            // GETCHATLIST emit and listner
            this.socket.off(CLIENT_BIND_CHAT_LIST);
            this.socket.on(CLIENT_BIND_CHAT_LIST, (response) => onChatListListner(dispatch, response));
            this.socket.emit(EMIT_SERVER_GET_CHAT_LIST, { SocketId: `C_${UserIdentityId}`, PageSize: 50, PageIndex: 1 });
    } else {
        CreateSocketConnectionDispatch(dispatch);
        dispatch({ type: SOCKET_CHAT_LIST, payload: [] });
    }     
};

export const socketConnectionDestroy = () => {
        //this.socket.emit('disconnect');
        if (this.socket != null) {
         try {   
        this.socket.disconnect();
        this.socket.off();
         } catch (e) {
             console.error(e.message);
         }
        }
};

export const getSocket = () => {
    if (this.socket != null) {
        return this.socket;
        } else {
            setTimeout(() => {
                getSocket();
            }, 1000);
        }
};

const setClientMessageListner = (argChatId) => {
    console.log('socket === client_message_ for ' + argChatId);
        this.socket.off(`${CLIENT_MESSAGES}${argChatId}`);
        this.socket.on(`${CLIENT_MESSAGES}${argChatId}`, (response) => onClientMessageListner(response, argChatId));
};

export const initChatBySocketid = (argChatId) => {
    const initObj = {
        SocketId: `C_${UserIdentityId}`,
        Name: `${UserFirstName} ${UserLastName}`,
        Image: `${UserImage}`
    };
    const UserData = {
        ChatId: argChatId,
        UserData: initObj
    };
    
    this.socket.emit(EMIT_SERVER_INIT_CHAT, UserData);
    serverInitReceiver(argChatId);
    setClientMessageListner(argChatId);
};

//// Call When User Click on chat Lits item From Chat list component
export const initChatFormAction = (argChatId) => dispatch => {
    //setClientMessageListner(argChatId);
    initChatBySocketid(argChatId);
};

//remove all litsner after chat Window Closed
export const removeConversationListner = (argChatId) => dispatch => {
    //console.log('socket ==== removeConversationListner=');
    this.socket.off(`${CLIENT_RECEIVER_DETAIL_LISTENER}${argChatId}`);
    this.socket.off(`${CLIENT_MESSAGE_HISTORY}${argChatId}`);
    this.socket.off(`${CLIENT_CHAT_DELIVER}${argChatId}`);
    this.socket.off(`${CLIENT_CHAT_TYPING}${argChatId}`);
    this.socket.off(`${EMIT_LOAD_HISTORY}${argChatId}`);
    //this.socket.off(CLIENT_USER_ONLINE);
    //this.socket.off(`${CLIENT_MESSAGES}${argChatId}`);
};

/// call When Chat Conversation Open on Chat Window
export const setChatConversationAction = (argChatId) => dispatch => {
    /// EMIT_SERVER_USER_ONLINE
    console.log('Call setChatConversationAction==' + argChatId);
    emitForSetUserOnlineStatus();

    //// 
    this.socket.off(`${CLIENT_RECEIVER_DETAIL_LISTENER}${argChatId}`);
    this.socket.on(`${CLIENT_RECEIVER_DETAIL_LISTENER}${argChatId}`, (response) => onClientReceiverDetail(response));
    //////
    this.socket.off(`${CLIENT_MESSAGE_HISTORY}${argChatId}`);
    this.socket.on(`${CLIENT_MESSAGE_HISTORY}${argChatId}`, (response) => onClientMessageHistoryListner(response));
    ////
    this.socket.off(CLIENT_USER_ONLINE);
    this.socket.on(CLIENT_USER_ONLINE, (response) => onClientUserOnlineListner(response));
    ///
    this.socket.off(`${CLIENT_CHAT_DELIVER}${argChatId}`);
    this.socket.on(`${CLIENT_CHAT_DELIVER}${argChatId}`, (response) => onClientChatDeliver(response));
    ////
    this.socket.off(`${CLIENT_CHAT_TYPING}${argChatId}`);
    this.socket.on(`${CLIENT_CHAT_TYPING}${argChatId}`, (response) => onClientChatTyping(response));
    ///
    //console.log('EMIT_SERVER_GET_RECEIVER_DETAILS==' + argChatId);
    this.socket.emit(`${EMIT_SERVER_GET_RECEIVER_DETAILS}${argChatId}`);
    ///
    this.socket.emit(`${EMIT_SERVER_MESSAGE_HISTORY}${argChatId}`);
};

export const serverInitReceiver = (argchatId) => {
    const initChatObj = {
        ChatId: argchatId,
        SocketId: `C_${UserIdentityId}`
    };
    this.socket.emit(EMIT_SERVER_INIT_RECEIVER, initChatObj);
   //getClientReceiverDetails(argchatId);
};

// load user old message history 
export const getUserOldMessageHistory = (argChatId, msgObj) => dispatch => {
    setListnerUserOldMessageHistory(argChatId, msgObj);
};

const setListnerUserOldMessageHistory = (argChatId, msgObj) => {
        this.socket.off(`${EMIT_LOAD_HISTORY}${argChatId}`);
        this.socket.on(`${EMIT_LOAD_HISTORY}${argChatId}`, (response) => onClientMessageHistoryListner(response));
        this.socket.emit(`${EMIT_LOAD_HISTORY}${argChatId}`, msgObj.MessageId);
    };

// const getClientReceiverDetails = (argchatId) => {
//     this.socket.off(`${CLIENT_RECEIVER_DETAIL_LISTENER}${argchatId}`);
//     this.socket.on(`${CLIENT_RECEIVER_DETAIL_LISTENER}${argchatId}`, (response) => onClientDetailsReceiver(response));
//     this.socket.emit(`${EMIT_SERVER_GET_RECEIVER_DETAILS}${argchatId}`);
// };

const emitForSetUserOnlineStatus = () => {
    //console.log('socket data====' + token + '==' + UserFirstName + '==' + UserIdentityId);
    const device = {
      Type: Platform.OS,
      Token: fcmToken
    };

    const userdata = {
        SocketId: `C_${UserIdentityId}`,
        Name: `${UserFirstName} ${UserLastName}`,
        Image: UserImage,
        Id: UserIdentityId,
        Type: SOCKET_IS_COACH,
        isCoach: IS_COACH,
        DeviceInfo: device
    };

    //console.log('socket data====' + JSON.stringify(userdata));
    this.socket.emit(EMIT_SERVER_USER_ONLINE, userdata);
};

export const setUserOnlineStatus = () => {
    ///EMIT_SERVER_USER_ONLINE
    emitForSetUserOnlineStatus();
    
    // UNREAD CHAT COUNT  emit or listner 
    this.socket.off(CLIENT_BIND_UNREADCHATCOUNT);
    this.socket.on(CLIENT_BIND_UNREADCHATCOUNT, (response) => onUnReadCountListner(store.dispatch, response));
    this.socket.emit(EMIT_SERVER_GET_UNREADCHATCOUNT, { SocketId: `C_${UserIdentityId}` });

    /// client Set Chat Listner 
    this.socket.off(CLIENT_SET_CHAT);
    this.socket.on(CLIENT_SET_CHAT, (response) => onCLientSetChatListner(response));

    /// client_disconnect_chat_session Listner
    this.socket.off(CLIENT_DISCONNECT_CHAT_SESSION);
    this.socket.on(CLIENT_DISCONNECT_CHAT_SESSION, (response) => onClientDisconnectChatSessionListner(response));
};

export const setClientMessageHistory = (argChatId) => dispatch => {
    this.socket.off(`${CLIENT_MESSAGE_HISTORY}${argChatId}`);
    this.socket.on(`${CLIENT_MESSAGE_HISTORY}${argChatId}`, (response) => onClientMessageHistoryListner(response));
    this.socket.emit(`${EMIT_SERVER_MESSAGE_HISTORY}${argChatId}`);
    setUserOnlineStatus();
};

////////////   All Socket Listners are Here    /////////////////////////////
const onClientMessageHistoryListner = (response) => {
    console.log('socket Listner===== onClientMessageHistoryListner===' + JSON.stringify(response));
    store.dispatch({ type: USER_MESSAGE_HISTORY_LOADED, payload: response });
};

// const onClientOldMessageHistory = (response) => {
//     console.log('socket Listner===== onClientOldMessageHistory===' + JSON.stringify(response));
// };

const onCLientSetChatListner = (response) => {
    console.log('socket Listner===== onClientSetChatListner == ' + JSON.stringify(response));
    if (!response.Error) {
        initChatBySocketid(response.Data);
        //initChatFormAction(response.Data);
        Actions.chatWindow({ chatId: response.Data, callbackFunction: null });
    } else {
         showToast(response.Message);
    }
};

const onClientDisconnectChatSessionListner = (response) => {
    console.log('socket Listner===== onClientDisconnectChatSessionListner == ' + JSON.stringify(response));
};

const onClientChatDeliver = (response) => {
    //console.log('socket Listner===== onClientChatDeliver == ' + JSON.stringify(response));
    if (Actions.currentScene === 'chatWindow') {
        store.dispatch({ type: SOCKET_CHAT_DELIVER, payload: response });
    }
};

const onClientChatTyping = (response) => {
    //console.log('socket Listner===== onClientChatTyping == ' + JSON.stringify(response));
    if (ClientChatUser === response.socketId) {
        store.dispatch({ type: SOCKET_USER_ISTYPING, payload: response });
        setTimeout(() => {
            store.dispatch({ type: SOCKET_USER_ISTYPING, payload: {} });
        }, 300);
    }
};

const onClientReceiverDetail = (response) => {
    console.log('socket Listner===== onClientDetailsReceiver== ' + JSON.stringify(response));
    //if (Actions.currentScene === 'chatWindow') {
       // if (ClientChatUser === response.SocketId) {
        ClientChatUser = response.SocketId;
        store.dispatch({ type: SOCKET_CLIENT_RECEIVER_DETAIL, payload: response });
       // }
    //}
};

const onClientUserOnlineListner = (response) => {
    //console.log('socket Listner===== onClientUserOnlineListner== ' + JSON.stringify(response));
    if (Actions.currentScene === 'chatWindow') {
        if (ClientChatUser === response.SocketId) {
        store.dispatch({ type: SOKET_CLIENT_USER_ONLINE, payload: response });
        }
    }
};

const onUnReadCountListner = (dispatch, response) => {
    //console.log('socket Listner==== unreadchatCount=response==== ' + JSON.stringify(response));
            store.dispatch({ type: SOCKET_UNREAD_COUNT, payload: response.data });
};

const onChatListListner = (dispatch, response) => {
        console.log('socket Listner==== chatList=response==== ' + JSON.stringify(response));
        store.dispatch({ type: SOCKET_CHAT_LIST, payload: response });
        // response.map(item => {
        //     console.log('socket =====onChatListItem For server_init_chat==' + JSON.stringify(item));
        //         console.log('socket =====server_init_chat For==' + item.Name);
        //         //initChatBySocketid(item.ChatId);
        // });
    };
 
const onConnectionError = (error) => {
        SocketConnection(store.dispatch);
        console.warn('socket Listner==== connection error =' + JSON.stringify(error));
};

const onDisconnectListner = (response) => {
    SocketConnection(store.dispatch);
    console.log('socket Listner==== Listner disconnect');
    console.log('socket Listner==== off all Listner' + response);
};

const onInitChatListner = (dispatch, response) => {
    console.log('socket Listner=====onInitChatListner==' + JSON.stringify(response));
    const ChatId = response.ChatId;
    response.Members.map(item => {
        //console.log('socket =====onInitChatmember==' + JSON.stringify(item));
        if (item.SocketId === `C_${UserIdentityId}`) {
            console.log('socket =====onInitChat For==' + item.SocketId);
            initChatBySocketid(ChatId);
        }
    });
};

const onClientMessageListner = (response, argChatId) => {
    console.log('socket Listner====== onClientMessageListner== ' + JSON.stringify(response));
    if (`C_${UserIdentityId}` !== response.SocketId) {
        notifyForMessageDelivered(argChatId, 1, response.MessageId);
    }
    if (Actions.currentScene === 'chatList') {
        ShowNotification(response);
        this.socket.emit(EMIT_SERVER_GET_CHAT_LIST, { SocketId: `C_${UserIdentityId}`, PageSize: 50, PageIndex: 1 });
    } else if (Actions.currentScene === 'chatWindow') {
        //console.log('socket === for perticuler user client_message =');
        if (ClientChatUser === response.SocketId) {
            notifyForMessageDelivered(argChatId, 2, response.MessageId);
            store.dispatch({ type: SOCKET_NEW_MESSAGE, payload: response });
        } else if (`C_${UserIdentityId}` === response.SocketId) {
            store.dispatch({ type: SOCKET_SEND_NEW_MESSAGE, payload: response });
        } else {
            ShowNotification(response);
        }
    } else {
        ShowNotification(response);
    }
    this.socket.emit(EMIT_SERVER_GET_UNREADCHATCOUNT, { SocketId: `C_${UserIdentityId}` });
};

export const onConnectListner = (dispatch, res) => {
    console.log('socket Listner==== connect=' + JSON.stringify(res));
        // SET USER ONLINE USING USER DATA
        setUserOnlineStatus();
    };

///send msg to socket Server
export const sendMsgAction = (data, chatId) => dispatch => {
    this.socket.emit(`${SERVER_SEND}${chatId}`, data);
};

/// extra Code For Ui 
export const getUnReadCount = () => dispatch => {
    this.socket.emit(EMIT_SERVER_GET_UNREADCHATCOUNT, { SocketId: `C_${UserIdentityId}` });
};

//// Need to Improve letter 
export const setClientChatUser = (clientid) => dispatch => {
    ClientChatUser = clientid;
};

export const sendTypingStatus = (chatId) => dispatch => {
    const obj = {
        socketId: `C_${UserIdentityId}`
    };
    this.socket.emit(`${SERVER_CHAT_TYPING}${chatId}`, obj);
};

/// MessageDelivery Statue Will Change By this Function
export const notifyForMessageDelivered = (chatId, status, msgId) => {
    const emitObj = {
        Status: status,
        MessageId: msgId
    };
    this.socket.emit(`${EMIT_SERVER_CHAT_DELIVER}${chatId}`, emitObj);
};

///// EMIT FOR Media Message
const sendMediaMessage = (newMsg, media) => {
    const fileobj = {
        FileName: media.fileName
    };
    const msgData = {
        TypeId: newMsg.TypeId,
        Message: JSON.stringify(fileobj),
        from: 'mobile'
      };
      //console.log('Call Back From Transloadit==for delete');
      //console.log('send Media Msg' + JSON.stringify(msgData));
      //console.log('send Media to ' + media.chatId);
      this.socket.emit(`${SERVER_SEND}${media.chatId}`, msgData); 
};

export const addNewMediaMsg = (newMsg) => dispatch => {
    newMsg.SocketId = `C_${UserIdentityId}`;
    newMsg.MessageId = -1;
    newMsg.DisplayName = `${UserFirstName} ${UserLastName}`;
    newMsg.Name = `${UserFirstName} ${UserLastName}`;
    newMsg.Image = `${UserImage}`;
    newMsg.DisplayImage = `${UserImage}`;
    //console.log('Chat ==== Media Msg =' + JSON.stringify(newMsg));
    dispatch({ type: SOCKET_SEND_NEW_MESSAGE, payload: newMsg });
};

export const actionSendMediaMsg = (newMsg, media) => dispatch => {
    dispatch({ type: SOCKET_DELETE_USER_MEDIA_MSG, payload: newMsg });
    sendMediaMessage(newMsg, media);
};

export const removeChatHistoryData = () => dispatch => {
    dispatch({ type: CLEAR_CHAT_MSG });
};


export const mediaMsgUpload = (media, base64, newMsg, mediaType) => dispatch => {
    const ext = media.fileName.split('.');
    const mediaData = new FormData();
    mediaData.append('MediaType', mediaType);
    mediaData.append('FolderType', FOLDER_TYPE_CHAT_MEDIA);
    mediaData.append('Data', base64);
    mediaData.append('FileName', media.fileName);
    mediaData.append('Extension', `.${ext[1]}`);

       // dispatch({ type: POST_UPLOADING });
        AsyncStorage.getItem('token').then(data => {
            const url = FILEUPLOADER_URL;
            // const request = {
            //     method: 'POST',
            //     url,
            //     headers: {
            //         Authorization: `Bearer ${data}`,
            //     },
            //     body: mediaData,
            //     json: true
            // };
            const request = {
                method: 'POST',
                url,
                data: mediaData,
                headers: {
                    Authorization: `Bearer ${data}`
                },
                json: true
            };
            axiosWithoutDispatch(request)
            .then((uploaderResponse) => {
                console.log('upload===' + JSON.stringify(uploaderResponse));
                if (uploaderResponse.data != null && uploaderResponse.data.data[0] !== '') {
                    const uploadedFileName = uploaderResponse.data.data[0];
                    const { fileHeight, fileWidth } = media;
                    media.fileName = uploadedFileName;
                    console.log('Print Upload' + JSON.stringify(media));
                    dispatch({ type: SOCKET_DELETE_USER_MEDIA_MSG, payload: newMsg });
                    sendMediaMessage(newMsg, media);
                } else {
                    showToast('Image Upload error From Server');
                }
            }).catch(error => {
                console.error(error);
            });
            // fetch(FILEUPLOADER_URL, request).then(response => {
            //     console.log('upload == ' + JSON.stringify(response));
            //     const uploaderResponse = JSON.parse(response._bodyText);
            //     if (uploaderResponse.data != null && uploaderResponse.data[0] !== '') {
            //         const uploadedFileName = uploaderResponse.data[0];
            //         const { fileHeight, fileWidth } = media;
            //         media.fileName = uploadedFileName;
            //         console.log('Print Upload' + JSON.stringify(media));
            //         dispatch({ type: SOCKET_DELETE_USER_MEDIA_MSG, payload: newMsg });
            //         sendMediaMessage(newMsg, media, mediaType);
            //        //submitPostRequest(postMedia, postText, circlesIds, dispatch);
            //     } else {
            //         showToast('Image Upload error From Server');
            //     }
            // }).catch(error => {
            //     console.log(request);
            //     console.log(error);
            // });
        });
};

const ShowNotification = (response) => {
    //console.log('Socket == push =' + JSON.stringify(response));
    if (response.TypeId === 2) {
        const fileMsg = JSON.parse(response.Message);
        PushNotification.localNotification({
            /* Android Only Properties */
            id: response.MessageId, // (optional) Valid unique 32 bit integer specified as string. default: Autogenerated Unique ID
            largeIcon: 'ic_wellness', // (optional) default: "ic_launcher"
            smallIcon: 'ic_wellness', // (optional) default: "ic_notification" with fallback for "ic_launcher"
            bigText: `${response.Name} sent an Image`, // (optional) default: "message" prop
            vibrate: true, // (optional) default: true
            vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
            priority: 'high', // (optional) set notification priority, default: high
            visibility: 'public', // (optional) set notification visibility, default: private
            importance: 'high', // (optional) set notification importance, default: high
           // imageUrl: fileMsg.FileName,
        
            /* iOS only properties */
            alertAction: '', // (optional) default: view
            category: '', // (optional) default: null
            userInfo: '', // (optional) default: null (object containing additional notification data)
        
            /* iOS and Android properties */
            title: response.Name, // (optional)
            message: `${response.Name} sent an Image`, // (required)
            playSound: true, // (optional) default: true
            soundName: 'default', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
            number: '1', // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
            actions: '',  // (Android only) See the doc for notification actions to know more
            date: new Date(Date.now())
            });
    } else if (response.TypeId === 4 || response.TypeId === 5) {
       // const fileMsg = JSON.parse(response.Message);
        PushNotification.localNotification({
            /* Android Only Properties */
            id: response.MessageId, // (optional) Valid unique 32 bit integer specified as string. default: Autogenerated Unique ID
            largeIcon: 'ic_wellness', // (optional) default: "ic_launcher"
            smallIcon: 'ic_wellness', // (optional) default: "ic_notification" with fallback for "ic_launcher"
            bigText: `${response.Name} sent a File`, // (optional) default: "message" prop
            vibrate: true, // (optional) default: true
            vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
            priority: 'high', // (optional) set notification priority, default: high
            visibility: 'public', // (optional) set notification visibility, default: private
            importance: 'high', // (optional) set notification importance, default: high
           // imageUrl: fileMsg.FileName,
        
            /* iOS only properties */
            alertAction: '', // (optional) default: view
            category: '', // (optional) default: null
            userInfo: '', // (optional) default: null (object containing additional notification data)
        
            /* iOS and Android properties */
            title: response.Name, // (optional)
            message: `${response.Name} sent a File`, // (required)
            playSound: true, // (optional) default: true
            soundName: 'default', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
            number: '1', // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
            actions: '',  // (Android only) See the doc for notification actions to know more
            date: new Date(Date.now())
            });
    } else {
        PushNotification.localNotification({
        /* Android Only Properties */
        id: response.MessageId, // (optional) Valid unique 32 bit integer specified as string. default: Autogenerated Unique ID
        largeIcon: 'ic_wellness', // (optional) default: "ic_launcher"
        smallIcon: 'ic_wellness', // (optional) default: "ic_notification" with fallback for "ic_launcher"
        bigText: response.Message, // (optional) default: "message" prop
        vibrate: true, // (optional) default: true
        vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
        priority: 'high', // (optional) set notification priority, default: high
        visibility: 'public', // (optional) set notification visibility, default: private
        importance: 'high', // (optional) set notification importance, default: high
    
        /* iOS only properties */
        alertAction: '', // (optional) default: view
        category: '', // (optional) default: null
        userInfo: '', // (optional) default: null (object containing additional notification data)
    
        /* iOS and Android properties */
        title: response.Name, // (optional)
        message: response.Message, // (required)
        playSound: true, // (optional) default: true
        soundName: 'default', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
        number: '1', // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
        actions: '',  // (Android only) See the doc for notification actions to know more
        date: new Date(Date.now())
        });
    }
};

const setListnerSetChat = () => {
    /// client Set Chat Listner 
    this.socket.off(CLIENT_SET_CHAT);
    this.socket.on(CLIENT_SET_CHAT, (response) => onCLientSetChatListner(response));
};

////// Initiate Chat From User by Click on Member List item
export const getChatId = (receiverId) => dispatch => {
    console.log('getChatId ===' + receiverId);
    setListnerSetChat();
    const receiver = {
        Id: receiverId,
        IsCoach: false
    };
    const sender = {
        Id: UserIdentityId,
        IsCoach: true
    };
    const obj = {
        Receiver: receiver,
        Sender: sender
    };
    this.socket.emit(EMIT_SERVER_GET_CHAT, obj);
};
