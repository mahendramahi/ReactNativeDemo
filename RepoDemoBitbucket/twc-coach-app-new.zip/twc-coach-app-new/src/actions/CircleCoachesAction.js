
import { GET_COACHES_LIST } from './../constant/api';
import { axiosWithoutDispatch } from './../helper/ApiHandler';
import { COACHES_LIST_LOADING, COACHES_LIST_LOADED, CIRCLE_COACH_CLEAR } from './../actions/types';
import { getAsyncStorage, showToast } from './../components/Utility';
import { APP_DONT_HAVE_TOKEN } from './../constant/string';


export const getCircleCoachesList = (request) => {
    return dispatch => {
        dispatch({ type: COACHES_LIST_LOADING });
        callApi(request, GET_COACHES_LIST, dispatch, COACHES_LIST_LOADED);
    };
};

export const clearCircleCoach = () => dispatch => {
    dispatch({ type: CIRCLE_COACH_CLEAR });
};

const callApi = (request, url, dispatch, action) => {
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url,
            data: request,
            headers: {
                Authorization: 'Bearer ' + data
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
               dispatch({ type: action, payload: response.data.data });
           } else {
            dispatch({ type: action, payload: [] });
           }
        })
        .catch((error) => {
            dispatch({ type: action, payload: [] });
        });
        }).catch(() => {
            showToast(APP_DONT_HAVE_TOKEN);
        });    
};
