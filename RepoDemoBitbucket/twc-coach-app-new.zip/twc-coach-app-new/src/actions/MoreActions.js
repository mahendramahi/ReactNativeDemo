import { AsyncStorage } from 'react-native';
import { Actions } from 'react-native-router-flux';
import firebase from 'react-native-firebase';
import { LOGOUT, LOGOUT_INITIATED } from './types';
import { socketConnectionDestroy } from '../actions';

export const logout = () => dispatch => {
        dispatch({ type: LOGOUT_INITIATED });
        firebase.messaging().deleteToken();
        AsyncStorage.removeItem('userData');
        socketConnectionDestroy();
        AsyncStorage.removeItem('token').then(() => {
            Actions.auth({ type: 'reset' });
            dispatch({ type: LOGOUT });
        }); 
};
