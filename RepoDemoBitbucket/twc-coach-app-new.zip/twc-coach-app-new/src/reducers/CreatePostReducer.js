import { POST_UPLOADING, POST_UPLOADED } from '../actions/types';

const INITIAL_STATE = {
    loading: false,
    showSuccessToast: false,
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case 'progressStop':
            return { ...state, loading: false };
        case POST_UPLOADING:
            return { ...state, loading: true };
        case POST_UPLOADED:
            return { ...state, loading: false, showSuccessToast: true };
        default:
            return state;
    }
};
