import { FEED_LOADING, FEED_LOADING_START, HIFI_UPDATE_FEED,
    FEED_POLL_UPDATE, UPDATE_COMMENT_COUNT, FEED_BLANK, FEED_LOADING_CLEAR } from '../actions/types';

const INITIAL_STATE = {
    feeds: [],
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case FEED_LOADING: 
            return { ...state, feeds: [...state.feeds, ...action.payload] };
        case FEED_LOADING_START: 
            return { ...state, feeds: action.payload };
        case FEED_BLANK:
            return { ...state, feeds: [] };
        case FEED_LOADING_CLEAR:
            return { ...state, feeds: [] };
        case HIFI_UPDATE_FEED:
            return { ...state, feeds: [...state.feeds, action.payload] };
        case FEED_POLL_UPDATE:
            return { ...state, feeds: [...state.feeds, action.payload] };
        case UPDATE_COMMENT_COUNT: 
            return { ...state, feeds: [...state.feeds, action.payload] };
        default: 
            return state;
    }
};
