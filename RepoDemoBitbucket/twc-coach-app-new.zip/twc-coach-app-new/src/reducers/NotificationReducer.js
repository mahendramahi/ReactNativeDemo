import { NOTIFICATION_LOADING, NOTIFICATION_LOADED,
    NOTIFICATION_LOAD_PAGEING, NOTIFICATION_CLEAR } from './../actions/types';

const INITIAL_STATE = {
   isLoading: false,
   notificationList: [],
};

export default (state = INITIAL_STATE, action) => {
   switch (action.type) {
      case NOTIFICATION_LOADING: 
           return { ...state, isLoading: true };
      case NOTIFICATION_LOADED:
            return { ...state, isLoading: false, notificationList: action.payload };
      case NOTIFICATION_CLEAR: 
         return { ...state, notificationList: [] };    
      case NOTIFICATION_LOAD_PAGEING: 
         return { ...state, isLoading: false, notificationList: [...state.notificationList, ...action.payload] };     
      case 'hideLoading':
      return { ...state, isLoading: false };
      default:
           return state;
   }
};
