import { SOCKET_CONNECTED, SOCKET_UNREAD_COUNT, SOCKET_CLIENT_RECEIVER_DETAIL, 
    SOCKET_CHAT_LIST, USER_MESSAGE_HISTORY_LOADED, SOCKET_USER_ISTYPING,
    SOCKET_NEW_MESSAGE, SOCKET_SEND_NEW_MESSAGE, SOCKET_CHAT_DELIVER,
    SOKET_CLIENT_USER_ONLINE, SOCKET_DELETE_USER_MEDIA_MSG, CLEAR_CHAT_MSG
 } from '../actions/types';

const INITIAL_STATE = {
    socket: null,
    unreadCount: 0,
    chatList: [],
    userMessageHistory: [],
    isLoadMoreMessageHistory: false,
    clientReceiverDetail: {},
    clientUserOnline: {},
    userIsTyping: {},
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
       case SOCKET_CONNECTED:
            return { ...state };
        case CLEAR_CHAT_MSG:
            return { ...state, userMessageHistory: [], clientReceiverDetail: {}, clientUserOnline: {}, userIsTyping: {} };    
        case SOCKET_UNREAD_COUNT: 
            return { ...state, unreadCount: action.payload };
        case SOCKET_CHAT_LIST:
            return { ...state, chatList: action.payload };
        case SOCKET_CLIENT_RECEIVER_DETAIL: 
            return { ...state, clientReceiverDetail: action.payload, userIsTyping: {} };
        case SOKET_CLIENT_USER_ONLINE: 
            return { ...state, clientUserOnline: action.payload, userIsTyping: {} };
        case SOCKET_USER_ISTYPING:
            return { ...state, userIsTyping: action.payload };
        case SOCKET_NEW_MESSAGE:
        {
            const tempArray = [];
            tempArray.push(action.payload);
            return { ...state, userMessageHistory: [...tempArray, ...state.userMessageHistory] };
        }
        case SOCKET_SEND_NEW_MESSAGE:
        {
            const tempArray = [];
            tempArray.push(action.payload);
            return { ...state, userMessageHistory: [...tempArray, ...state.userMessageHistory] };
        }
        case SOCKET_DELETE_USER_MEDIA_MSG: 
        {
            const index = state.userMessageHistory.indexOf(action.payload);
            if (index > -1) {
                state.userMessageHistory.splice(index, 1);
              }
            return { ...state, userMessageHistory: state.userMessageHistory };
        }
        case SOCKET_CHAT_DELIVER:
        {
            state.userMessageHistory.map(item => {
                if (item.MessageId === action.payload.MessageId) {
                    item.Status = action.payload.Status;
                }
            });
            return { ...state, userMessageHistory: state.userMessageHistory };
        }
        case USER_MESSAGE_HISTORY_LOADED:
        {
            const tempArray = action.payload.Messages.reverse();
            return { ...state, isLoadMoreMessageHistory: action.payload.Isloadmore, userMessageHistory: [...state.userMessageHistory, ...tempArray] }; 
        }
        default: 
            return state;
    }
};
