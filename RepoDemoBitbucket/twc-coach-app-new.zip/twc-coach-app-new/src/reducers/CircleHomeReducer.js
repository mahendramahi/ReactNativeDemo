import { POST_LIST_LOADED, POST_LIST_LOADING,
   POST_PAGING_LOADED, POST_PAGING_LOADING, CIRCLE_HOME_CLEAR } from '../actions/types';

const INITIAL_STATE = {
   data: {},
   isLoading: false,
   postList: [],
};

export default (state = INITIAL_STATE, action) => {
   switch (action.type) {
      case POST_LIST_LOADED:
         return { ...state, isLoading: false, postList: action.payload };
      case POST_LIST_LOADING:
         return { ...state, isLoading: true };
      case CIRCLE_HOME_CLEAR:
         return { ...state, postList: [] };   
      case POST_PAGING_LOADED:
         return { ...state, postList: [...state.postList, ...action.payload] };
      default:
           return state;
   }
};
