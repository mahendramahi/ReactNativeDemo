import { LOGIN_INPUT_CHANGED, LOGIN_SUCCESS, LOGIN_FAIL, LOGIN_INITIATED } from '../actions/types';

const INITIAL_STATE = {
    email: '',
    password: '',
    loading: false,
    error: ''
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case LOGIN_INPUT_CHANGED:
            return { ...state, [action.payload.prop]: action.payload.value };
        case LOGIN_INITIATED:
            return { ...state, loading: true, error: '' };
        case LOGIN_SUCCESS:
            return { ...state, loading: false, error: '' };
        case LOGIN_FAIL:
            return { ...state, error: 'Invalid credentials', loading: false };
        default:
            return state;
    }
};
