import { HIFI_UPDATE, HIFI_ID } from '../actions/types';

const INITIAL_STATE = {
    data: {},
    postId: ''
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case HIFI_UPDATE:
        return { ...state, data: action.payload.data };
        case HIFI_ID:
        return { ...state, postId: action.payload };
        default:
            return state;
    }
};
