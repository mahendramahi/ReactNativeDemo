import { HIFI_MEMBER_LIST_LOADED, HIFI_MEMBER_LIST_LOADING } from '../actions/types';

const INITIAL_STATE = {
    loading: false,
    memberData: []
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case HIFI_MEMBER_LIST_LOADING:
            return { ...state, loading: true };
        case HIFI_MEMBER_LIST_LOADED:
            return { ...state, loading: false, memberData: action.payload };
        default:
            return state;
    }
};
