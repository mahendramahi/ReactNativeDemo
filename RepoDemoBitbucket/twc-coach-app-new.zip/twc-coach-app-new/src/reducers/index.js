import { combineReducers } from 'redux';
import AuthReducer from './AuthReducer';
import MoreReducer from './MoreReducer';
import HomeReducer from './HomeReducer';
import FeedReducer from './FeedReducer';
import PostReducer from './PostReducer';
import CreatePostReducer from './CreatePostReducer';
import PostDetailReducer from './PostDetailReducer';
import NotificationReducer from './NotificationReducer';
import CircleCoachesReducer from './CircleCoachesReducer';
import CircleMembersReducer from './CircleMembersReducer';
import CircleHomeReducer from './CircleHomeReducer';
import SocketReducer from './SocketReducer';
import AppStateReducer from './AppStateReducer';
import HashTagPostsReducer from './HashTagPostsReducer';
import HifiMemberReducer from './HifiMemberReducer';
import SelectCirclesReducer from './SelectCirclesReducer';

export default combineReducers({
    auth: AuthReducer,
    more: MoreReducer,
    home: HomeReducer,
    feeds: FeedReducer,
    post: PostReducer,
    createPost: CreatePostReducer,
    postDetail: PostDetailReducer,
    notification: NotificationReducer,
    circleCoach: CircleCoachesReducer,
    circleMembers: CircleMembersReducer,
    circleHome: CircleHomeReducer,
    socket: SocketReducer,
    appState: AppStateReducer,
    hashTagPost: HashTagPostsReducer,
    HifiMember: HifiMemberReducer,
    selectCircle: SelectCirclesReducer,
});
