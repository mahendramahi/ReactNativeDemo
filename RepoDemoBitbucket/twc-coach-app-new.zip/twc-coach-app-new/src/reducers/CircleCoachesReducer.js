import { COACHES_LIST_LOADED, COACHES_LIST_LOADING,
   CIRCLE_COACH_CLEAR } from './../actions/types';

const INITIAL_STATE = {
   data: {},
   isLoading: false,
   coachList: [],
};

export default (state = INITIAL_STATE, action) => {
   switch (action.type) {
      case COACHES_LIST_LOADED:
         return { ...state, isLoading: false, coachList: action.payload };
      case COACHES_LIST_LOADING:
         return { ...state, isLoading: true };
      case CIRCLE_COACH_CLEAR:
         return { ...state, coachList: [] };   
      default:
           return state;
   }
};
