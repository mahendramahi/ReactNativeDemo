import { COMMENTLIST_LOADING, COMMENTLIST_LOADED,
     NEW_COMMENT_ADDED, LOAD_CHNAGES, PREVIOUS_COMMENT, GET_POST_DETAIL,
     REMOVE_POST_DETAIL, ADD_HIFI_ON_COMMENT_UPDATE, ADDED_REPLY_UPDATE } from './../actions/types';

const INITIAL_STATE = {
    data: {},
    isLoading: false,
    commentsList: [],
    postDetailObj: {},
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case COMMENTLIST_LOADING: 
            return { ...state, isLoading: false };
        case COMMENTLIST_LOADED: 
            return { ...state, commentsList: action.payload, isLoading: false }; 
        case NEW_COMMENT_ADDED:
            return { ...state, commentsList: [...state.commentsList, ...action.payload], isLoading: false };
        case LOAD_CHNAGES:
            return { ...state, loadAgain: false };
        case PREVIOUS_COMMENT: 
            return { ...state, commentsList: [...action.payload, ...state.commentsList], isLoading: false };
        case GET_POST_DETAIL:
            return { ...state, isLoading: false, postDetailObj: action.payload[0] };
        case REMOVE_POST_DETAIL:
            return { ...state, isLoading: false, postDetailObj: {} };
        case ADD_HIFI_ON_COMMENT_UPDATE: 
            return { ...state, commentsList: [...state.commentsList] };
        case ADDED_REPLY_UPDATE:
            return { ...state, commentsList: [...state.commentsList] };  
        case 'clearCommentList':
            return { ...state, commentsList: [] };   
        default:
            return state;
    }
};
