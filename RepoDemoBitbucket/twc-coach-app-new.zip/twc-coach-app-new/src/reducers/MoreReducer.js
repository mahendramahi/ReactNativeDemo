import { LOGOUT, LOGOUT_INITIATED } from '../actions/types';

const INITIAL_STATE = {
    loading: false
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case LOGOUT:
            return { ...state, loading: false };
        case LOGOUT_INITIATED:
            return { ...state, loading: true };
        default:
            return state;
    }
};
