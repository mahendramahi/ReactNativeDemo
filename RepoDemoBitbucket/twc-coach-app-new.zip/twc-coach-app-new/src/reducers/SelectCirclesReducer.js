import { MYCIRCLE_LIST_LOADED, MYCIRCLE_LIST_UPDATE } from '../actions/types';

const INITIAL_STATE = {
    data: [],
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case MYCIRCLE_LIST_LOADED:
            return { ...state, data: action.payload };
        case MYCIRCLE_LIST_UPDATE:
            return { ...state, data: action.payload };
        default:
            return state;
    }
};
