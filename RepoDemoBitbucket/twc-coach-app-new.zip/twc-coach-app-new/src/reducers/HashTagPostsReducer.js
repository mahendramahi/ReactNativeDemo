import { HASHTAG_POST_LOADING, HASHTAG_POST_LOADED, HASHTAG_CIRCLE_LOADED,
   HASHTAG_CIRCLE_LOADING, HASHTAG_POST_CLEAR } from '../actions/types';
 
 const INITIAL_STATE = {
    data: {},
    isLoading: false,
    postList: [],
    circleList: [],
 };

   export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
      case HASHTAG_POST_LOADING:
         return { ...state, isLoading: true };
      case HASHTAG_POST_LOADED:
         return { ...state, postList: action.payload };
      case HASHTAG_CIRCLE_LOADING:
         return { ...state, isLoading: true };
      case HASHTAG_CIRCLE_LOADED:
         return { ...state, circleList: action.payload }; 
      case HASHTAG_POST_CLEAR:
         return { ...state, postList: [] };
      default:
        return { ...state };
    }
 };
