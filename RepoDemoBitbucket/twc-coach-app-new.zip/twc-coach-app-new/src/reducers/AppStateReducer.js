import { FOREGROUND, BACKGROUND, INACTIVE } from 'redux-enhancer-react-native-appstate';
import { CreateSocketConnectionDispatch, socketConnectionDestroy } from './../actions';
import { store } from './../configureStore';


export default(state = '', action) => {
    switch (action.type) {
    case FOREGROUND:
      socketWork();
      return 'back to foreground';
    case BACKGROUND:
      socketConnectionDestroy();
      return 'background';
    case INACTIVE:
      return 'inactive';
    default:
      return state;
  }
};

const socketWork = () => {
  //console.log('App is In Forground' + store.dispatch);
  CreateSocketConnectionDispatch(store.dispatch);
};

