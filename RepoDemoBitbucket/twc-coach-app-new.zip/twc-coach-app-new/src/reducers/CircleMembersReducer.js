import { MEMBERS_LIST_LOADED, MEMBERS_LIST_LOADING,
    TOTAL_MEMBER_COUNT, MEMBERS_LIST_LOADMORE_LOADED,
    CIRCLE_MEMBER_CLEAR, 
    } from '../actions/types';

const INITIAL_STATE = {
   data: {},
   isLoading: false,
   totalMembers: 0,
   membersList: [],
};

export default (state = INITIAL_STATE, action) => {
   console.log('reducer called', action);
   switch (action.type) {
      case MEMBERS_LIST_LOADED:
         return { ...state, isLoading: false, membersList: action.payload };
      case MEMBERS_LIST_LOADING:
         return { ...state, isLoading: true };
      case TOTAL_MEMBER_COUNT:
         return { ...state, totalMembers: action.payload, isLoading: false };
      case MEMBERS_LIST_LOADMORE_LOADED:
         return { ...state, membersList: [...state.membersList, ...action.payload], isLoading: false };
      case CIRCLE_MEMBER_CLEAR:
         return { ...state, membersList: [], totalMembers: 0, isLoading: false };
      default:
           return state;
   }
};
