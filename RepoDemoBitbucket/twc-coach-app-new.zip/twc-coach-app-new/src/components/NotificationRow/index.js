import React from 'react';
import { View, Text, Image, TouchableOpacity, Dimensions } from 'react-native';
import { Card, CardSection } from './../common';  //common';
import styles from './Style';
import HTML from 'react-native-render-html';
import UserAvatar from '../../ThirdParty/UserAvatar';

const renderUserImage = (notificationItem) => {
    let UserName = '';
    UserName = notificationItem.text.split(' ').slice(0, 2).join(' ').replace('<b>', '');
    const nameForUserAvatar = UserName.replace('</b>', '');
    if (notificationItem.image !== null && !notificationItem.image.includes('initial-image.png')) {
    return (
            <UserAvatar
            name={nameForUserAvatar} 
            src={notificationItem.image} 
            size={70} 
            />
        );
    } else {
        return (
            <UserAvatar
            name={nameForUserAvatar}
            src={''}
            size={70}
            />
        );
    }
};

const NotificationRow = ({ notificationItem, onItemClick }) => {
    return (
        <View 
        style={{ margin: 1 }}
        >
        <TouchableOpacity
        onPress={() => {
            onItemClick(notificationItem);
        }}
        >
        <Card>
            <CardSection>
                <View style={styles.imageroundx}>
                    {renderUserImage(notificationItem)}
                    {/* <Image 
                        style={styles.circleimg}
                        source={{ uri: notificationItem.image }}
                    /> */}
                </View>
                <View style={styles.circlecontent}>
                    <HTML
                    tagsStyles={{ marginRight: 30, fontSize: 1 }}
                    classesStyles={{ marginRight: 30 }}
                    containerStyle={{ marginRight: 30 }}
                    html={notificationItem.text}
                    imagesMaxWidth={Dimensions.get('window').width}
                    />
                    
                    <Text style={styles.circlepost}>{notificationItem.date}</Text>
                </View>
                
            </CardSection>
        </Card>
        </TouchableOpacity>
        </View>
    );
};

export default NotificationRow;

