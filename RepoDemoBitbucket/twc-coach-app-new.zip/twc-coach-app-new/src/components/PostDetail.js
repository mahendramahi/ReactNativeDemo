import React from 'react';
import { View, TextInput, ActivityIndicator,
    TouchableOpacity, Image, ScrollView,
    Platform, FlatList, Keyboard, Text, Animated,
    Dimensions
} from 'react-native';
import { createStore } from 'redux';
import Spinner from 'react-native-loading-spinner-overlay';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';
import Post from './Post';
import ToolBarWithBackArrow from '../components/common/ToolBarWithBackArrow';
import MessageRow from '././MessageRow';
import { getCommentsData, saveComment, saveCommentReply, getPostDetail,
     addHifiOnComment, UpdateCommentCount, removePostDetailObj, clearCommentList } from './../actions';
import AppStyle from './../helper/AppStyles';
import { showToast, getAsyncStorage } from './Utility';
import CommentUserTagInput from '../ThirdParty/CommentUserTagInput';
import { SEARCH_USERNAME_BYPOST } from '../constant/api';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import UserAvatar from '../ThirdParty/UserAvatar';

/**
 * A Reducer which is subscribe for Comment Changes
 */
// const intial = { loadAgain: false };
// const loadReducer = (state = intial, action) => {
//     switch (action.type) {
//       case 'loadAgain':
//         return { ...state, loadAgain: action.loadAgain };
//       default:
//         return state;
//     }
//   };

// const storeLocal = createStore(loadReducer);
const { height } = Dimensions.get('window');
class PostDetail extends React.PureComponent {

    constructor(props) {
        super(props);
        this.scrollView = null;
        this.isScrollAble = false;
        this.isAutoScrollToBottom = false;
        this.timeout = null;
        this.state = {
           pageForComments: 0,
           pageSize: 10,
           commentBody: '',
           nestedReplayObj: {
            isNestedReplay: false,
            Membername: '',
            CommentIdentity: '',
            MemberIdentity: '',
            screenHeight: 0,
            data: [],
            hashTagValue: [],
            TagTypeValue: [],
            keyword: ''
           },
        };
        //Function For Login on Component
        this.handleClickOnHiFi = this.handleClickOnHiFi.bind(this);
        this.handleClickNestedreplay = this.handleClickNestedreplay.bind(this);
    }
    
    componentWillMount() {
        //console.log('notificationData  Data = ' + JSON.stringify(this.props.notificationData));
        this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
        this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);    
        //this.getCommetList();
    }

    componentDidMount = async() => {
        //console.log('notificationData  Data = ' + JSON.stringify(this.props));
        if (this.props.notificationData !== null) {
             if (!this.props.notificationData.text.includes('high-fived')) {
                 this.isAutoScrollToBottom = true;
            }
        }
        await this.getCommetList();
    };

   // componentWillReceiveProps()

    // shouldComponentUpdate(nextProps, nextState) {
    //     // if (this.state.data && (this.state.data.length !== nextState.data.length)) {
    //     //     return true;
    //     // } else {
    //         return this.props !== nextProps;
    //     // }
    // }

    componentWillUnmount() {
        this.chnageIsResplyReset();
        this.props.clearCommentList();
        this.keyboardDidShowListener.remove();
        this.keyboardDidHideListener.remove();
      }
    
     keyboardDidShow() {
        // if (this.scrollView !== null) {
        //     try {
        //         this.scrollView.scrollToEnd({ animated: true });
        //     } catch (e) {
        //         console.log(e);
        //     }
        // }
      }
    
      keyboardDidHide() {
      }

    handleClickOnHiFi = (item) => {
        const { isHiFive, totalHiFive } = item;
        const updateBody = item;
        if (isHiFive) {
            updateBody.isHiFive = !isHiFive;
            updateBody.totalHiFive = totalHiFive - 1;
        } else {
            updateBody.isHiFive = !isHiFive;
            updateBody.totalHiFive = totalHiFive + 1;
        }
        this.props.addHifiOnComment(item.commentIdentity, null, updateBody);
    };

    handleClickNestedreplay = (item, argMemberIdentity, argMemberName) => {
        //console.log('handleClickNestedreplay==', item);
        //TagTypeValue
        const obj = {
            TagIndex: 0,
            TagMapIdentity: item.memberIdentity,
            TagName: item.memberName,
            TagTypeId: 3
           };

        this.setState({
            TagTypeValue: [obj],
            commentBody: `@${item.memberName} `,
            nestedReplayObj: {
                isNestedReplay: true,
                Membername: argMemberName,
                CommentIdentity: item.commentIdentity,
                MemberIdentity: argMemberIdentity,
                comment: item,
             }
        });
    };

    getCommetList = () => {
        this.props.getCommentsData(this.state.pageForComments, this.state.pageSize, this.props.postData.postIdentity, null, this.scrollView);
        this.forceUpdate();
    };

    onBackArrowPressed = () => {
        if (this.state.data && this.state.data.length > 0) {
            this.setState({ data: [] });
            this.forceUpdate();
        } else {
        if (this.props.callbackFunction != null) {
            this.props.callbackFunction(true);
        }
        Actions.pop();
        }
        //Actions.pop({refresh: {test:true}})
    };

    onOptionMenuClick = () => {
        //alert('on Done Click');
    };
    parentUpdate = () => {
        //this.forceUpdate();
    };

    renderBodyOfApp() {
        return (
        <Post 
        onRef={ref => (this.child = ref)}
        post={this.props.postData}
        />
        );
    }

    chnageIsResplyReset = () => {
        this.setState({ 
            nestedReplayObj: { 
                isNestedReplay: false,
                Membername: '',
                CommentIdentity: '',
                MemberIdentity: '',
                comment: {},
             }
        });
    };

    onReplayCancel = () => this.chnageIsResplyReset();

    onPreviousComments = async(pageIndex) => {
        //const page = await this.state.pageForComments + 1;
        const page = await pageIndex - 1;
        await this.setState({ pageForComments: page });
        await this.getCommetList();
        //this.forceUpdate();
    };

    onSendMessage = () => {
        if (this.state.commentBody !== '' && this.state.commentBody.replace(/\s+/, '').length > 0) {
            if (this.state.nestedReplayObj.isNestedReplay) {
                this.chnageIsResplyReset();
                this.isScrollAble = true;
                this.props.saveCommentReply(this.state.commentBody, this.state.nestedReplayObj, this.props.postData.postIdentity, this.scrollView, this.state.TagTypeValue);
            } else {
            this.isScrollAble = true;
            this.props.saveComment(this.state.commentBody, null, this.props.postData.postIdentity, this.scrollView, this.state.TagTypeValue);
            }
            const { postTotalComments } = this.props.postData;
            this.state = {
                post: this.props.postData
            };
            this.setState({ commentBody: '' });
            this.state.post.postTotalComments = (postTotalComments + 1);
            this.props.UpdateCommentCount(this.state.post);
            const count = postTotalComments + 1;
            this.child.method(count);
        } else {
            showToast('Please Enter Text');
        }
    }

    renderReplayUser = (memberName) => {
        return (
            <View 
            style={styles.nestedReply}
            > 
            <Text
            style={{
            color: 'white',
            textAlign: 'center',
            marginLeft: 8,
            fontSize: 14 }}
            > {'Replying to ' + memberName }</Text>

            <View
            style={styles.nestedReplayCross} 
            >
            <TouchableOpacity
            style={{ justifyContent: 'center', alignSelf: 'center' }}
            onPress={this.onReplayCancel.bind(this)}
            >
            <Image
            style={{ width: 12, height: 12 }}
            source={require('./images/ic_cross.png')}
            />
            </TouchableOpacity>
            </View>
            </View>
        );
    };

    onCommentTextChange = (value) => this.setState({ commentBody: value });
    

    renderSuggestionsRow({ item }, hidePanel) {
           return (
               <TouchableOpacity
               onPress={() => {
                   //this.onSuggestionUserTap(item, hidePanel);
                   this.forceUpdate();
                   }}
               >
                 <Animated.View
                 style={{ flex: 1, flexDirection: 'row' }}
                 >
                 <UserAvatar
                     name={item.postTagName} 
                       src={item.postTagImage} 
                       size={15}
                 />
                 <Text
                 style={{ fontSize: 14, color: '#000', marginStart: 10 }}
                 >{item.postTagName}
                 </Text>
                 </Animated.View>
               </TouchableOpacity>
             );
     }

    callback(keyword) {
            try {
            if (keyword !== null && keyword.length > 1) {
                if (keyword.includes('@')) {
                    this.getUserSuggestions(keyword.replace('@', ''));
                 } 
                this.forceUpdate();
            } else {
                this.setState({ data: [] });
            }
        } catch(err) {
            console.log(err);
        }
      }


      onSuggestionUserTap(item) {
        this.setState({
           data: [],
           keyword: ''
        });
    
       const comment = this.state.commentBody.slice(0, -(this.state.keyword.length + 1));
       const tagPoition = this.state.TagTypeValue ? this.state.TagTypeValue.length : 0;
       const obj = {
        TagIndex: tagPoition,
        TagMapIdentity: item.postTagMapIdentity,
        TagName: item.postTagName,
        TagTypeId: item.postTagType
       };
       //console.log('tag item', obj);
       if (tagPoition === 0) {
        this.setState({
            TagTypeValue: [obj],
            commentBody: `${comment}@${item.postTagName} `
           });
       } else {
        this.setState({
            TagTypeValue: [...this.state.TagTypeValue, obj],
            commentBody: `${comment}@${item.postTagName} `
           });
       }
     }
          
      getUserSuggestions = (keyword_) => {
        //if (this.state.circleSelctedList.length === 0 && this.state.circleSelctedList.length > 1) {
        //} else {
            //console.log('data oF circle Selected =' + JSON.stringify(this.state.circleSelctedList[0]));
        const request = {
            SearchTerm: keyword_,
            Id: this.props.postData.postMapIdentity
        };
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url: SEARCH_USERNAME_BYPOST,
            data: request,
            headers: {
                Authorization: `Bearer ${data}`
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           //console.log('getUserSuggestions==', response);
           if (response.status === 200) {
                this.setState({
                   keyword: keyword_,
                   data: response.data.data
             });
             this.forceUpdate();
          }
        })
        .catch((error) => {
           console.log(error);
        });
        }).catch(() => {
            console.log('Access Toke Error');
        });    
   // }
};

    renderBottomUi() {
        return (
            <Animated.View 
            style={{ flex: 1, flexDirection: 'column' }}
            >
            { this.state.nestedReplayObj.isNestedReplay ?
            this.renderReplayUser(this.state.nestedReplayObj.Membername)
             : null }
            
            <Animated.View 
            style={{ flexDirection: 'row' }}
            >
            <CommentUserTagInput
            placeholder="comment"
            suggestionsPanelStyle={{ backgroundColor: '#fff', marginLeft: 20 }}
            loadingComponent={() => <View style={{ justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator /></View>}
            textInputMinHeight={140}
            textInputMaxHeight={140}
            trigger={'@'}
            textInputStyle={styles.textInput}
            triggerLocation={'anywhere'} // 'new-word-only', 'anywhere'
            value={this.state.commentBody}
            onChangeText={(value) => this.onCommentTextChange(value)}
            triggerCallback={this.callback.bind(this)}
            renderSuggestionsRow={this.renderSuggestionsRow.bind(this)}
            suggestionsData={this.state.data} // array of objects
            keyExtractor={(item, index) => index.toString()}
            suggestionRowHeight={20}
            horizontal={false} // defaut is true, change the orientation of the list
            MaxVisibleRowCount={5} // this is required if horizontal={false}  
            />
            {/* <TextInput
                style={styles.textInput}
                placeholder={'comment'}
                returnKeyType='send'
                value={this.state.commentBody}
                onChangeText={(value) => this.setState({ commentBody: value })}
                underlineColorAndroid={'transparent'}
            /> */}
      
                <TouchableOpacity
                  style={styles.button}
                  onPress={this.onSendMessage.bind(this)} 
                >
                <Image
                source={require('./../components/images/sendEnabled.png')}
                />
                </TouchableOpacity>
                </Animated.View>
            </Animated.View>
          );
    }

    renderPreviousComments() {
        if (this.props.commentsList !== null && this.props.commentsList.length > 0 && this.props.commentsList[0].currentPageIndex > 1) {
           // if ((this.props.commentsList.length % 10) === 0 && this.props.commentsList.length > 0) {
                return (
                    <View
                    style={{ width: '100%', height: 30, backgroundColor: 'gray', justifyContent: 'center', alignItems: 'center' }}
                    >
                    <TouchableOpacity
                    style={{ justifyContent: 'center', alignItems: 'center', padding: 3 }}
                    onPress={this.onPreviousComments.bind(this, this.props.commentsList[0].currentPageIndex)}
                    >
                    <Text 
                    style={{ color: 'black', fontSize: 14, justifyContent: 'center', alignItems: 'center' }}
                    > View Previous Comments </Text>
                    </TouchableOpacity>
                    </View>
                );
           // }
        }
    }

    renderPostData() {
        return (
            <Animated.View style={styles.body}>
            <ScrollView 
            ref={(scrollref) => { this.scrollView = scrollref; }}
            style={styles.container}
            showsVerticalScrollIndicator={false}
            //scrollEnabled={scrollEnabled}
            nestedScrollEnabled={true}
            onContentSizeChange={(contentWidth, contentHeight) => {
                // Save the content height in state
                this.setState({ screenHeight: contentHeight }); 
                if (this.isScrollAble) {
                    this.isScrollAble = false;  
                this.scrollView.scrollTo({ y: contentHeight });
                }
                if (this.isAutoScrollToBottom) {
                    this.scrollView.scrollTo({ y: contentHeight });
                    clearTimeout(this.timeout);
                    this.timeout = setTimeout(() => {
                    this.isAutoScrollToBottom = false;
                    }, 1000);
                }
            }}
            >
            {this.renderBodyOfApp()}

            {this.renderPreviousComments()}
            
            <FlatList
                style={styles.commentList}
                contentContainerStyle={styles.commentContent}
                data={this.props.commentsList}
                extraData={this.props}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => (
                    <MessageRow
                    message={item}
                    handleClickOnHiFi={this.handleClickOnHiFi}
                    handleClickNestedreplay={this.handleClickNestedreplay}
                    />
                )}
            />
            </ScrollView>
            </Animated.View>
        );
    }

    renderUserTagList() {
        return (
            <Animated.View
            style={styles.body}
            >
            <FlatList
            keyboardShouldPersistTaps={'always'}
            enableEmptySections={false}
            data={this.state.data}
            extraData={this.state}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
                <TouchableOpacity
                onPress={() => {
                    this.onSuggestionUserTap(item);
                    }}
                >
                    <Animated.View
                    style={{ flex: 1, flexDirection: 'row', padding: 10 }}
                    >
                    <UserAvatar
                        name={item.postTagName}
                        src={item.postTagImage}
                        size={35}
                    />
                    <Text
                    style={{ fontSize: 18, color: '#000', marginStart: 13, marginEnd: 5 }}
                    numberOfLines={1}
                    >{item.postTagName}
                    </Text>
                    </Animated.View>
                </TouchableOpacity>
                )}
            />
            </Animated.View>
        );
    }
    
    render() {
        return (
            <Animated.View
             style={{ flex: 1 }}
            >
                <Spinner
                    visible={this.props.isLoading}
                    textContent={''}
                    textStyle={AppStyle.spinnerTextStyle} 
                />

            <Animated.View 
            style={{ height: 55, backgroundColor: 'white', elevation: 3 }}
            >
             <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title={this.props.postData.postMapName}
                rightButton=''
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
             />
            </Animated.View>
            {(this.state.data && this.state.data.length > 0)
            ?
            this.renderUserTagList()
            :
            this.renderPostData()
            }

            <View 
            style={[styles.bottomBar,
            { height: (this.state.nestedReplayObj.isNestedReplay ? 90 : 60) }]}
            >
                {this.renderBottomUi()}
            </View>


            </Animated.View>

        );
    }
}

const styles = {
    container: {
       flex: 1,
        paddingTop: (Platform.OS === 'ios') ? 20 : 0,
      },
      body: {
        flex: 1,
      },
      textInput: {
        flex: 1,
        backgroundColor: '#e5e5e5',
        height: 40,
        margin: 10,
        borderRadius: 20,
        paddingLeft: 15,
        paddingEnd: 15,
      },
      button: {
        flexShrink: 0,
        width: 40,
        height: 40,
        marginTop: 10,
        marginRight: 10,
        marginBottom: 10,
        alignItems: 'center',
        justifyContent: 'center'
      },
      MainContainer:
      {
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          paddingTop: (Platform.OS === 'ios') ? 20 : 0
      },
      bottomBar: {
        backgroundColor: 'white',
        borderTopWidth: 0.5,
        borderColor: '#e5e5e5'
      },
      bottomView: {
        width: '100%', 
        height: 50, 
        backgroundColor: '#FF9800', 
        justifyContent: 'center', 
        alignItems: 'center',
        position: 'absolute',
        bottom: 0
      },
      commentList: {
        display: 'flex',
        marginTop: 3,
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '#eeeeee'
      },
      commentContent: {
        flexGrow: 1,
        justifyContent: 'center'
      },
      nestedReply: {
          width: '100%',
          height: 30,
            flexDirection: 'row',
            backgroundColor: 'black',
            padding: 5
      },
      nestedReplayCross: {
        flex: 1,
        justifyContent: 'center',
        paddingLeft: 140
      }

  };
  
const mapStateToProps = (state) => {
    return (
        {
            commentsList: state.postDetail.commentsList,
            isLoading: state.postDetail.isLoading,
            loadAgain: state.postDetail.loadAgain,
            postDetailObj: state.postDetail.postDetailObj,
        }
    );
};

// const mapDispatchToProps = {
//     getComments,
//     saveComment
// };

export default connect(mapStateToProps, 
    { getCommentsData, saveComment, saveCommentReply, addHifiOnComment, UpdateCommentCount, getPostDetail, removePostDetailObj, clearCommentList })(PostDetail);
