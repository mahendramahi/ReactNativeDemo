import React from 'react';
import { Text, View, Image } from 'react-native';

const NoDataView = () => {
    const { textStyle, viewStyle } = styles;
    return (
        <View style={viewStyle}>
        <Image style={{ width: 120, height: 120 }} source={require('./../images/no_message_icon.png')} />
        <Text>No Data Found</Text>
        </View>
    );
};

const styles = {
    viewStyle: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        elevation: 2,
        position: 'relative'
    },
    textStyle: {
        fontSize: 20
    }
};

// Make this component available to other parts of the app
export default NoDataView;
