import React from 'react';
import { View } from 'react-native';


const TriangleShape = (props) => {
    return (
        <View style={[styles.triangle, props.style]} />
    );
};

const styles = {
    triangle: {
        width: 0,
        height: 0,
        justifyContent: 'center',
        marginLeft: 8,
        marginTop: 3,
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderLeftWidth: 7,
        borderRightWidth: 7,
        borderBottomWidth: 10,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderBottomColor: 'gray'
      }
};

export { TriangleShape };
