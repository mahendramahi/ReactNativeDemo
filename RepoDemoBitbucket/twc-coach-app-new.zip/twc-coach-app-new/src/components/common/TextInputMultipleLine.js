import React from 'react';
import { TextInput } from 'react-native';

const TextInputMultipleLine = 
({ style, value, onChangeText, placeholder, underlineColorAndroid, multiline, numberOfLines }) => {
    return (
            <TextInput 
                placeholder={placeholder}
                autoCorrect={false}
                style={style}
                value={value}
                multiline={multiline}
                numberOfLines={numberOfLines}
                onChangeText={onChangeText}
                underlineColorAndroid={underlineColorAndroid}
            />
    );
};

export { TextInputMultipleLine };
