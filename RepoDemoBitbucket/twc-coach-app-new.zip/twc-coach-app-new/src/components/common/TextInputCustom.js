import React from 'react';
import { TextInput } from 'react-native';

const TextInputCustom = 
({ style, value, onChangeText, placeholder, secureTextEntry, underlineColorAndroid }) => {
    return (
            <TextInput 
                placeholder={placeholder}
                secureTextEntry={secureTextEntry}
                autoCorrect={false}
                style={style}
                value={value}
                onChangeText={onChangeText}
                underlineColorAndroid={underlineColorAndroid}
            />
    );
};

export { TextInputCustom };
