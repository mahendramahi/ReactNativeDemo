import React from 'react';
import { Image, TouchableOpacity } from 'react-native';
import TouchableDebounce from '../../ThirdParty/TouchableDebounce';


const FloatingButton = ({ onPress }) => {
    return (
      
        <TouchableOpacity
        activeOpacity={0.1}
        onPress={() => onPress()}
        style={styles.fab}
        >
        <Image 
          source={
                require('../images/createPostButton.png') 
            } 
           style={styles.fabImage} 
        />
        </TouchableOpacity>
    );
};

const styles = {
fab: {
    zIndex: 5,
    position: 'absolute',
    width: 55,
    height: 55,
    alignItems: 'center',
    justifyContent: 'center',
    right: 15,
    bottom: 10, 
    borderRadius: 30, 
    elevation: 8 
  },
  fabImage: {
    resizeMode: 'contain',
    width: 55,
    height: 55,
  }
};

export { FloatingButton };
