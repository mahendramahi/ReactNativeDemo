import React from 'react';
import { TouchableOpacity, Image, Text, View } from 'react-native';

const ToolBarWithBackArrow = ({ onPress, title, rightButton, 
  onRightButtonClick, hideCrossIcon }) => {
    return (
        <View style={styles.main}>
        <TouchableOpacity 
        style={styles.imageContainer}
        activeOpacity={0.8}
        onPress={() => onPress()}
        >
        <Image 
        source={require('../images/backIcon.png')} 
        />  
        </TouchableOpacity>
        <View 
        style={styles.titleContainer} 
        >
        <Text 
        style={styles.titleText}
        >
        { title }
        </Text>
        </View>
        <View 
        style={{ justifyContent: 'flex-end' }} 
        >
        { hideCrossIcon === true
        ?
        <Text 
        style={styles.rightButton}
        onPress={() => onRightButtonClick()}
        > { rightButton }
        </Text>
        :  
        <Image 
        style={{ width: 20, height: 20 }}
        onPress={() => onRightButtonClick()}
        source={require('../images/ic_cross_black.png')}
        />
        }
        </View>
        </View>
    );
};

const styles = {
main: {
    flex: 1,
    marginLeft: 10,
    marginRight: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  imageContainer: {
    width: 10,
    height: 10,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center' 
  },
  titleContainer: {
    flex: 1,
    justifyContent: 'center',
    alignSelf: 'center'
  },
  titleText: {
    fontSize: 20,
    fontWeight: '900',
    fontStyle: 'normal',
    marginLeft: 14,
    justifyContent: 'center',
    color: '#313131'
  },
  rightButton: {
    fontSize: 16,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#22a1a1',
  }
};

export default ToolBarWithBackArrow;
