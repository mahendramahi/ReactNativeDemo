import React from 'react';
import { View, Text, TouchableHighlight, TouchableOpacity } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Card, CardSection } from '../common';
 import UserAvatar from '../../ThirdParty/UserAvatar';

 const isEmpty = (obj) => {
    return (Object.getOwnPropertyNames(obj).length === 0);
  };

const renderMemebers = (countOfMembers) => {
    if (countOfMembers > 1) {
        return (
            <Text style={styles.circlepost}>{countOfMembers} members</Text>
        );
    } else {
        return (
            <Text style={styles.circlepost}>{countOfMembers} member</Text>
        );
    }
};

const CircleJoinBox = ({ circleName, circleItem, circleImage, circleMembers }) => {
    let countOfMembers = 0;
    if (!isEmpty(circleMembers)) {
        countOfMembers = circleMembers.length;
    }
    return (
        <TouchableOpacity
        onPress={() => {
        Actions.circleBase({ circleObj: circleItem }); 
        }}
        >
        <Card>
            <CardSection>
                <View style={styles.imageroundx}>
                    <UserAvatar 
                        name={circleName} 
                        src={circleImage} 
                        size={35}
                    />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{circleName}</Text>
                    {renderMemebers(countOfMembers)}
                </View>

                <View>
                <TouchableHighlight
                    style={styles.selectedCircleBG}
                    underlayColor='#fff'
                    // onPress={this.onSelectCircles.bind(this)}
                >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 4 }}>
                <Text style={{ fontSize: 14 }}> join </Text>   
                {/* <Image style={{ width: 10, height: 10, marginLeft: 5, justifyContent: 'center' }} 
                source={require('../components/images/ic_down_arrow.png')} /> */}
                </View>
                </TouchableHighlight>
                </View>
                {/* <Image 
                    style={styles.arrowright} 
                    source={require('./images/arrowright.png')} 
                /> */}
            </CardSection>
        </Card>
        </TouchableOpacity>
    );
};

const styles = {
    imageroundx: {
        width: 40,
        height: 40,
        padding: 0,
        borderRadius: 100,
        overflow: 'hidden',
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        alignContent: 'center',
        marginLeft: 5,
        marginTop: 7,
        marginRight: 10
      },
      selectedCircleBG: {
        marginTop: 4,
        padding: 2,
        backgroundColor: '#fff',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#979797'
    },
    circlename: {
        fontSize: 16,
        fontWeight: '800',
        padding: 5
    },
    circlepost: {
        fontSize: 14,
        padding: 5
    },
    arrowright: {
        marginLeft: 'auto',
        marginTop: 35,
        width: 12,
        height: 12,    
    },
};

export default CircleJoinBox;
