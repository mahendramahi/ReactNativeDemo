// import React from 'react';
// import { View, Text } from 'react-native';

// export const OfflineSign = () => {
//     return (
//       <View
//       style={{ backgroundColor: '#b52424',
//       height: 30,
//       justifyContent: 'center',
//       alignItems: 'center',
//       flexDirection: 'row',
//       width: 40,
//       position: 'absolute',
//       top: 30 }}
//       >
//         <Text
//         style={{ color: '#fff' }}
//         >
//         No Internet Connection
//         </Text>
//       </View>
//     );
//   };
