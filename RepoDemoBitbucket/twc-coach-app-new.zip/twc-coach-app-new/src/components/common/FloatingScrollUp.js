import React from 'react';
import { Image, TouchableOpacity } from 'react-native';

const FloatingScrollUp = ({ onPress }) => {
    return (
      
        <TouchableOpacity
        activeOpacity={0.1}
        onPress={() => onPress()}
        style={styles.fab}
        >
        <Image 
          source={
                require('../images/ic_down.png') 
            } 
           style={styles.fabImage} 
        />
        </TouchableOpacity>
    );
};

const styles = {
fab: {
    zIndex: 5,
    position: 'absolute',
    width: 35,
    height: 35,
    alignItems: 'center',
    justifyContent: 'center',
    right: 26,
    bottom: 80, 
    borderRadius: 30, 
    elevation: 5 
  },
  fabImage: {
    resizeMode: 'contain',
    width: 35,
    height: 35,
  }
};

export { FloatingScrollUp };
