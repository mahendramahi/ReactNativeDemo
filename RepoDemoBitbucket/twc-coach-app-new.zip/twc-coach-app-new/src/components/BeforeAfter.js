import React, {
    Component
} from 'react';
import {
    View,
    Image,
    TouchableOpacity,
    Text,
    Platform,
    PermissionsAndroid
} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import { Container,
    Header,
    Footer,
    Content } from 'native-base';
import { Actions } from 'react-native-router-flux';
import ImagePicker from 'react-native-image-picker';
import ViewShot from 'react-native-view-shot';
import ToolBarWithBackArrow from '../components/common/ToolBarWithBackArrow';
import { KEY_TAKE_PHOTO, KEY_CHOOSE_FROM_LIBRARY } from '../constant/string';

export default class BeforeAfter extends Component {

    constructor(props) {
        super(props);
        this.state = {
            beforeImageObj: '',
            afterImageObj: '',
            loading: false
        };
    }


    onOptionMenuClick = () => {
        Actions.pop();
    }

    onBackArrowPressed = () => {
        Actions.pop();
    }

    onClickBeforeImage = async() => {
        if (Platform.OS === 'ios') {
        this.getImageFromGallry();
        } else if (Platform.OS === 'android') {
            const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE);
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                this.getImageFromGallry();
                console.log('You can use the camera');
              } else {
                console.log('Camera permission denied');
              }
        }
    }

    onClickAfterImage() {
        this.selectPhotoTapped();
    }

    getImageFromGallry = () => {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
              skipBackup: true
            }
          };
        // Open Image Library:
        ImagePicker.launchImageLibrary(options, (response) => {
          if (response.didCancel) {
            console.log('User cancelled photo picker');
          } else if (response.error) {
            console.log('ImagePicker Error: ', response.error);
          } else if (response.customButton) {
            console.log('User tapped custom button: ', response.customButton);
          } else {
           const source = { uri: response.uri };
            this.setState({ beforeImageObj: source });
            console.log('Response:-' + this.state.beforeImageObj);
          }
        });
    }

    onCaptureScreenShot() {
      this.setState({ loading: true });
      this.refs.viewShot.capture().then(uri => {
          this.setState({ loading: false });
          this.props.callbackFunction(uri);
          Actions.pop();
        }).catch((error) => {
          this.setState({ loading: false });
          console.log(error);
        });
    }

    CheckPermissionForApp = async() => {
      const granted = await PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE, PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE, PermissionsAndroid.PERMISSIONS.CAMERA]);
      console.log(granted, JSON.stringify(granted).includes('denied'));
      if (!JSON.stringify(granted).includes('denied')) {
        const options = {
          quality: 1.0,
          maxWidth: 500,
          maxHeight: 500,
          takePhotoButtonTitle: KEY_TAKE_PHOTO,
          chooseFromLibraryButtonTitle: KEY_CHOOSE_FROM_LIBRARY,
          storageOptions: {
            skipBackup: true
          }
        };
    
        ImagePicker.showImagePicker(options, (response) => {
         // console.log('Response = ', response);

          if (response.didCancel) {
            console.log('User cancelled photo picker');
          } else if (response.error) {
            console.log('ImagePicker Error: ', response.error);
          } else if (response.customButton) {
            console.log('User tapped custom button: ', response.customButton);
          } else {
            const source = { uri: response.uri };
            this.setState({ afterImageObj: source });
          }
        });
      }
  }

    selectPhotoTapped = () => {
      this.CheckPermissionForApp();
      }
      
    isEnableDisableButton = () => {
        if (this.state.beforeImageObj !== '' && this.state.afterImageObj !== '') {
            return false;
        } else {
            return true;
        }
    }

    renderCameraIcon() {
      return (
             <View style={styles.circle} >
                  <Image style={{ alignSelf: 'center' }} source={require('./images/cameraIcon.png')} />
              </View>
      );
  }
    

    renderBeforeAfterImageView() {
        return (
            <ViewShot
            style={styles.container}
            ref='viewShot'
            options={{ format: 'jpg', quality: 0.9, width: 200, height: 200 }}
            >
                    {/* Before */}
                    <TouchableOpacity
                    style={[styles.imageContainer, { marginRight: 1 }]}
                    onPress={this.onClickBeforeImage.bind(this)}
                    >
                    { this.state.beforeImageObj === '' ?
                    this.renderCameraIcon()
                    :
                    <Image 
                    style={[styles.imageContainer, { marginRight: 1, zIndex: 2, alignSelf: 'stretch', width: '100%' }]}
                    source={this.state.beforeImageObj}
                    /> 
                    }
                    <View style={{ zIndex: 8, height: '100%', position: 'absolute', justifyContent: 'flex-end' }}>  
                        <Text style={styles.text}> Before </Text>
                    </View>
                    </TouchableOpacity>

                    {/* End Before */}
                    

                    {/* Start After */}
                    <TouchableOpacity 
                    style={[styles.imageContainer, { marginLeft: 1 }]}
                    onPress={this.onClickAfterImage.bind(this)}
                    >
                     { this.state.afterImageObj === '' ?
                    this.renderCameraIcon()
                    :
                    <Image 
                    style={[styles.imageContainer, { marginLeft: 1, zIndex: 2, alignSelf: 'stretch', width: '100%' }]}
                    source={this.state.afterImageObj}
                    /> 
                    }
                    {/* <View style={styles.circle} >
                    <Image style={{ alignSelf: 'center' }} source={require('./images/cameraIcon.png')} />              
                    </View> */}
                    <View style={{ zIndex: 8, height: '100%', position: 'absolute', justifyContent: 'flex-end' }}>
                        <Text style={styles.text}> After </Text>
                    </View>
                    </TouchableOpacity>
                    {/*End After */}

                    
            </ViewShot>  
        );
    }

    render() {
        return (
           <Container>
            <Header 
                style={{ backgroundColor: '#fff' }}
                androidStatusBarColor='gray' 
            >
            <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title='Before After'
                rightButton=''
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
            />
            </Header> 
            <Content padder >
            <Spinner
                    visible={this.state.loading}
                    textContent={''}
                    textStyle={styles.spinnerTextStyle} 
                    />
           { this.renderBeforeAfterImageView()}
            </Content> 
            <Footer
            style={{ backgroundColor: '#fff' }}
            >
            <TouchableOpacity 
            style={[styles.buttonStyle, { backgroundColor: !this.isEnableDisableButton() ? '#36CABE' : '#e5e5e5' }]}
            disabled={this.isEnableDisableButton()}
            onPress={this.onCaptureScreenShot.bind(this)}
            >
            <Text
            style={styles.textStyle}
            > Share </Text>
            </TouchableOpacity>
            </Footer>
            </Container>
        );
    }
}

const styles = {
    container: {
        flex: 1,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'flex-start' 
    },
    circle: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 80,
        height: 80,
        borderRadius: 100/2,
        backgroundColor: '#fff'
    },
    imageContainer: {
        height: 300,
        width: '50%',
        backgroundColor: '#145f',
        justifyContent: 'center',
        alignItems: 'center' 
    },
    text: {
        zIndex: 12,
        position: 'absolute',
        color: '#fff',
        fontSize: 20,
        alignItems: 'flex-end',
        alignSelf: 'center'
    },
    textStyle: {
        alignSelf: 'center',
        color: '#fff',
        paddingTop: 7,
        paddingBottom: 7,
        fontSize: 18,
        textAlign: 'center',
        paddingLeft: 10,
        paddingRight: 10
    },
    buttonStyle: {
        flex: 1, //expand to fill as much content as you can
        alignSelf: 'stretch',
        marginLeft: 8,
        marginTop: 3,
        marginBottom: 3,
        marginRight: 8,
        justifyContent: 'center',
        backgroundColor: '#36CABE',              //'#36CABE',
        borderRadius: 40,
        borderWidth: 1,
        borderColor: '#fff'
    }
};
