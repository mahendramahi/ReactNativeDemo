import React, { Component } from 'react';
import { View, StyleSheet, Image, Text, TouchableHighlight,
     TouchableOpacity, KeyboardAvoidingView, Platform, PermissionsAndroid,
     ScrollView, Animated, TextInput, ActivityIndicator
     } from 'react-native';
import VideoPlayer from 'react-native-video-controls';
import Config from 'react-native-config';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import { Actions } from 'react-native-router-flux';
import ImagePicker from 'react-native-image-picker';
import { connect } from 'react-redux';
//import ImgToBase64 from 'react-native-image-base64';
import Spinner from 'react-native-loading-spinner-overlay';
import { Container,
    Header,
    Content,
    ActionSheet
     } from 'native-base';
import { DatePickerDialog } from 'react-native-datepicker-dialog';
import moment from 'moment';
//import Menu, { MenuItem, MenuDivider } from 'react-native-material-menu';
import LinkPreview from 'react-native-link-preview';
//import Toast from 'react-native-simple-toast';
import ToolBarWithBackArrow from '../components/common/ToolBarWithBackArrow';
import { TextInputMultipleLine, TriangleShape } from './common';
import { mediaUpload, submitPostWithoutMedia,
     submitUrlMediaPost, submitPollPost, onActionAssigne, newMediaUploadHandler,
     showProgressBar, stopProgressBar, updateListCheckStatus } from '../actions';
import LinkPreviewCard from './LinkPreviewCard';
import { ASK_QUESTION_FOR_POLL, POLL_MANDATORY_OPTION,
    TRANSLOADIT_MEDIA_TYPE_IMAGE, TRANSLOADIT_MEDIA_TYPE_VIDEO, KEY_TAKE_PHOTO } from './../constant/string';
import { showToast, setAsyncStorage,
     getAsyncStorage, showLog, getAsyncStoragemultiple } from './Utility';
import UserAvatar from './../ThirdParty/UserAvatar';
import Transloadit from '../nativeModule/Transloadit';
import MentionsTextInput from '../ThirdParty/MentionsTextInput';
import { axiosWithoutDispatch } from '../helper/ApiHandler';
import { SEARCH_USERNAME_BYPOST, GET_HASHTAGS_LIST } from '../constant/api';
import TouchableDebounce from '../ThirdParty/TouchableDebounce';

const Options = ['1 Day', '1 Week', 'Never', 'Custom', 'Cancel'];

class CreatePost extends React.Component {

    constructor(props) {
        super(props);

        this.onSelectCircle = this.onSelectCircle.bind(this); 
        this.onCallBackBeforeAfter = this.onCallBackBeforeAfter.bind(this); 

        this.animatedValue = new Animated.Value(0);
        this.Array_Value_Index = 2;
        this.actionSheet = null;
        this.menuOption = null;
        this.reqTimer = 0;

        this.state = {
            userImage: '',
            userFirstName: 'TWC',
            userLastName: 'twc',
            UserIdentityId: '',
            editText: '',
            optionDefault0: '',
            optionDefault1: '',
            askQuestions: '',
            circleSelctedList: [],
            isMultiLine: true,
            numberOfLines: 3,
            Alert_Visibility: false,
            ImageSource: null,
            media: {},
            mediaUrl: {},
            FileBase64: '',
            IsHasMedia: false,
            isLoading: false,
            isMediaUrl: false,
            isPollUI: false,
            uriMediaObj: {},
            selectCircleForPost: '',
            selectedCircleName: 'select Circle',
            FileObj: null,
            ViewArray: [],
            PollEndValue: '1 Day',
            DateText: '',
            dateValueHolder: null,
            Disable_Button: false,
            pollOptionArray: [],
            removePoll: 'Remove Poll',
            suggestions: [{ name: 'Mickey Mouse' }, { name: 'Mickey Mouse2' }],
            data: [],
            hashTagValue: [],
            TagTypeValue: [],
            keyword: '',
        };
    }
    
    
    componentWillMount = async () => {
        getAsyncStorage('UserFirstName').then((response) => { this.setState({ userFirstName: response }); })
        .catch(() => { this.setState({ userFirstName: 'twc' }); });
        
        getAsyncStorage('UserLastName').then((response) => { this.setState({ userLastName: response }); })
        .catch(() => { this.setState({ userLastName: '' }); });
        
        getAsyncStorage('UserImage').then((response) => { this.setState({ userImage: response }); })
        .catch(() => { this.setState({ userImage: '' }); });
        getAsyncStorage('UserIdentityId').then((response) => { this.setState({ UserIdentityId: response }); })
        .catch(() => { this.setState({ UserIdentityId: '' }); });
    }

    componentDidMount() {
       this.props.onActionAssigne(this.props.callbackFunction);
    }

     componentWillUnmount() {
    //    // Keyboard.dismiss();
    //     //this.props.callbackFunction(true);
    const data = [];
    this.props.updateListCheckStatus(data);
     }
    

    // shouldComponentUpdate(nextProps, nextState) {
    //     const Diff = this.props !== nextProps;
    //     return Diff;
    // }
     
    setMenuRef = ref => {
        this.menuOption = ref;
    };

    hideMenu = () => {
        this.menuOption.hide();
    };
    
    showMenu = () => {
        this.menuOption.show();
    };

    showOptionMenu() {
        if (this.actionSheet !== null) {
            // Call as you would ActionSheet.show(config, callback)
            this.actionSheet._root.showActionSheet({
                options: Options 
            }, (i) => {
                switch (i) {
                    case 0:
                    return this.setState({ PollEndValue: Options[i] });
                    case 1:
                    return this.setState({ PollEndValue: Options[i] });
                    case 2:
                    return this.setState({ PollEndValue: Options[i] });
                    case 3:
                    return this.datePickerShow();
                    default:
                    return null;
                }
            });
        }
    }

  
  /**
   *  
   */
  datePickerShow = () => {
    let DateHolder = this.state.dateValueHolder;
 
    if (!DateHolder || DateHolder == null) {
        const today = new Date();
        DateHolder = new Date();
      DateHolder.setDate(today.getDate() + 1);
      this.setState({
        dateValueHolder: DateHolder
      });
    }
    //To open the dialog
    this.refs.DatePickerDialog.open({
      date: DateHolder,
      minDate: DateHolder
    });
    this.forceUpdate();
  }

  /**
   * Call back for dob date picked event
   */
   onDatePickedFunction = (date) => {
    const SetDate = moment(date).format('DD-MMM-YYYY');
    this.setState({
      PollEndValue: SetDate
    });
    this.setState({
    removePoll: 'Remove Poll'
    });
    this.forceUpdate();
  }

    onCallBackBeforeAfter(uriFromBack) {
        console.log('onCallBackBeforeAfter');
        if (uriFromBack !== null && uriFromBack !== '') {
        console.log('source FromBefore After ' + uriFromBack);
            const source = { uri: uriFromBack };
            const nameOfFile = uriFromBack.substring(uriFromBack.length - 40, uriFromBack.length);
            Image.getSize(uriFromBack, (width, height) => {
                this.setState({
                    fileWidth: width,
                    fileHeight: height
                });
                this.setState({
                    media: {
                        fileName: nameOfFile,
                        filePath: uriFromBack,
                        fileUri: uriFromBack,
                        fileHeight: height,
                        fileWidth: width
                    }
                });
            });
            this.setState({ 
                ImageSource: source,
                fileUri: uriFromBack,
                IsHasMedia: true
            });
        }
    }

    onBackArrowPressed = () => {
        Actions.pop();
    };

    async onSelectCircle(val) {
        const circleArray = [];
        let CircleIds = '';
        this.setState({ selectCircleForPost: '' });
        this.setState({ ...this.state, 
            circleSelctedList: circleArray });
        val.map(item => {
            circleArray.push(item);
            const id = item.circleIdentity;
            if (CircleIds === '') {
                CircleIds = id;
            } else {
                CircleIds = `${CircleIds},${id}`;
            }
        });
            await this.setState({ ...this.state, circleSelctedList: circleArray, selectCircleForPost: CircleIds });
            if (this.state.circleSelctedList.length > 0) {
                if (this.state.circleSelctedList.length === 1) {
                    this.setState({ selectedCircleName: this.state.circleSelctedList[0].circle_Name });
                } else {
                    this.setState({ selectedCircleName: `${this.state.circleSelctedList.length} Circles Selected` });
                }
            } else {
                this.setState({ selectedCircleName: 'select Circle' });
            }
    }

    onImageCrossClick() {
        this.setState({
            ImageSource: null,
            IsHasMedia: false
        });
    }

    onSelectCircles() {
        Actions.selectCircles({
            callbackFunction: this.onSelectCircle,
        });
    } 

    onClickPoll = () => {
        this.setState({ isPollUI: true });
    };

    onClickBeforeAfter() {
        console.log('click:- onCLickBeforeAfter()');
        Actions.BeforeAfter({
            callbackFunction: this.onCallBackBeforeAfter
        });
    }

    onPreViewCrossListner() {
        this.setState({ isMediaUrl: false });
    }

    onPostTextChange = (value) => {
        this.setState({ editText: value });
        if (value.length === 0) {
            this.setState({
                data: [] 
            });
        }
        if (value.includes('http://') || value.includes('https://') || value.includes('www.')) {
            LinkPreview.getPreview(value)
        .then(data => {
            const dataObj = data;
            if (dataObj.length !== 0) {
                this.setState({ 
                    mediaUrl: dataObj,
                    isMediaUrl: true
                 });
            } else {
                this.setState({
                    isMediaUrl: false
                 });
            }
        });
        }      
    };
    
    newFileUploader(base64String) {
        console.log(base64String);
        const media = this.state.media;
        const postText = this.state.editText;
        this.props.mediaUpload(media, base64String, postText, this.state.selectCircleForPost);
    }

    renderUrlPreview = () => {
        if (this.state.mediaUrl !== null) {
            return ( 
                <LinkPreviewCard
                media={this.state.mediaUrl}
                onPreViewCross={this.onPreViewCrossListner.bind(this)}
                isPostView={false}
                onPress={null}
                />
            );
        }
    };

     savePost = async () => {
        if (this.state.circleSelctedList.length > 0) {
            if (this.state.isPollUI) {
                console.log('Create Post isPollUI-');
                if (this.state.askQuestions.trim() === '') {
                    showToast(ASK_QUESTION_FOR_POLL);
                } else if (this.state.optionDefault0.trim() === '' || this.state.optionDefault1.trim() === '') {
                    showToast(POLL_MANDATORY_OPTION);
                } else {
                console.log('Create Post isPollUI-');
                    const Answers = [];
                    Answers.push(this.state.optionDefault0);
                    Answers.push(this.state.optionDefault1);
                    this.state.pollOptionArray.map(item => {
                            console.log('' + JSON.stringify(item));
                            if (item === '') {
                            } else {
                                Answers.push(item);
                            }  
                        });
                        console.log('answer:-' + await JSON.stringify(Answers));
                        let DayCount = 0;
                        if (this.state.PollEndValue === Options[0]) {
                            DayCount = 1;
                        } else if (this.state.PollEndValue === Options[1]) {
                            DayCount = 7;
                        } else if (this.state.PollEndValue === Options[2]) {
                            DayCount = 0;
                        } else {
                            try {
                            const currentD = new Date();
                            const givenD = new Date(this.state.PollEndValue);
                            const Diff = Math.round((givenD.getTime() - currentD.getTime()) / (1000 * 60 * 60 * 24));
                            // const minutes = Math.round(seconds / 60);
                            // const hours = Math.round(minutes / 60);
                            // const days = Math.round(hours / 24);
                            console.log('Day Count =' + (Diff + 1));
                            DayCount = Diff + 1;
                            } catch (e) {
                                DayCount = 0;
                                console.log(e);
                            }
                        }

                        const contentData = {
                            Answer: await Answers,
                            Days: DayCount,
                            Question: this.state.askQuestions
                        };
                        //console.log('answer:-' + await JSON.stringify(contentData));
                        await this.props.submitPollPost(contentData, this.state.selectCircleForPost);
                }
            } else if (this.state.isMediaUrl) {
                console.log('Create Post isMediaUrl-');
               const postText = this.state.editText;
                    const postMedia = [{
                        Data: this.state.mediaUrl.url,
                        Desc: this.state.mediaUrl.title,
                        FileName: this.state.mediaUrl.images[0],
                        Height: 0,
                        MediaType: 2,
                        Title: this.state.mediaUrl.title,
                        Width: 0
                    }];
                this.props.submitUrlMediaPost(postMedia, postText, this.state.selectCircleForPost, this.state.hashTagValue, this.state.TagTypeValue);
            } else if (this.state.IsHasMedia) {
                const ext = this.state.media.fileName.split('.');
                this.props.showProgressBar();
                this.forceUpdate();
                Transloadit.submitAssembly(Config.TRANSLOADIT_API_KEY, Config.TRANSLOADIT_SECRET_KEY,
                    this.state.media.fileUri, this.state.media.fileName,
                    `.${ext[1]}`, Transloadit.KEY_IMAGE_VIDEO_POST, this.state.media.templateId,
                    (error, response) => {
                        if (response !== null) {
                            const assemblyResponse = JSON.parse(response);
                            console.log('Call Back From Transloadit==' + JSON.stringify(assemblyResponse));
                            if (assemblyResponse.http_code === 200) {
                                if (this.state.media.filetype === 'video') {
                                    this.state.media.fileWidth = assemblyResponse.uploads[0].meta.width;
                                    this.state.media.fileHeight = assemblyResponse.uploads[0].meta.height;
                                    const media = this.state.media;
                                    const postText = this.state.editText;
                                    this.forceUpdate();
                                    //this.props.mediaUpload(media, base64String, postText, this.state.selectCircleForPost);
                                    this.props.newMediaUploadHandler(media, postText, this.state.selectCircleForPost, TRANSLOADIT_MEDIA_TYPE_VIDEO, this.state.hashTagValue, this.state.TagTypeValue);
                                    this.props.stopProgressBar();
                                } else {
                                    const media = this.state.media;
                                    const postText = this.state.editText;
                                    this.forceUpdate();
                                    this.props.newMediaUploadHandler(media, postText, this.state.selectCircleForPost, TRANSLOADIT_MEDIA_TYPE_IMAGE, this.state.hashTagValue, this.state.TagTypeValue);
                                    this.props.stopProgressBar();
                                }
                            } else {
                                this.props.stopProgressBar();
                                showToast(assemblyResponse.message);
                            }
                        } else {
                            this.props.stopProgressBar();
                            console.log('Call Back From Transloadit== error' + JSON.stringify(error));
                            const msg = error.replace('com.transloadit.sdk.exceptions.RequestException', '');
                            showToast(msg);
                        }
                    });
            } else if (this.state.editText === '' || this.state.editText.replace(/\s+/, '').length === 0) {
                    showToast('Please enter text for post');
            } else {
                console.log('isHasMedia Called Start TransloadIt Else Called');
                    const postText = this.state.editText;
                    this.props.submitPostWithoutMedia(postText, this.state.selectCircleForPost, this.state.hashTagValue, this.state.TagTypeValue);
            }
        } else {
            //Transloadit.submitAssembly('hello');
            showToast('Please Select Circle');
        }
    };

    CheckPermissionForApp = async() => {
        const granted = await PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE, PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE, PermissionsAndroid.PERMISSIONS.CAMERA]);
        console.log(granted, JSON.stringify(granted).includes('denied'));
        if (!JSON.stringify(granted).includes('denied')) {
            const options = {
                quality: 1.0,
                maxWidth: 500,
                maxHeight: 500,
                takePhotoButtonTitle: KEY_TAKE_PHOTO,
                chooseFromLibraryButtonTitle: 'Choose Photo from library',
                storageOptions: {
                  skipBackup: true
                },
                customButtons: [
                  { name: 'video', title: 'Take Video' },
                  { name: 'video_library', title: 'Choose Video from library' },
              ]
              };
              const optionsVideo = {
                  storageOptions: {
                      skipBackup: true,
                  },
                  noData: true,
                  mediaType: 'video'
              };
              ImagePicker.showImagePicker(options, (response) => {
                console.log('Response = ', response);
                if (response.didCancel) {
                  console.log('User cancelled photo picker');
                } else if (response.error) {
                  console.log('ImagePicker Error: ', response.error);
                } else if (response.customButton === 'video') {
                  console.log('User tapped custom button: ', response.customButton);
                  ImagePicker.launchCamera(optionsVideo, (responseVideo) => {
                      //do what you want with the video
                      if (responseVideo !== null) {
                      this.videoResponseHandler(responseVideo);
                      }
                  });
                } else if (response.customButton === 'video_library') {
                  ImagePicker.launchImageLibrary(optionsVideo, (responseVideolibrary) => {
                      if (responseVideolibrary !== null) {
                      this.videoResponseHandler(responseVideolibrary);
                      }
                  });
                } else {
                  this.imageResponseHandler(response);
                }
              });
        }
    }
     selectPhotoTapped = () => {
         this.CheckPermissionForApp();
      }

    videoResponseHandler = (responseVideolibrary) => {
        try {
        const source = { uri: responseVideolibrary.uri };
        this.setState({ IsHasMedia: true });
        const lengthIndex = responseVideolibrary.path.length;
        const lastIndexOf = responseVideolibrary.path.lastIndexOf('/');
        const FileNameFromIndex = responseVideolibrary.path.substring(lastIndexOf + 1, lengthIndex);        
        //console.log('fileName ==' + responseVideolibrary.path.substring(responseVideolibrary.path.lastIndexOf('/') + 1, responseVideolibrary.path.length));
        //console.log('fileName ==' + responseVideolibrary.uri.substring(responseVideolibrary.uri.lastIndexOf('/') + 1, responseVideolibrary.uri.length()));

        this.setState({
            media: {
                templateId: Config.TEMPLATE_ID_VIDEO,
                fileName: FileNameFromIndex,
                filePath: responseVideolibrary.path,
                fileData: responseVideolibrary.data,
                timestamp: responseVideolibrary.timestamp,
                fileSize: responseVideolibrary.fileSize,
                fileUri: responseVideolibrary.uri,
                filetype: 'video',
                fileHeight: responseVideolibrary.height,
                fileWidth: responseVideolibrary.width
            }
        });
        this.setState({
          ImageSource: source
        });
    } catch (e) {
        console.log(e);
    }
    }
    imageResponseHandler = (response) => {
        this.setState({
            FileObj: response
          });
        const source = { uri: response.uri };
        this.setState({ IsHasMedia: true });
        //console.log(source);
        this.setState({
            media: {
                templateId: Config.TEMPLATE_ID_IMAGE,
                fileName: response.fileName,
                filePath: response.path,
                fileData: response.data,
                timestamp: response.timestamp,
                fileSize: response.fileSize,
                fileUri: response.uri,
                filetype: response.type,
                fileHeight: response.height,
                fileWidth: response.width
            }
        });

        // You can also display the image using data:
        // let source = { uri: 'data:image/jpeg;base64,' + response.data };
        console.log('Image = ' + source);
        this.setState({
          ImageSource: source
        });
    }


    editPost() {

    }

    deletePost() {

    }

    // onEndPollClick = () => {
    //     console.log('onEndPoll Call');
    //     return (
    //         <Menu
    //          ref={this.setMenuRef}
    //         >
    //         <MenuItem onPress={this.hideMenu}>Menu item 1</MenuItem>
    //         <MenuItem onPress={this.hideMenu}>Menu item 2</MenuItem>
    //         <MenuItem onPress={this.hideMenu} disabled>
    //             Menu item 3
    //         </MenuItem>
    //         <MenuDivider />
    //         <MenuItem onPress={this.hideMenu}>Menu item 4</MenuItem>
    //         </Menu>
    //     );
    // }

    onOptionBoxDelete = (key) => {
        this.state.ViewArray.pop();
        const array = this.state.pollOptionArray;
        array[key] = '';
        this.setState({ pollOptionArray: array });
        this.setState({ ViewArray: this.state.ViewArray });
        this.forceUpdate();
    }

      Add_New_View_Function = () => {
          this.animatedValue.setValue(0);
          let New_Added_View_Value = { Array_Value_Index: this.Array_Value_Index };
          const tempArray = this.state.pollOptionArray;
          tempArray.push('');

          this.setState({ Disable_Button: true, ViewArray: [...this.state.ViewArray, New_Added_View_Value] }, () =>
          {
              Animated.timing(
                  this.animatedValue,
                  {
                      toValue: 1,
                      duration: 400,
                      useNativeDriver: true
                  }
              ).start(() => {
                  this.Array_Value_Index = this.Array_Value_Index + 1;
                  this.setState({ Disable_Button: false });
              }); 
          });              
      }

      renderAskQuestion() {
          return (
              <View >        
                <TextInputMultipleLine
                    placeholder="Ask a question... "
                    underlineColorAndroid='#fff'
                    secureTextEntry={false}
                    style={[styles.input, { marginLeft: 0 }]}
                    value={this.state.askQuestions}
                    onChangeText={(value) => this.setState({ askQuestions: value })}
                    multiline={this.state.isMultiLine}
                    numberOfLines={this.state.numberOfLines}
                />
              </View>
          );
      }

    ShowCalanderForDateSelect() {
        this.showDatePicker();
      }

      renderFixedBoxUI() {
       // let New_Added_View_Value = { Array_Value_Index: this.Array_Value_Index }
          return (
              <View 
              style={{ flexDirection: 'column' }} 
              >
                <View 
                  key={0} 
                  style={[styles.pollBox, { width: '100%' }]}
                >
                 <TextInput
                 onChangeText={(value) => {
                     this.setState({ optionDefault0: value });
                 }}
                 value={this.state.optionDefault0}
                  style={[styles.View_Inside_Text, { flex: 1, height: 36 }]}
                  placeholder={'option 1'} 
                 />
                {/* <Text 
                style={styles.View_Inside_Text} 
                > Option 1 </Text> */}
                </View>
                <View 
                key={1}
                style={[styles.pollBox, { width: '100%', marginTop: 15 }]}
                >
              <TextInput 
               onChangeText={(val) => {
                this.setState({ optionDefault1: val });
                }}
                value={this.state.optionDefault1}
               style={[styles.View_Inside_Text, { flex: 1, height: 36 }]}
                placeholder={'option 2'} 
               />
              </View>
              </View>
          );
      }

      renderAddQuestionBox() {
        return (
            <TouchableOpacity
            disabled={this.state.Disable_Button} 
            onPress={this.Add_New_View_Function}
            style={[styles.pollBox, { width: '100%', marginTop: 15, justifyContent: 'center', padding: 8, borderStyle: 'dashed', borderColor: 'green' }]}
            >
            <Text 
            style={{ justifyContent: 'center', alignSelf: 'center', color: 'green' }}
            > + Add Another Option </Text>
            </TouchableOpacity>
        );
      }

      renderPollBottomView() {
          return (
              <View 
              style={{
                  flex: 1,
                  marginTop: 16,
                  marginBottom: 10,
                  width: '100%', 
                  flexDirection: 'row',
                  }} 
              > 
            <View style={{ justifyContent: 'flex-start', alignItems: 'center', flexDirection: 'row', marginLeft: 10 }}>
            <Text 
            style={{ justifyContent: 'center', fontSize: 14 }}
            onPress={() => console.log('call Poll ends')}
            >Poll Ends </Text>
        
            <TouchableOpacity
                    style={styles.pollBox}
                    underlayColor='#fff'
                    onPress={this.showOptionMenu.bind(this)}
            >
            <View style={{ flexDirection: 'row', padding: 4, width: 85, justifyContent: 'space-between' }}>
            <Text style={{ fontSize: 10 }}>{this.state.PollEndValue}</Text>
            <TriangleShape
            style={styles.triangleDown}
            />
            </View>
                </TouchableOpacity>

        </View>

        <View 
        style={{ 
        width: '74%',
        justifyContent: 'flex-end', 
        alignItems: 'center' }} 
        >
        <Text
        style={{ fontSize: 14 }}
        onPress={() => {
            this.setState({ isPollUI: false });
        }}
        >{this.state.removePoll}</Text>
        </View>

        </View>
        );
      }

      renderPollUI() {
        const AnimationValue = this.animatedValue.interpolate(
            {
                inputRange: [0, 1],
     
                outputRange: [-59, 0] 
            });
     
            let Render_Animated_View = this.state.ViewArray.map((item, key) => {
                if ((key) === this.Array_Value_Index) {
                    return (
                        <Animated.View 
                          key={key} 
                          style={[styles.Animated_View_Style, { opacity: this.animatedValue, transform: [{ translateY: AnimationValue }] }]}
                        >
                            <Text style={styles.View_Inside_Text} > This Is Row { item.Array_Value_Index } </Text>
                        </Animated.View>
                  );
                } else {
                    if (key === (this.state.ViewArray.length - 1)) {
                        return (
                            <View 
                              key={key} 
                              style={[styles.pollBox, { width: '100%', marginTop: 15, flexDirection: 'row', flex: 1 }]}
                            >
                            <TextInput 
                            numberOfLines={1}
                            onChangeText={(value) => {
                                //let Val = this.state.pollOptionArray.indexOf(key);
                                const array = this.state.pollOptionArray;
                                array[key] = value;
                                this.setState({ pollOptionArray: array });
                            }}
                            style={[styles.View_Inside_Text, { width: '80%', height: 35 }]}
                            placeholder={'option ' + (key + 3)} 
                            />
                            <TouchableOpacity 
                                style={{ flex: -1,
                                    justifyContent: 'flex-end', 
                                    alignItems: 'center',
                                    marginStart: 38 }}
                                onPress={this.onOptionBoxDelete.bind(this, key)}
                                >
                                <Image 
                                style={{ alignItems: 'flex-end', width: 26, height: 26, marginBottom: 5, justifyContent: 'flex-start', alignSelf: 'center' }}
                                source={require('../components/images/reset_input_box_icon.png')}
                                />
                                </TouchableOpacity>
                            </View>
                        );  
                    } else {
                        return (
                            <View 
                              key={key} 
                              style={[styles.pollBox, { width: '100%', marginTop: 15, flexDirection: 'row', flex: 1 }]}
                            >
                            <TextInput 
                            numberOfLines={1}
                            onChangeText={(value) => {
                                const array = this.state.pollOptionArray;
                                array[key] = value;
                                this.setState({ pollOptionArray: array });
                            }}
                            style={[styles.View_Inside_Text, { width: '80%', height: 35 }]}
                            placeholder={'option ' + (key + 3)} 
                            />
                             {/* <TouchableOpacity 
                                style={{ flex: -1,
                                    justifyContent: 'flex-end', 
                                    alignItems: 'center' }}
                                onPress={this.onOptionBoxDelete.bind(this)}
                                >
                                <Image 
                                style={{ alignItems: 'flex-end', width: 26, height: 26 }}
                                source={require('../components/images/reset_input_box_icon.png')}/>
                                </TouchableOpacity> */}
                            </View>
                        );  
                    }
                }
            });
     
            return (
                <View style={styles.MainContainer_}>
     
                    <ScrollView>
     
                        <View style={{ flex: 1, padding: 2, margin: 10 }}>
                        {this.renderAskQuestion()}
                        {this.renderFixedBoxUI()}
                        {
                            Render_Animated_View
                        }
                        {this.renderAddQuestionBox()}
                        {this.renderPollBottomView()}
                        </View>
                    </ScrollView>
                </View>
            );
        }

        //   return (
        //     <View style={{ flex: 1, justifyContent: 'center', marginTop: 20, position: 'relative' }}>
        //     <ScrollView 
        //     style={{ flex: 1,
        //         paddingTop: (Platform.OS === 'ios') ? 20 : 0, }}
        //     showsVerticalScrollIndicator={false}
        //     >
        //     </ScrollView>
        //     </View>
        //   );
     // }

     handleDelete = index => {
        const tagsSelected = this.state.tagsSelected;
        tagsSelected.splice(index, 1);
        this.setState({ tagsSelected });
     }

     onSuggestionTap(item, hidePanel) {
         this.setState({
            data: [],
            keyword: ''
         });
        //hidePanel();
        const comment = this.state.editText.slice(0, -(this.state.keyword.length + 1));
        this.setState({
            hashTagValue: [...this.state.hashTagValue, item],
            editText: `${comment}#${item.hashTagName} `
        });
        hidePanel();
      }

      onSuggestionUserTap(item, hidePanel) {
        this.setState({
           data: [],
           keyword: ''
        });
       //();
       const comment = this.state.editText.slice(0, -(this.state.keyword.length + 1));
       const obj = {
        TagIndex: this.state.TagTypeValue.length,
        TagMapIdentity: item.postTagMapIdentity,
        TagName: item.postTagName,
        TagTypeId: item.postTagType
       };
       this.setState({
        TagTypeValue: [...this.state.TagTypeValue, obj],
        editText: `${comment}@${item.postTagName} `
       });
       hidePanel();
     }

     renderSuggestionsRow({ item }, hidePanel) {
         if (item.hasOwnProperty('postTagName')) {
            return (
                <TouchableOpacity
                onPress={() => {
                    this.onSuggestionUserTap(item, hidePanel);
                    this.forceUpdate();
                    }}
                >
                  <Animated.View
                  style={{ flex: 1, flexDirection: 'row' }}
                  >
                  <UserAvatar
                      name={item.postTagName} 
                        src={item.postTagImage} 
                        size={15}
                  />
                  <Text
                  style={{ fontSize: 14, color: '#000', marginStart: 10 }}
                  >{item.postTagName}
                  </Text>
                  </Animated.View>
                </TouchableOpacity>
              );
         } else {
        return (
          <TouchableOpacity
          onPress={() => {
              this.onSuggestionTap(item, hidePanel);
              this.forceUpdate();
              }}
          >
            <View
            style={{ flex: 1 }}
            >
            <Text
            style={{ fontSize: 14, color: '#000' }}
            >{item.hashTagName}
            </Text>
            </View>
          </TouchableOpacity>
        );
       }
      }

      callback(keyword) {
        // if (this.reqTimer) {
        //     console.log('Call Clear Time out');
        //   clearTimeout(this.reqTimer);
        // }
       // this.reqTimer = setTimeout(() => {
            try {
            if (keyword !== null && keyword.length > 1) {
                if (keyword.includes('#')) {
                this.getHashTagSuggestions(keyword.replace('#', ''));
                } else if(this.state.circleSelctedList.length === 1){
                    this.getUserSuggestions(keyword.replace('@', ''));
                }
                this.forceUpdate();
          //this.getUserSuggestions(keyword.replace('@', ''));
            } else {
            }
        } catch(err) {

        }
      }

    getHashTagSuggestions = (keyword_) => {
        console.log('Call Suggestion Api');
        const request = {
            SearchTerm: keyword_,
        };
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url: GET_HASHTAGS_LIST,
            data: request,
            headers: {
                Authorization: `Bearer ${data}`
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
                 this.setState({
                    keyword: keyword_,
                    data: response.data.data
              });
              this.forceUpdate();
           }
        })
        .catch((error) => {
           console.log(error);
        });
        }).catch(() => {
            console.log('Access Toke Error');
        });    
        };
      
    getUserSuggestions = (keyword_) => {
        //if (this.state.circleSelctedList.length === 0 && this.state.circleSelctedList.length > 1) {
        //} else {
            //console.log('data oF circle Selected =' + JSON.stringify(this.state.circleSelctedList[0]));
        const request = {
            SearchTerm: keyword_,
            Id: this.state.circleSelctedList[0].circleIdentity
        };
    getAsyncStorage('token').then((data) => {
        const route = {
            method: 'POST',
            url: SEARCH_USERNAME_BYPOST,
            data: request,
            headers: {
                Authorization: `Bearer ${data}`
            },
            json: true
        };
       axiosWithoutDispatch(route)
       .then((response) => {
           if (response.status === 200) {
                this.setState({
                   keyword: keyword_,
                   data: response.data.data
             });
             this.forceUpdate();
          }
        })
        .catch((error) => {
           console.log(error);
        });
        }).catch(() => {
            console.log('Access Toke Error');
        });    
   // }
};

      renderPostText() {
          return ( 
            <View 
            style={{ position: 'absolute', zIndex: 999, marginTop: 65 }}
            >
            <MentionsTextInput
            placeholder="Share something with your circle"
            suggestionsPanelStyle={{ backgroundColor: '#fff', marginLeft: 20 }}
            loadingComponent={() => <View style={{ justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator /></View>}
            textInputMinHeight={80}
            textInputMaxHeight={80}
           // trigger={'#'}
            textInputStyle={styles.input}
            triggerLocation={'anywhere'} // 'new-word-only', 'anywhere'
            value={this.state.editText}
            onChangeText={(value) => this.onPostTextChange(value)}
            triggerCallback={this.callback.bind(this)}
            renderSuggestionsRow={this.renderSuggestionsRow.bind(this)}
            suggestionsData={this.state.data} // array of objects
            keyExtractor={(item, index) => index.toString()}
            suggestionRowHeight={10}
            horizontal={false} // defaut is true, change the orientation of the list
            MaxVisibleRowCount={5} // this is required if horizontal={false}    
            />
        {
        this.state.isMediaUrl ?
            this.renderUrlPreview()
            :
            null
        }
        </View>
        );
      }

    renderImageHoldeUI() {
        if (this.state.media.filetype === 'video') {
            return (
                <View 
                style={{ flex: this.state.isMediaUrl ? 1.7 : 2,
                backgroundColor: '#e5e5e5',
                alignItems: 'center',
                position: 'relative',
                zIndex: -1
                }}
                >
                    <TouchableOpacity style={{ marginTop: 10 }}>
                    <VideoPlayer
                    ref={(ref) => {
                            this.player = ref;
                        }}
                        showOnStart={true}
                        paused={true}
                        resizeMode={'cover'}
                        style={{
                            flex: 1,   
                            marginBottom: 10,
                            justifyContent: 'center',
                            paddingBottom: 30,
                            marginLeft: -5,
                            marginRight: -20,
                        }}
                        volume={0}
                        source={{ uri: this.state.media.filePath }}
                        //navigator={null}
                        toggleResizeModeOnFullscreen={false}
                        controlTimeout={2000}
                    />
                    {/* <Image 
                    style={{ alignItems: 'center', width: 200, height: 260, resizeMode: 'contain' }}
                    source={this.state.ImageSource}
                    />                   */}
                    </TouchableOpacity>
                    <TouchableOpacity 
                    style={{ position: 'absolute', justifyContent: 'flex-start' }}
                    onPress={this.onImageCrossClick.bind(this)}
                    >
                    <Image 
                    style={{ alignItems: 'flex-start', width: 26, height: 26 }}
                    source={require('../components/images/reset_input_box_icon.png')}/>
                    </TouchableOpacity>
                   
                </View>
            );
        } else {
        return (
            <View 
            style={{ 
            flex: this.state.isMediaUrl ? 1.7 : 2,
            backgroundColor: '#e5e5e5',
            alignItems: 'center',
            position: 'relative',
            zIndex: -1
            }}
            >
                <TouchableOpacity style={{ marginTop: 10 }}>
                <Image 
                style={{ alignItems: 'center', width: 200, height: 260, resizeMode: 'contain' }}
                source={this.state.ImageSource}
                />                  
                </TouchableOpacity>
                <TouchableOpacity 
                style={{ position: 'absolute', justifyContent: 'flex-start' }}
                onPress={this.onImageCrossClick.bind(this)}
                >
                <Image 
                style={{ alignItems: 'flex-start', width: 26, height: 26 }}
                source={require('../components/images/reset_input_box_icon.png')}/>
                </TouchableOpacity>
               
            </View>
        );
        }
    }

    renderCameraOptionUI() {
        if (this.state.isPollUI) {
            return null;
        } else {
            return (
                <View
                    style={{
                        flex: this.state.isMediaUrl ? 1.7 : 2,
                        backgroundColor: '#e5e5e5', 
                        flexDirection: 'row', 
                        justifyContent: 'space-around',
                        position: 'relative',
                        zIndex: -999
                    }}
                >
                    {/* Photo/ Video */}
                    {/* <Throttle time='700' handler='onPress'> */}
                    <TouchableOpacity
                    style={styles.card}
                    onPress={this.selectPhotoTapped.bind(this)}
                    >
                    <View style={styles.innerCard}>
                    <Image style={{ alignSelf: 'center' }} source={require('./images/cameraIcon.png')}/>
                    <Text 
                    style={styles.cardText}
                    >Image / Video</Text>
                    </View>                    
                    </TouchableOpacity>
                    {/* </Throttle> */}
                    {/* End Photo/ Video */}

                    {/* Start Before/ After */}
                    {/* <Throttle time='700' handler='onPress'> */}
                    <TouchableDebounce
                    style={styles.card}
                    onPress={this.onClickBeforeAfter.bind(this)}
                    >
                    <View style={styles.innerCard}>
                    <Image style={{ alignSelf: 'center' }} source={require('./images/beforeAfterIcon.png')}/>
                    <Text 
                    style={styles.cardText}
                    >Before / After</Text>
                    </View>                    
                    </TouchableDebounce>
                    {/* </Throttle> */}
                    {/*End Before/ After */}

                    
                    {/* Start Poll */}
                    <TouchableOpacity 
                    style={styles.card}
                    onPress={this.onClickPoll.bind(this)}
                    >
                    <View style={styles.innerCard}>
                    <Image style={{ alignSelf: 'center' }} source={require('./images/pollIcon.png')} />
                    <Text 
                    style={styles.cardText}
                    >Poll</Text>
                    </View>                    
                    </TouchableOpacity>
                    {/*End Poll */}
                    
                </View>  

            );
       }
    }

    renderSelectedCircle() {
        return (
        <TouchableOpacity
            style={styles.selectedCircleBG}
            underlayColor='#fff'
            onPress={this.onSelectCircles.bind(this)}
        >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 4 }}>
        <Text style={{ fontSize: 9 }}> {this.state.selectedCircleName}</Text>
        <TriangleShape
        style={styles.triangleDown}
        />

        {/* <Image style={{ width: 10, height: 10, marginLeft: 5, justifyContent: 'center' }} 
        source={require('../components/images/ic_down_arrow.png')} /> */}
        </View>
        </TouchableOpacity>
        );
    }

    renderSelectedCirclesName() {
        //console.log('props', this.proop);
        
        if (this.props.circleSelctedList == null) {
            return (
                <Text style={{ fontSize: 8 }}> select Circle</Text>
            );
        } else if (this.props.circleSelctedList.length === 1) {
            return (
                <Text style={{ fontSize: 8 }}> {this.props.circleSelctedList[0]} Circle</Text>
            );
        }
    }

    renderContent() {
        return (
            <KeyboardAvoidingView   
            style={styles.container}
            // behavior='padding'
            behavior={(Platform.OS === 'ios') ? 'padding' : null}
            keyboardVerticalOffset={Platform.select({ ios: 0, android: 500 })}
            enabled
            > 
                   <Spinner
                    visible={this.props.loading}
                    textContent={'Please Wait...'}
                    textStyle={styles.spinnerTextStyle} 
                    />

                <View
                style={{
                flex: (this.state.data && this.state.data.length > 1) ? 1.7 : 1,
                backgroundColor: '#fff',
                flexDirection: 'column',
                justifyContent: 'flex-start'
                }}
                >
                {/* Avtar view */}
                    <View style={{ paddingTop: 20, paddingLeft: 20, flexDirection: 'row' }}>
                    { (this.state.userImage !== null && !this.state.userImage.includes('initial-image.png')) 
                        ? 
                        <UserAvatar 
                        name={this.state.userFirstName} 
                        src={this.state.userImage} 
                        size={43}
                        />
                        :
                        <UserAvatar 
                        name={this.state.userFirstName}
                        src={''}
                        size={43}
                        />
                        }
                        {/* <Image style={styles.userImage} source={{ uri: this.state.userImage }} /> */}
                        {/* Name view */}
                        <View style={{ flexDirection: 'column', paddingLeft: 10 }}>
                        <Text 
                        style={{ fontSize: 13, fontWeight: 'bold', fontStyle: 'normal', color: '#000000' }}
                        >
                        {`${this.state.userFirstName} ${this.state.userLastName}`}
                        </Text>
                        {this.renderSelectedCircle()}
                        </View>
                        {/* Name view */}
                    </View>
                    {/* Avtar view */}
                    { this.state.isPollUI ?
                    this.renderPollUI() :
                    this.renderPostText() }
                </View>  
                { this.state.ImageSource === null ? 
                this.renderCameraOptionUI() :
                this.renderImageHoldeUI() }
                <DatePickerDialog ref="DatePickerDialog" onDatePicked={this.onDatePickedFunction.bind(this)} />
            </KeyboardAvoidingView>
        );
    }
    
    render() {
        return (
            <KeyboardAwareScrollView 
            style={{ backgroundColor: '#0000' }}
            resetScrollToCoords={{ x: 0, y: 0 }}
            scrollEnabled={false}
            >
            <Container>
            <Header 
                style={{ backgroundColor: '#fff', elevation: 8 }}
                androidStatusBarColor='#35AEA4' 
            >
                <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title='Create Post'
                rightButton='SAVE'
                onRightButtonClick={this.savePost.bind(this)}
                hideCrossIcon
                />
            </Header>
            <View style={{ width: '100%', height: 0.5, backgroundColor: 'gray', opacity: 0.08, elevation: 8 }} />
            <Content
            contentContainerStyle={{ flex: 1, backgroundColor: '#e5e5e5' }}
            >
           {this.renderContent()}
           <ActionSheet ref={(c) => { this.actionSheet = c; }} />
            </Content> 
            </Container>
            </KeyboardAwareScrollView>
        );
    }
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#ffffff',
        flexDirection: 'column',
    },
    container: {
        flex: 1,
        position: 'relative'
    },
    userImage: {
        width: 40,
        height: 40,
        borderRadius: 20,    
        borderWidth: 0,        
    },
    selectedCircleBG: {
        marginTop: 4,
        padding: 2,
        backgroundColor: '#fff',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#979797'
    },
    pollBox: {
        backgroundColor: '#fff',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#979797',
        alignSelf: 'flex-start' 
    },
    input: {
        height: 80,
        marginLeft: 20,
        borderWidth: 0,
        fontSize: 15,
      },
      card: {
        padding: 18,
        width: 104,
        height: 104,
        marginTop: 20,
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: '#fff',
        borderColor: '#e5e5e5',
        shadowColor: '#000',
        shadowRadius: 2,
        elevation: 1 
      },
  cardText: {
    marginTop: 8,
    alignSelf: 'center',
    fontSize: 10,
    fontWeight: 'bold',
    fontStyle: 'normal',
    letterSpacing: 0,
    color: '#313131' 
  },
  innerCard: {
    flexDirection: 'column',
    justifyContent: 'space-around'
  }, 
  TextStyle: {
      color: '#fff',
      textAlign: 'center',
      fontSize: 22,
      marginTop: -5
  },
  spinnerTextStyle: {
    color: '#FFF'
  },
  MainContainer_:
    {
        flex: 1,
        marginTop: 20,
        position: 'relative',
        justifyContent: 'center',
        paddingTop: (Platform.OS === 'ios') ? 20 : 0
    },
 
    Animated_View_Style:
    {
        height: 60,
        backgroundColor: '#FF9800',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 5
    },
 
    View_Inside_Text:
    {
        color: 'gray',
        fontSize: 13
    },
 
    TouchableOpacityStyle:{
  
      position: 'absolute',
      width: 50,
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      right: 30,
      bottom: 30,
    },
 
    FloatingButtonStyle: {
  
      resizeMode: 'contain',
      width: 50,
      height: 50,
    },
      triangleDown: {
        transform: [
          { rotate: '180deg' }
        ]
      }
});


const mapDispatchToProps = {
    mediaUpload,
    submitPostWithoutMedia,
    submitUrlMediaPost,
    submitPollPost,
    onActionAssigne,
    newMediaUploadHandler,
    showProgressBar,
    stopProgressBar,
    updateListCheckStatus,
  };

  const mapStateToProps = (state) => {
      return ({
          loading: state.createPost.loading,
          createPost: state.createPost,
      });
  };

export default connect(mapStateToProps, mapDispatchToProps)(CreatePost);
