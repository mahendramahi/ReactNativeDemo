import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import UserAvatar from './../../ThirdParty/UserAvatar';
import styles from './Styles';
import ParseTestTWC from '../../ThirdParty/ParseText/ParseTestTWC';
import { Actions } from 'react-native-router-flux';


const handleUrlPress = (url) => Actions.webViewHelper({ fileData: url });

const renderHifi = (count) => {
         return (
                <TouchableOpacity 
                activeOpacity={0.1}
                style={styles.fabHifi}
                >
                <View
                style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }}
                >
                <Image 
                style={{ width: 10, height: 13 }}
                source={require('./../../components/images/high_five_colored_icon.png')}
                />
                <Text
                style={{ fontSize: 10, marginLeft: 5 }}
                >
                {count}
                </Text>
                
                </View>
                </TouchableOpacity>
          );
};

const renderMessageRow = (message, isReplay, handleClickOnHiFi, handleClickNestedreplay) => {
  let isSubCommentShow = false;
  const { comment, commentIsHasTags, commentTagList } = message;
  //console.log('message', message);
  let commentBody = '';
  let rendertextValue= comment;
    if (commentIsHasTags) {
            commentTagList.map((item, index) => {
                const string = '{{' + index + '}}';
                rendertextValue = rendertextValue.replace(string, `@${item.commentTagName}`);
                commentBody = rendertextValue;
                //console.log(commentBody);
            });
        } else {
          commentBody = rendertextValue;
        }

  let subCommentlength = 0;
        if ('subComment' in message) {
          isSubCommentShow = true;
          subCommentlength = message.subComment.length;
        }

      return (
        <View
        key={`messageComment${message.commentIdentity}`}
        style={styles.maincontainer}
        >
        <View
      style={styles.container} 
        >
        <View>
        <UserAvatar 
         name={message.memberName} 
         src={message.memberImage} 
         size={40} 
        />

          </View>
          {/* comment bubble */}
          <View
            style={[styles.bubbleView]}
          >
          {/* comment body User Name */}
            <Text
              style={styles.userText} 
            >
              {message.memberName}
            </Text>

            {/* comment body msg */}
            <ParseTestTWC
            style={styles.messageText}
            parse={
              [
                { type: 'url', style: { color: '#45c4ba', textDecorationLine: 'underline' }, onPress: (url) => handleUrlPress(url) },
               // { type: 'hashTag', style: { color: '#45c4ba', fontWeight: 'bold', textDecorationLine: 'underline' }, onPress: (hashTag) => this.handleHashTagPress(hashTag) },
                { type: 'atTheRate', style: { color: '#45c4ba', fontWeight: 'bold' }, onPress: (atTheRate) => { } },
              ]
              }
            childrenProps={{ allowFontScaling: false }}
            >
            {commentBody}
            </ParseTestTWC>

            {/* Show Hifi on comment */}
            { message.totalHiFive > 0 
            ? 
            renderHifi(message.totalHiFive)
            :
            null
            }
          </View>
        </View>
        {/* comment bottom view */}
        <View
        style={{ marginLeft: 50, flex: 1, flexDirection: 'row' }}
        >
            <Text 
            style={styles.timeText} 
            >{message.commentDate}</Text>

            <TouchableOpacity 
            style={{ marginLeft: 10 }}
            onPress={() => { handleClickOnHiFi(message); }}
            >
              <Text
              style={[styles.HifiText, { color: message.isHiFive ? 'green' : 'black' }]} 
              > Hi-5 </Text>
            </TouchableOpacity>

            { isReplay ? 
            <TouchableOpacity 
            style={{ marginLeft: 10 }}
            onPress={() => { 
              handleClickNestedreplay(message, message.memberIdentity, message.memberName);
            }}
            >
              <Text
              style={[styles.HifiText, { color: 'black', fontWeight: 'bold' }]} 
              > Reply </Text>
            </TouchableOpacity>
            :
            null
            }
            
          </View>
          {/* reply agian on Comment View */}

          <View
          style={{ marginLeft: 40, flex: 1 }}
          >
          {/* {renderReplayOnComment(message)} */}
          { isSubCommentShow && subCommentlength ? 
          message.subComment.map(item => {
            return renderMessageRow(item, false, handleClickOnHiFi);
          })
          :
          null
        }
          </View>

          {/* End of Whole View */}
          </View>
          );
};

const MessageRowComponent = (props) => {
  //console.log('props==', props);
  return (
    renderMessageRow(props.message, true, props.handleClickOnHiFi, props.handleClickNestedreplay)
  );
};


export default MessageRowComponent;
