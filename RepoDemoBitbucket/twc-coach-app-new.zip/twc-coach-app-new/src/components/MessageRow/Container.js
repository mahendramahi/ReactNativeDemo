import React from 'react';

import MessageRow from './Component';

class MessageRowContainer extends React.Component {

  render() {
    return (
      <MessageRow
        message={this.props.message}
        handleClickOnHiFi={this.props.handleClickOnHiFi}
        handleClickNestedreplay={this.props.handleClickNestedreplay}
      />
    );
  }
}

export default MessageRowContainer;
