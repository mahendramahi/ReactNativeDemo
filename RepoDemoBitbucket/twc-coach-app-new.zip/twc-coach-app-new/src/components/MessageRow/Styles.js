import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  maincontainer: {
    flex: 1,
    flexDirection: 'column',
    padding: 8,
  },
  subMaincontainer: {
    flex: 1,
    marginLeft: 10,
    flexDirection: 'column',
    padding: 8,
  },
  container: {
    flex: 1,
    padding: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eeeeee',
    borderRadius: 5
  },
  bubbleView: {
    backgroundColor: '#E5E5E5',
    flex: 1,
    borderRadius: 15,
    paddingLeft: 14,
    paddingEnd: 14,
    paddingTop: 8,
    paddingBottom: 8,
  },
  userText: {
    color: 'black',
    fontSize: 13,
    fontWeight: 'bold'
  },
  messageText: {
    flex: 1,
    color: 'black',
    marginLeft: 3,
    paddingTop: 5,
    fontSize: 13
  },
  timeText: {
    color: 'gray',
    marginLeft: 3,
    paddingTop: 5,
    fontSize: 12
  },
  HifiText: {
    color: 'black',
    paddingTop: 5,
    fontSize: 12
  },
  userImage: {
    width: 30, 
    height: 30, 
    borderRadius: 30/2, 
    marginEnd: 6, 
    elevation: 10,
    borderWidth: 1,
    resizeMode: 'stretch',
    borderColor: '#000',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    },
   fabHifi: {
     padding: 3,
    backgroundColor: 'white',
    zIndex: 5,
    position: 'absolute',
    width: 40,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    right: 25,
    bottom: -5, 
    borderRadius: 30, 
    elevation: 10 
    },
    fabImage: {
      resizeMode: 'contain',
      width: 50,
      height: 50,
    }
});
