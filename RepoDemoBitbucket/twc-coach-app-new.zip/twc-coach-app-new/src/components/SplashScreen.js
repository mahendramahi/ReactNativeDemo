import React, {
    Component
} from 'react';
import {
    Image,
    ImageBackground,
    AsyncStorage
} from 'react-native';
import { Actions } from 'react-native-router-flux';
import firebase from 'react-native-firebase';
import Config from 'react-native-config';

export default class SplashScreen extends Component {

    componentDidMount() {
        if (Config.ENV === 'release') {
            setTimeout(() => {
                firebase.crashlytics().enableCrashlyticsCollection();
                this.getTokenStatus();
            }, 350);
        } else {
            this.getTokenStatus();
        }
    }

    getTokenStatus() {      
        AsyncStorage.getItem('token').then(data => {
                if (data !== null) {
                    Actions.replace('main');
                } else {
                    Actions.replace('login');
                }
            });
    }
  

    render() {
        return (
            <ImageBackground
            style={styles.backgroundImage}
            source={ require('./images/splash_bg.png')} 
            >
            <Image
            style={styles.item}
            source={ require('./images/logo_splash.png')} 
            />
            </ImageBackground>
        );
    }
}

const styles = {
    backgroundImage: {
        flex: 1, 
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'stretch',
      },
      item: {
        width: 180,
        height: 180,
        alignSelf: 'center'        
      }
};
