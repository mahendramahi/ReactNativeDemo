import React, { Component } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';
import firebase from 'react-native-firebase';
import { connect } from 'react-redux';
import { CardSection, Spinner } from './common';
import { logout } from '../actions';
import { socketConnectionDestroy } from './../actions';

class More extends Component {

    onButtonPress() {
        socketConnectionDestroy();
        firebase.iid().deleteToken();
        firebase.iid().delete();
        this.props.logout();
    }

    renderButton() {
        if (this.props.loading) {
            return (
                <Spinner size='large' />
            );
        }
        return (
        <View
        style={styles.container}
        >
        <TouchableOpacity
            style={styles.logOutButton}
            onPress={this.onButtonPress.bind(this)}
            underlayColor='#fff'
        >
            <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
        </View>
        );
        //{/* <Button onPress={this.onButtonPress.bind(this)}>Logout</Button> */}
       // );
    }

    render() {
        return (
            <CardSection>
                {this.renderButton()}
            </CardSection>
        );
    }   
}

const mapStateToProps = state => {
    return ({
        loading: state.more.loading
    });
};

const styles = {
    container: {
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',
        width: '100%'
    },
    logOutButton: {
        width: '80%',
        marginRight: 15,
        marginLeft: 15,
        marginTop: 8,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#36CABE',
        borderRadius: 40,
        borderWidth: 1,
        borderColor: '#fff',
    },
    logoutText: {
        color: '#fff',
        paddingTop: 4,
        paddingBottom: 4,
        fontSize: 16,
          textAlign: 'center',
          paddingLeft: 10,
          paddingRight: 10
      }
};

export default connect(mapStateToProps, { logout })(More);
