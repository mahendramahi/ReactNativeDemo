import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Card, CardSection } from './common';
import UserAvatar from './../ThirdParty/UserAvatar';
import TouchableDebounce from '../ThirdParty/TouchableDebounce';

const CircleBox = ({ circleName, circleItem, circleImage, circleMembers, circleNewPosts }) => {
    return (
        // <Throttle time='800' handler='onPress' >
        <TouchableDebounce
        onPress={() => {
        Actions.circleBase({ circleObj: circleItem }); 
        }}
        >
        <Card>
            <CardSection>
                <View style={styles.imageroundx}>
                    <UserAvatar 
                        name={circleName} 
                        src={circleImage} 
                        size={70}
                    />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{circleName}</Text>
                    <Text style={styles.circlepost}>{circleMembers} members</Text>
                    <Text style={styles.circlepost}>{circleNewPosts} new posts</Text>
                </View>
                <Image 
                    style={styles.arrowright} 
                    source={require('./images/arrowright.png')} 
                />
            </CardSection>
        </Card>
        </TouchableDebounce>
    );
};

const styles = {
    imageroundx: {
        width: 70,
        height: 70,
        padding: 0,
        borderRadius: 100,
        overflow: 'hidden',
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        alignContent: 'center',
        marginLeft: 5,
        marginTop: 7,
        marginRight: 10
      },
    circleimg: { 
        width: 70,
        height: 70,
        borderRadius: 24
    },
    circlename: {
        fontSize: 15,
        fontWeight: '800',
        padding: 5
    },
    circlepost: {
        fontSize: 14,
        padding: 5
    },
    arrowright: {
        marginLeft: 'auto',
        marginTop: 35,
        width: 12,
        height: 12,    
    },
};

export default CircleBox;
