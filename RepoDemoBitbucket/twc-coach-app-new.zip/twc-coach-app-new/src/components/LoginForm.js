import React, { Component } from 'react';
import firebase from 'react-native-firebase';
import { View, Text, Image, TouchableOpacity,
    BackHandler, Platform, NetInfo } from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import DeviceInfo from 'react-native-device-info';
import { connect } from 'react-redux';
import { TextInputCustom } from './common';
import { loginInputChanged, loginUser, showProgress } from '../actions';
import { HARDWARE_ACTIONS } from '../constant/string';
import { showToast } from './Utility';
//import OfflineSign from './common/OfflineSign';

class LoginForm extends Component {

    constructor(props) {
        super(props);
        this.state = {
            fcmToken: '',
            ipAddres: '1.0.0.0',
            isConnected: true
        };
    }

    async componentDidMount() {
        // BackAndroid.addEventListener(HARDWARE_ACTIONS, () => {
        //     BackAndroid.exitApp();
        // });
        BackHandler.addEventListener('hardwareBackPress', () => {
            BackHandler.exitApp();
        });
        this.checkPermission();
        this.createNotificationListeners(); //add this line
        DeviceInfo.getIPAddress().then((response) => {
            console.log('device info', response);
            this.setState({ ipAddres: `${response}` });
        });
       // NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectivityChange);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return this.nextProps !== nextProps;
    }


  createNotificationListeners = async() => {
    this.onTokenRefreshListener = firebase.messaging().onTokenRefresh(fcmTokenValue => {
        // Process your token as required
        console.log('RefreshfcmToken=' + fcmTokenValue);
        this.setState({ fcmToken: fcmTokenValue });
    });

    /*
    * If your app is closed, you can check if it was opened by a notification being clicked / tapped / opened as follows:
    * */
    const notificationOpen = await firebase.notifications().getInitialNotification();
    if (notificationOpen) {
        console.log(JSON.stringify(notificationOpen));
        const { title, body } = notificationOpen.notification;
    }
  
    /*
    * Triggered for data only payload in foreground
    * */
    this.messageListener = firebase.messaging().onMessage((message) => {
      //process data message
      console.log('message=== ' + JSON.stringify(message));
    }); 
  }
      //1
    async checkPermission() {
      console.log('app==== checkpermisiion  ');
      const enabled = await firebase.messaging().hasPermission();
      
      console.log('app==== ' + enabled);
      if (enabled) {
          this.getToken();
      } else {
          this.requestPermission();
      }
    }
  
    getFCMToken = () => {
      return new Promise( async(resolve, reject) => {
        console.log('app====getFCMtoken Called');
       const fcmTokenValue = await firebase.messaging().getToken();
       if (fcmTokenValue) {
           this.setState({ fcmToken: fcmTokenValue });
        resolve(fcmTokenValue);
          } else {
          reject('error');
          }
      });
        }
    
      //3
     getToken = async() => {
      //let fcmToken = await AsyncStorage.getItem('fcmToken', value);
      //console.log('app==== fcmToken FromAsync===' + await fcmToken);
     // if (!fcmToken) {
        firebase.messaging().getToken().then((token) => {
            console.log(token);
        }).catch((error) => {
            console.log('error');
        });
        this.getFCMToken().then((response) => {
          console.log('app==== fcmToken= '+ response);
        }).catch((error) => {
          console.log(error);
        });
      }
      //d68L4kFBph0:APA91bFTO7TzW6h5FqKugbwHQqgE_2gDXZIdPnBVrJelZ87vSCwjX_Q0DSWTwcx_VMEzqIH4CKzhGLXYc71SdCGWdsJlwxKC_T8Azc3lqKa87uJg6GsB6FcbGgwE_BkdLgwxj-fXEEpv
    
      //2
    async requestPermission() {
      try {
          await firebase.messaging().requestPermission();
          // User has authorised
          this.getToken();
      } catch (error) {
          // User has rejected permissions
          showToast('rejected permissions!!!');
      }
    }
    componentWillUnmount() {
        //BackAndroid.removeEventListener(HARDWARE_ACTIONS, () => {});
        BackHandler.removeEventListener('hardwareBackPress', () => {});
        //NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectivityChange);
        //this.messageListener();
        this.notificationListener();
        this.notificationOpenedListener();
        this.onTokenRefreshListener();
    }

    handleConnectivityChange = isConnected => {
        console.log(isConnected);
        if (isConnected) {
          this.setState({ isConnected });
        } else {
          this.setState({ isConnected });
        }
      };

    onButtonPress = () => {
        const { email, password } = this.props;
        if (email === '' || password === '') {
            showToast('Enter Valid credentials');
        } else {
        //this.porps.store.dispatch({ type: LOGIN_INITIATED });
        if (this.state.fcmToken !== '' && this.state.fcmToken != null) {
            this.props.showProgress();
            const token = this.state.fcmToken;
            const ip = this.state.ipAddres;
            this.props.loginUser({ email, password, token, ip });
        } else {
            if (Platform.OS === 'android') {
            showToast('Please check that you have installed Google Play Service Library.');
            } else {
                showToast('Please check Notification Permission and Allow it.');
            }
        }
        }
    }

    renderLoginButton() {
            return (
            <TouchableOpacity
                style={styles.loginButton}
                onPress={this.onButtonPress.bind(this)}
                underlayColor='#fff'
            >
            <Text style={styles.loginText}>LOGIN</Text>
            </TouchableOpacity>
            );
    }

    renderError() {
        if (this.props.error) {
            return (
                <View style={{ backgroundColor: 'white' }}>
                    <Text style={styles.errorTextStyle}>
                        {this.props.error}
                    </Text>
                </View>
            );
        }
    }

    render() {
        // if (!this.state.isConnected) {
        //     return <OfflineSign />;
        //   }
        return (
            <View style={styles.mainContainer}>
            <Spinner
                    visible={this.props.loading}
                    textContent={'Please Wait...'}
                    textStyle={{ color: '#fff' }} 
            />

            <Image 
            style={styles.imageHeaderStyle}
            source={
                require('./images/logo.png')
            }
            />
             <Text 
             style={styles.textCoach}
             >
             Health coaches only!
            </Text>
            <View 
             style={{ marginTop: 40 }}
            />
            <View>
            <TextInputCustom
            placeholder="Email Address" 
            value={this.props.email}
            style={styles.input}
            onChangeText={value => this.props.loginInputChanged({ prop: 'email', value })}
            underlineColorAndroid="#36CABE"
            />         
            <TextInputCustom
             secureTextEntry
             placeholder="Password" 
             value={this.props.password}
             onChangeText={value => this.props.loginInputChanged({ prop: 'password', value })}
             style={styles.input}
             underlineColorAndroid='#36CABE'
            />
            {this.renderError()}
                <View >
                    {this.renderLoginButton()}
                </View>
            </View>
            {/* <Text 
             style={styles.textForgetPassword} 
            >
            Forgot password?
            </Text> */}
            </View>
        );
    }
}

const styles = {
    mainContainer: {
        width: '100%',
        height: '100%',
        backgroundColor: 'white',
        paddingTop: 42,
        paddingLeft: 30,
        paddingRight: 30,
    },
    errorTextStyle: {
        fontSize: 20,
        color: 'red',
        textAlign: 'center'
    },
    imageHeaderStyle: {
        marginTop: 15,
        alignSelf: 'center'

    },
    textCoach: {
        height: 30,
        marginTop: 10,
        fontFamily: 'System',
        fontSize: 20,
        fontStyle: 'normal',
        letterSpacing: 1,
        color: '#000000',
        alignSelf: 'center'
    },
    textForgetPassword: {
        height: 30,
        marginTop: 60,
        fontFamily: 'System',
        fontSize: 12,
        fontStyle: 'normal',
        letterSpacing: 0,
        color: '#000000',
        textDecorationLine: 'underline',
        alignSelf: 'center',

    },
    loginButton: {
        marginRight: 2,
        marginLeft: 2,
       marginTop: 50,
        paddingTop: 6,
        paddingBottom: 6,
        backgroundColor: '#36CABE',
        borderRadius: 40,
        borderWidth: 1,
        borderColor: '#fff'
    },
    input: {
    width: 250,
    height: 50,
    borderWidth: 0,
    borderColor: 'red',
    alignSelf: 'center'
  },
  loginText: {
    color: '#fff',
    paddingTop: 4,
    paddingBottom: 4,
    fontSize: 12,
      textAlign: 'center',
      paddingLeft: 10,
      paddingRight: 10
  }
};

const mapStateToProps = state => {
    return (
        {
        email: state.auth.email,
        password: state.auth.password,
        loading: state.auth.loading,
        error: state.auth.error
        }
    );
};

export default connect(mapStateToProps, { loginInputChanged, loginUser, showProgress })(LoginForm);
