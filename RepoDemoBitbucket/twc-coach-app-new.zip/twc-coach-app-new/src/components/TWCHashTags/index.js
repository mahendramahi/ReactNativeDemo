import React, {
    Component
} from 'react';
import {
    View,
    Image,
    TouchableOpacity,
    Text
} from 'react-native';
import { Container,
    Header,
    Tab, Tabs, ScrollableTab,
    Content, Item,
    TabHeading } from 'native-base';
import { Actions } from 'react-native-router-flux';
import HashTagPosts from './HashTagPosts';

import ToolBarWithBackArrow from './../../components/common/ToolBarWithBackArrow';


class HashTagsBase extends Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {
    }

    onOptionMenuClick = () => {
        Actions.pop();
    }

    onBackArrowPressed = () => {
        Actions.pop();
    }
    render() {
        return (
           <Container>
            <Header 
            style={{ backgroundColor: '#fff' }}
            androidStatusBarColor='gray' 
            >
            <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title={this.props.hashTag}
                rightButton=''
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
            />
            </Header> 
            <Content >
            <HashTagPosts 
                    tag={this.props.hashTag}
            />
            </Content>
            {/* <Tabs 
            tabBarUnderlineStyle={{ backgroundColor: '#27c5c6' }}
            //  renderTabBar={() => <ScrollableTab />}
            >
                <Tab 
                heading='Posts' 
                tabStyle={{ backgroundColor: '#fff' }}
                activeTabStyle={{ backgroundColor: '#fff' }}
                textStyle={{ color: 'gray' }}
                activeTextStyle={{ color: 'black' }}
                > */}
                    {/* <Home /> */}
                    {/* <HashTagPosts 
                    tag={this.props.hashTag}
                    /> */}
                {/* </Tab>
                
                <Tab 
                heading='Circles'
                tabStyle={{ backgroundColor: '#fff' }}
                activeTabStyle={{ backgroundColor: '#fff' }}
                textStyle={{ color: 'gray' }}
                activeTextStyle={{ color: 'black' }}
                >
                <HashTagCircle 
                tag={this.props.hashTag}
                />
                </Tab>
                <Tab 
                heading='Food'
                tabStyle={{ backgroundColor: '#fff' }}
                activeTabStyle={{ backgroundColor: '#fff' }}
                textStyle={{ color: 'gray' }}
                activeTextStyle={{ color: 'black' }}
                >
                <HashTagFood
                tag={this.props.hashTag}
                />
                </Tab>

                <Tab 
                heading='Blogs'
                tabStyle={{ backgroundColor: '#fff' }}
                activeTabStyle={{ backgroundColor: '#fff' }}
                textStyle={{ color: 'gray' }}
                activeTextStyle={{ color: 'black' }}
                >
                <HashTagBlogs
                tag={this.props.hashTag}
                />
                </Tab>
                </Tabs> */}
            </Container>
        );
    }
}

export default HashTagsBase;
