import React, { Component } from 'react';
import { View, Text, Image, RefreshControl, ScrollView } from 'react-native';
import styles from './Styles';

const HashTagFoodComponent = (props) => {
  return (
    <View style={styles.root}>
    <ScrollView 
          style={styles.mainContainer}
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          onScroll={(e) => {
              let paddingToBottom = 10;
              paddingToBottom += e.nativeEvent.layoutMeasurement.height;
              if (e.nativeEvent.contentOffset.y >= e.nativeEvent.contentSize.height - paddingToBottom) {
                props.onLoadMore();
              }
            }}
            refreshControl={
                <RefreshControl
                    refreshing={props.refreshing}
                    onRefresh={props.onRefresh}
                />
            }            
    >  
         {/* <Feed feeds={props.postList} /> */}
      </ScrollView>
      </View>
);
};

export default HashTagFoodComponent;
