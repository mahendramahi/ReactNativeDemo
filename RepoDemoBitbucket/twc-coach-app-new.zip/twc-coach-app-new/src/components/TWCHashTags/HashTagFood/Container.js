import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View } from 'native-base';
import Styles from './Styles';
import HashTagFood from './Component';

class HashTagCircleContainer extends Component {

    constructor(props) {
        super(props);
        this.state = {
          pageIndex: 1,
          pageSize: 10,
          refreshing: false,
          type: 1,
        };
      }
      
      componentDidMount() {
        //this.props.getHashTagPostList(this.state.pageIndex, this.state.pageSize, this.state.type, this.props.tag);
        //this.setState({ pageIndex: (this.state.pageIndex + 1) });
      }
      
      onLoadMore = () => {
       
      };
      
      onRefresh = () => {
    
      };
      
      
      render() {
        return (
          <View style={Styles.root}>
            <HashTagFood
            postList={this.props.postList}
            onLoadMore={this.onLoadMore.bind(this)}
            onRefresh={this.onRefresh.bind()}
            refreshing={this.state.refreshing}
            />
          </View>
        );
      } 
    }
    
    
    const mapDispatchToProps = {
      //getHashTagPostList
      };
      const mapStateToProps = (state) => {
      return (
        {
         // postList: state.hashTagPost.postList,
          //isLoading: state.hashTagPost.isLoading
        }
      );
      };
    
    export default connect(mapStateToProps, mapDispatchToProps)(HashTagCircleContainer);
    