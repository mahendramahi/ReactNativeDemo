import React, { Component } from 'react';
import { View, Text, FlatList, RefreshControl, ScrollView } from 'react-native';
import styles from './Styles';
import { CircleJoinBox } from '../../common';
import NoDataView from '../../common/NoDataView';

const emptyComponent = () => {
  return (
    <NoDataView />
  );
};

const renderCircleList = (props) => {
    return (
        <FlatList
        data={props.circleList}
        ItemSeparatorComponent={this.FlatListItemSeparator}
        renderItem={({ item }) => (
            <CircleJoinBox
            key={item.circleIdentity}
            circleName={item.circle_Name}
            circleItem={item}
            circleImage={item.circle_ImageName}
            circleMembers={item.memberList}
            />
           )}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={emptyComponent()}
        />
    );
};

const HashTagCircleComponent = (props) => {
  return (
    <View style={styles.root}>
    <ScrollView 
          style={styles.mainContainer}
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          onScroll={(e) => {
              let paddingToBottom = 10;
              paddingToBottom += e.nativeEvent.layoutMeasurement.height;
              if (e.nativeEvent.contentOffset.y >= e.nativeEvent.contentSize.height - paddingToBottom) {
                props.onLoadMore();
              }
            }}
            refreshControl={
                <RefreshControl
                    refreshing={props.refreshing}
                    onRefresh={props.onRefresh}
                />
            }
    >
    {renderCircleList(props)}
    </ScrollView>
    </View>
);
};

export default HashTagCircleComponent;
