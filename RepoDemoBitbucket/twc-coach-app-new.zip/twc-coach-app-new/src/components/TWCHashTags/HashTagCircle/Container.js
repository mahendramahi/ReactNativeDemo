import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View } from 'native-base';
import Styles from './Styles';
import { getHashTagCircleList } from '../../../actions/HashTagPostsAction';
import HashTagCircle from './Component';

class HashTagCircleContainer extends Component {

    constructor(props) {
        super(props);
        this.state = {
          pageIndex: 1,
          pageSize: 10,
          refreshing: false,
          type: 2,
        };
      }
      
      componentDidMount() {
        this.props.getHashTagCircleList(this.state.pageIndex, this.state.pageSize, this.state.type, this.props.tag);
        this.setState({ pageIndex: (this.state.pageIndex + 1) });
      }
      
      onLoadMore = () => {
       
      };
      
      onRefresh = () => {
    
      };
      
      
      render() {
        return (
          <View style={Styles.root}>
            <HashTagCircle
            circleList={this.props.circleList}
            onLoadMore={this.onLoadMore.bind(this)}
            onRefresh={this.onRefresh.bind()}
            refreshing={this.state.refreshing}
            />
          </View>
        );
      } 
    }
    
    
    const mapDispatchToProps = {
      getHashTagCircleList
      };
      const mapStateToProps = (state) => {
      return (
        {
          circleList: state.hashTagPost.postList,
          isLoading: state.hashTagPost.isLoading
        }
      );
      };
    
    export default connect(mapStateToProps, mapDispatchToProps)(HashTagCircleContainer);
