import React, { Component } from 'react';
import { View, StyleSheet, Text,
     TouchableOpacity, FlatList, Image, AsyncStorage } from 'react-native';
import { connect } from 'react-redux';
import { Container,
        Header,
        Content } from 'native-base';
import { Actions } from 'react-native-router-flux';
import ToolBarWithBackArrow from '../components/common/ToolBarWithBackArrow';
import { GET_CIRCLES, IMAGE_BASE_URL_CIRCLE } from '../constant/api';
import { axiosWithoutDispatch } from './../helper/ApiHandler';
import NoDataView from '../components/common/NoDataView';
import UserAvatar from '../ThirdParty/UserAvatar';
import { getMyCircleList, updateListCheckStatus } from '../actions';

class SelectCircles extends Component {

    constructor(props) {
        super(props);
        this.state = {
            circleList: [],
            circleSelctedList: [],
            PageIndex: 1,
            data: {},
            PageSize: 50,
            reRender: false,
        };

        //this.getAllCircleList();
    }

    componentDidMount() {
        if (this.props.selectCircleData.length === 0) {
            this.props.getMyCircleList(this.state.PageIndex, this.state.PageSize);
        } else {
            this.props.selectCircleData.map(item => {
                if (item.check) {
                this.state.circleSelctedList.push(item);
                }
            });
        }
    }

    onBackArrowPressed = () => {
        Actions.pop({
            text: 'text'
        });
       
    };

    onOptionMenuClick = () => {
        this.props.callbackFunction(this.state.circleSelctedList);
        Actions.pop();
        //alert('on Done Click');
    };

    onItemClick = (item) => {
        const ItemTemp = item.check;
        const updatedItemList = [...this.props.selectCircleData];
        const position = this.props.selectCircleData.indexOf(item);
        updatedItemList[position].check = !item.check;

        this.props.updateListCheckStatus(updatedItemList);
        // this.setState({
        //          ...this.state,
        //          circleList: updatedItemList,
        //      });

        if (!ItemTemp) {
            const updatedItem = item;
           this.state.circleSelctedList.push(updatedItem);
        } else {
           this.state.circleSelctedList.pop(item);
        }
    };

    // getAllCircleList() {
    //     const requestData = {
    //         PageSize: this.state.PageSize,
    //         PageIndex: this.state.PageIndex,
    //         SearchTerm: '',
    //         SortBy: 'circle',
    //     };
    //     AsyncStorage.getItem('token').then(data => {
    //         const url = GET_CIRCLES;
    //         const authOptions = {
    //                 method: 'POST',
    //                 url,
    //                 data: requestData,
    //                 headers: {
    //                     Authorization: 'Bearer ' + data
    //                 },
    //                 json: true
    //             };
    //             axiosWithoutDispatch(authOptions)
    //             .then((res) => {
    //                 const circleListData = res.data.data.data;
    //                       circleListData.map(item => {
    //                         item.check = false;
    //                         return circleListData;
    //                       });
    //                       this.setState({ circleList: circleListData, });
    //             }).catch(error => {
    //                 console.error(error);
    //             });
    //         });
    // }

    emptyComponent = () => {
        return (
            <NoDataView />
        );
    }

    renderBodyOfApp() {
        return (
        <View
        >
                <Text style={styles.textHead}>Select the circles in which you would like to share this post</Text>
                <FlatList
                data={this.props.selectCircleData}
                extraData={this.props}
                ListEmptyComponent={this.emptyComponent()}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => (
                  <TouchableOpacity
                  key={`${index.toString()}`}
                  style={{
                    flexDirection: 'row',
                    padding: 16,
                    borderBottomWidth: 1,
                    borderStyle: 'solid',
                    borderColor: '#ecf0f1'
                    }}
                    onPress={this.onItemClick.bind(this, item)}
                    >
                    <View 
                    style={{
                        alignItems: 'stretch',
                        justifyContent: 'flex-start',
                        flexDirection: 'row',
                    }}>
                     { item.check ?
                    <Image
                    style={{ marginLeft: 15 }}  
                    source={require('../components/images/checkboxSelected.png')}/>
                    :
                    <Image
                    style={{ marginLeft: 15 }}  
                    source={require('../components/images/checkbox.png')}/>
                     }
                    <UserAvatar 
                        name={item.circle_Name} 
                        src={item.circle_ImageName} 
                        size={30}
                        style={{ marginLeft: 15 }}
                    />
				    <Text style={styles.circleName} >{item.circle_Name}</Text> 
                    </View>
                    </TouchableOpacity>
                 )}
                />  
                </View>
        );
    }
    
    render() {
        return (

            <Container>
            <Header 
                style={{ backgroundColor: '#fff' }}
                androidStatusBarColor='#35AEA4' 
            >
            <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title='Select Circles'
                rightButton='DONE'
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
            />
            </Header> 
            <Content padder >
            {this.renderBodyOfApp()}
            </Content> 
            </Container>  
        );
    }
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#ffffff',
        flexDirection: 'column',
    },
    container: {
        flex: 14,
    },
    textHead: {
        marginLeft: 18,
        marginRight: 18,
        marginTop: 14,
        marginBottom: 14,
        fontSize: 16,
        fontWeight: '300',
        fontStyle: 'normal',
        color: '#313131',
    },
    circleName: {
        fontWeight: 'bold',
        marginLeft: 15,
        fontStyle: 'normal',
        letterSpacing: 0,
        color: '#313131',
        fontSize: 18,
    },
  });

const mapDispatchToProps = {
    getMyCircleList,
    updateListCheckStatus,
};

const mapStateToProps = state => {
    return (
        {
        selectCircleData: state.selectCircle.data
        }
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectCircles);
