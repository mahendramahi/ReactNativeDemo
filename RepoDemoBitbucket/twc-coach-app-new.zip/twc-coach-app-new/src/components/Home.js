import React, { Component } from 'react';
import firebase, { Firebase } from 'react-native-firebase';
import { ScrollView, Text, View, BackHandler, Image, FlatList, Animated,
    TouchableOpacity, Platform, RefreshControl, ActivityIndicator } from 'react-native';
import { Badge } from 'native-base';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';
import CircleBox from './CircleBox';
import Feed from './Feed';
import { loadHome, getFeed, getUnReadCount, clearHomePage } from '../actions';
import { FloatingButton, FloatingScrollUp } from './common';
import { HARDWARE_ACTIONS, NO_INTERNET_CONNECTED } from '../constant/string';
import { registerAppListener } from '../firebase/Listners';
import { showToast } from './Utility';
import TouchableDebounce from '../ThirdParty/TouchableDebounce';

class Home extends React.Component {

    constructor(props) {
        super(props);
        this.onHomeAfterCreatePost = this.onHomeAfterCreatePost.bind(this);
        this.onHomeFromChat = this.onHomeFromChat.bind(this);
        this.state = {
           pageForFeed: 1,
           goBack: 1,
           feed: null,
           refreshing: false,
           isNetworkConnected: false,
           screenHeight: 0,
           upScrollIcon: false,
        };
        //this.upScrollIcon = false;
        this.BackAction = 1;
        this.scrollView = null;
        this.refresh = this.refresh.bind(this);
    }

    componentWillMount() {
        this.props.loadHome();
    }

    onNotify = (notification) => {
       // console.log('Furrrrr=' + notification);
    };
    
    componentDidMount = async() => {
        BackHandler.addEventListener('hardwareBackPress', () => {
            if (Actions.currentScene === 'home') {
                if (this.BackAction === 1) {
                    this.BackAction = 2;
                    showToast('Press Again For Exit');
                } else {
                BackHandler.exitApp();
                }
               }
        });
        this.props.getFeed(1);
        const channel = new firebase.notifications.Android.Channel('test-channel', 'Test Channel', firebase.notifications.Android.Importance.Max)
        .setDescription('My apps test channel');
        console.log('channel = ' + JSON.stringify(channel));
    
        // Create the channel
        firebase.notifications().android.createChannel(channel);

        registerAppListener();

        firebase.notifications().getInitialNotification()
        .then((notificationOpen) => {
            console.log('getInitialNotification');
          if (notificationOpen) {
            // Get information about the notification that was opened
            //alert('open');
           // const notif = notificationOpen.notification;
           // console.log('getInitialNotification =' + notificationOpen.notification.title);
          }
        });

        firebase.notifications().onNotification().then((notificationOpen) => {
           // console.log('onNotification =' + notificationOpen.notification.title);
        });

        firebase.notifications().onNotificationOpened().then((notificationOpen) => {
            //console.log('onNotificationOpened =' + notificationOpen.notification.title);
        });
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (this.state.upScrollIcon !== nextState.upScrollIcon) {
            return true;
        } else {
        return this.props !== nextProps;
        }
    }

    componentWillUnmount() {
        this.BackAction = 1;
        BackHandler.removeEventListener('hardwareBackPress', this.handleBackPress);
        this.messageListener();
    }

    // onContentSizeChange = (contentWidth, contentHeight) => {
    //     //this.setState({ screenHeight: contentHeight });
    // }

    onHomeAfterCreatePost(val) {
        if (val === true) {
            this.setState({
                pageForFeed: 1,
            });
            this.forceUpdate();
            this.props.getFeed(1);
            this.forceUpdate();
        }
    }

    onHomeFromChat() {
        this.props.getUnReadCount();
    }

    onMessageClick = () => {
        Actions.chatList({ callbackFunction: this.onHomeFromChat });
    };

    onGetFeedAgain = () => {
         this.setState({
            pageForFeed: this.state.pageForFeed + 1,
        });
        this.props.getFeed(this.state.pageForFeed + 1);
        this.forceUpdate();
    };

    handleConnectionChange = (isConnected) => {
        this.setState({ isNetworkConnected: isConnected });
        console.log(`is connected: ${this.state.isNetworkConnected}`);
    }

    isCloseToBottom = ({ layoutMeasurement, contentOffset, contentSize }) => {
        const paddingToBottom = 20;
        return layoutMeasurement.height + contentOffset.y >=
          contentSize.height - paddingToBottom;
      };

    refresh() {
        this.setState({ refreshing: true });
        this.props.clearHomePage();
        this.props.getUnReadCount();
        this.setState({ pageForFeed: 1 });
          // you must return Promise everytime
          //return new Promise((resolve) => {
            //setTimeout(() => {
              // some refresh process should come here
              this.props.loadHome();              
              this.props.getFeed(1);
              setTimeout(() => {
                this.setState({ refreshing: false });
              }, 160);
            //  resolve(); 
           // }, 1000);
        //  });
    }

    renderCircles() {
        return (
            <FlatList
            data={this.props.circles}
            ItemSeparatorComponent={this.FlatListItemSeparator}
            // scrollEnabled={false}
            // nestedScrollEnabled={false}
            renderItem={({ item }) => (
                <CircleBox
                key={item.circle_ID}
                circleName={item.circle_Name}
                circleItem={item}
                circleImage={item.circle_ImageName}
                circleMembers={item.totalCircleMembers}
                circleNewPosts={item.totalCirclePost}
                />
               )}
            keyExtractor={(item, index) => index.toString()}
            />
        );
    }
    renderFooter = () => {
        return (
          <View
            style={{
              paddingVertical: 20,
              borderTopWidth: 1,
              borderColor: '#CED0CE'
            }}
          >
            <ActivityIndicator animating size="large" />
          </View>
        );
    };

    handleClick = () => {
        //alert('Hello click');
    }

    clickOnFloatingButton = () => {
            Actions.createPost({
                callbackFunction: this.onHomeAfterCreatePost
            });
    };

    clickOnScrollUp = () => {
        this.setState({ upScrollIcon: false });
       this.scrollView.scrollTo({ y: 0, animated: true });
    }

    render() {
        return (
            <View style={{ flex: 1 }}>
            <ScrollView
                    ref={(scrollref) => { this.scrollView = scrollref; }}
                    style={styles.mainContainer}
                    //contentContainerStyle={{ flexGrow: 1 }}
                    showsVerticalScrollIndicator={false}
                    // pagingEnabled={true}
                    nestedScrollEnabled={true}
                    onScroll={(e) => {
                        if (e.nativeEvent.contentOffset.y > 256) {
                            this.setState({ upScrollIcon: true });
                            //this.upScrollIcon = true;
                        } else {
                            this.setState({ upScrollIcon: false });
                            //this.upScrollIcon = false;
                        }
                        let paddingToBottom = 20;
                        paddingToBottom += e.nativeEvent.layoutMeasurement.height;
                        if (e.nativeEvent.contentOffset.y >= e.nativeEvent.contentSize.height - paddingToBottom) {
                        this.onGetFeedAgain();
                        }
                    }}
                    refreshControl={
                        <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={this.refresh.bind(this)}
                        />
                        }
                >
                    <View 
                    style={styles.circleHead}
                    >
                    <Text style={styles.mainheading}>My Circles</Text>
                    <TouchableDebounce
                    onPress={this.onMessageClick.bind(this)}
                    >
                    <Image 
                    source={require('./../components/images/messages.png')}
                    style={styles.messageIcon}
                    />
                    {this.props.unreadCount > 0 ? 
                    <Badge 
                    style={styles.badge}
                    >
                        <Text 
                        style={styles.badgeText}
                        >{this.props.unreadCount}</Text>
                    </Badge>
                    :
                    null}
                    </TouchableDebounce>
                    </View>
                    {this.renderCircles()}
                    <View style={styles.feedHead}>
                    <Text style={styles.mainheading}>Activity Feed</Text>
                    <Text style={{ fontSize: 12, color: '#040404', marginLeft: 6 }} >Catch-up with what’s been happening in your circles</Text>
                    </View>
                    <View style={styles.feedHead1}>
                    <Feed feeds={this.props.feeds} />
                    </View>
                </ScrollView>   
                  {/* </SafeAreaView> */}
                {this.state.upScrollIcon ?
                <FloatingScrollUp
                     onPress={this.clickOnScrollUp.bind(this)}
                />
                : null }
                <FloatingButton
                     onPress={this.clickOnFloatingButton.bind(this)}
                />
            </View>
        );
    }   
}

const styles = {
    mainContainer: {
        flex: 1,
        paddingTop: (Platform.OS === 'ios') ? 20 : 0,
    },
    messageIcon: {
        justifyContent: 'center',
        padding: 5,
        marginRight: 8,
        marginTop: 8,
        width: 34,
        height: 30
    },
    circleHead: {
        flexDirection: 'row',
        justifyContent: 'space-between' 
    },
    mainheading: {
        fontSize: 22,
        color: '#000',
        fontWeight: '800',
        marginLeft: 5,
        marginTop: 5,
        marginBottom: 5,
    },
    feedHead: {
        marginTop: 10,
        paddingTop: 10,
        backgroundColor: '#ffffff'
    },
    feedHead1: {
        // flex: 1,
        backgroundColor: '#ffffff'
    },
    badge: { 
        backgroundColor: 'red',
        zIndex: 5,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        right: 5,
        height: 20,
        top: 4, 
        },
    badgeText: {
        color: 'white',
        fontSize: 8
    }    
};

const mapStateToProps = (state) => {
    return (
        {
            circles: state.home,
            feeds: state.feeds.feeds,
            unreadCount: state.socket.unreadCount,
        }
    );
};

export default connect(mapStateToProps, { loadHome, getFeed, getUnReadCount, clearHomePage })(Home);
