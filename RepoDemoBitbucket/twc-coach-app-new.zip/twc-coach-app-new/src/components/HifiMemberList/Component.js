import React from 'react';
import { View, Text, FlatList } from 'react-native';
import styles from './Styles';
import NoDataView from '../common/NoDataView';

const emptyComponent = () => {
  return (
    <NoDataView />
  );
};

const HifiMemberComponent = (props) => {
  return (
    <View style={styles.root}>
    {/* <FlatList
        data={props.circleList}
        renderItem={({ item }) => (
            <CircleJoinBox
            key={item.circleIdentity}
            circleName={item.circle_Name}
            circleItem={item}
            circleImage={item.circle_ImageName}
            circleMembers={item.memberList}
            />
           )}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={emptyComponent()}
        /> */}
    </View>
);
};

export default HifiMemberComponent;
