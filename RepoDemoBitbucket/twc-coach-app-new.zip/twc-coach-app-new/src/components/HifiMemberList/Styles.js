import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    root: {
        flex: 1,
        height: '100%',
        width: '100%'
    }
});
