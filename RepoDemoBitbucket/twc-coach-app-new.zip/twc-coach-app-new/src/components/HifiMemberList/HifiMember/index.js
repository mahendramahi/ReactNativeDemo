import React from 'react';
import { View, Text } from 'react-native';
import styles from './Style';
import { Card, CardSection } from '../../common';
import UserAvatar from '../../../ThirdParty/UserAvatar';


const HifiMember = ({ item }) => {
    return (
        <View 
        style={{ margin: 7 }}
        >
        <Card >
            <CardSection>
                <View style={styles.imageroundx}>
                        <UserAvatar 
                        name={item.name} 
                        src={item.image} 
                        size={60} 
                        />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{item.name}</Text>
                </View>
            </CardSection>
        </Card>
        </View>
    );
};

export default HifiMember;
