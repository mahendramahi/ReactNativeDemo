import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Actions } from 'react-native-router-flux';
import { Container,
  Header,
  Content } from 'native-base';
import { FlatList, Text } from 'react-native';
import Styles from './Styles';
import { getHifiMemberList } from '../../actions';
import ToolBarWithBackArrow from '../common/ToolBarWithBackArrow';
import NoDataView from '../common/NoDataView';
import HifiMember from './HifiMember';

class HifiMemberContainer extends Component {

    constructor(props) {
        super(props);
        this.state = {
          pageIndex: 1,
          pageSize: 40
        };
      }
      
      componentDidMount() {
        this.props.getHifiMemberList(this.state.pageIndex, this.state.pageSize, this.props.data.postIdentity);
      }

    onBackArrowPressed = () => {
      Actions.pop();
    }

      
      render() {
        return (
          <Container>
          <Header 
          style={{ backgroundColor: '#fff' }}
          androidStatusBarColor='gray' 
          >
          <ToolBarWithBackArrow
              onPress={this.onBackArrowPressed.bind(this)}
              title={'High-Fives'}
              rightButton=''
              onRightButtonClick={null}
              hideCrossIcon
          />
          </Header> 
          <Content >
          <FlatList
            data={this.props.HifiMember}
            extraData={this.props}
            renderItem={({ item }) => (
              <HifiMember
              item={item}
              />
            )}
            keyExtractor={(item, index) => index.toString()}
            ListEmptyComponent={<NoDataView />}
          />
          </Content>
          </Container>
        );
      } 
    }
    
    
    const mapDispatchToProps = {
      getHifiMemberList
      };
      const mapStateToProps = (state) => {
      return (
        {
          HifiMember: state.HifiMember.memberData,
          isLoading: state.HifiMember.isLoading
        }
      );
      };
    
    export default connect(mapStateToProps, mapDispatchToProps)(HifiMemberContainer);
