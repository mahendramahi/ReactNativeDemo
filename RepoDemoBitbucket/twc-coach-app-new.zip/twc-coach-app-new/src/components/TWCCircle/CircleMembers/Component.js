import React, { Component } from 'react';
import { View, Text, Image, FlatList } from 'react-native';


const CircleMembersComponent = (props) => {
  return (
        <View 
        style={{ flex: 1 }}
        >
        
        </View> 
       );
};

export default CircleMembersComponent;
