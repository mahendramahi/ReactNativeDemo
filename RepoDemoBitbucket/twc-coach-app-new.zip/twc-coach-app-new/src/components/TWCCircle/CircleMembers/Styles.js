import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
    mainContainer: {
        flex: 1,
        paddingTop: (Platform.OS === 'ios') ? 20 : 0,
    },
    searchBarcontainer: {
        margin: 5,
        flex: 1,
        width: '100%',
        zIndex: 10,
        position: 'absolute',
        elevation: 1,
        shadowRadius: 0,
        borderRadius: 6,
        borderWidth: 0.01,
        borderColor: 'gray',
        height: 38,
        flexDirection: 'row',
        alignItems: 'center',
      },
      totalMember: {
        color: '#6f6f6f',
        fontSize: 10,
        fontWeight: 'bold'
      },
      searchIcon: {
          marginLeft: 10,
          marginEnd: 8,
          justifyContent: 'center',
          alignItems: 'center'
        },
});
