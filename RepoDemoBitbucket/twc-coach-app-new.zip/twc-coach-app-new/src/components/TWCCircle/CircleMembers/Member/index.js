import React from 'react';
import moment from 'moment';
import { View, Text } from 'react-native';
import { Card, CardSection } from './../../../common';  //common';
import styles from './Style';
import UserAvatar from './../../../../ThirdParty/UserAvatar';
import TouchableDebounce from '../../../../ThirdParty/TouchableDebounce';

const Member = ({ memberItem, onClick }) => {
    return (
        <View 
        style={{ margin: 7 }}
        >
        <TouchableDebounce
        onPress={() => onClick(memberItem)}
        >
        <Card>
            <CardSection>
                <View style={styles.imageroundx}>
                <UserAvatar 
                    name={memberItem.memberName} 
                    src={memberItem.memberImage} 
                    size={65} 
                />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{memberItem.memberName}</Text>
                    <Text style={[styles.circlepost, { marginEnd: 90 }]} numberOfLines={2}>{memberItem.memberBio}</Text>
                    <Text style={[styles.circlepost, { color: 'black' }]}>{`joined ${moment(memberItem.joiningDate).local().format('MMMM DD, YYYY').toUpperCase()}`}</Text>
                </View>
            </CardSection>
        </Card>
        </TouchableDebounce>
        </View>
    );
};

export default Member;

