import React, { Component } from 'react';
import { View, Text, TextInput, Image, FlatList,
   ScrollView, ActivityIndicator, RefreshControl } from 'react-native';
import { connect } from 'react-redux';
import { getCircleMmbersList, clearCircleMembers, getChatId } from './../../../actions';
import Member from './Member';
import styles from './Styles';

class CircleMembersContainer extends Component {

    constructor(props) {
      super(props);
     this.state = {
          pageNo: 1,
          pageSize: 20,
          searchTerms: '',
          footer: false,
          refreshing: false,
          onScrollEnable: true
     };
    }

  componentDidMount() {
    this.props.getCircleMmbersList(this.state.pageNo, this.state.searchTerms, this.props.circleCoach.circleIdentity);
    this.setState({ pageNo: (this.state.pageNo + 1) });
  }

  onSearch = (text) => {
    this.setState({ searchTerms: text, footer: false });
    this.props.getCircleMmbersList(1, text.trim(), this.props.circleCoach.circleIdentity);
  }

  onLoadMore = () => {
    this.props.getCircleMmbersList(this.state.pageNo, this.state.searchTerms, this.props.circleCoach.circleIdentity);
    this.setState({ pageNo: (this.state.pageNo + 1), footer: true });
    this.forceUpdate();
  }

  onRefresh = () => {
    this.props.clearCircleMembers();
    this.setState({ refreshing: true });
    this.props.getCircleMmbersList(1, this.state.searchTerms, this.props.circleCoach.circleIdentity);
    this.setState({ pageNo: 2 });
    setTimeout(() => {
      this.setState({ refreshing: false });
    }, 170);
   // this.setState({ refreshing: false });
  };

  onMemeberItemClick = (memberItem) => {
    //console.log('member Details' + JSON.stringify(memberItem));
    this.props.getChatId(memberItem.memberIdentity);
  };

  renderSearchBar() {
    return (
      <View
      style={styles.searchBarcontainer}
      >
      <Image 
        source={require('./../../images/search3.png')}
        style={styles.searchIcon}
      />
      <TextInput
      style={{ width: '100%' }}
        placeholder='Search'
        onChangeText={(text) => {
          this.onSearch(text);
        }}
        // onLayout={() => focusOnLayout && this.textInput.focus()}
      />
      </View>
    );
  }
  renderFooter = () => {
    console.log('isLoading', this.props.isLoading);
    if (!this.props.isLoading) return null;
      return (
        <View
          style={{
            paddingVertical: 20,
            borderTopWidth: 1,
            borderColor: '#CED0CE'
          }}
        >
          <ActivityIndicator animating size="large" />
        </View>
      );
  };

  render() {
    return (
      
      <View style={{ flex: 1, justifyContent: 'center', position: 'relative', margin: 10 }}>
            <ScrollView 
            style={styles.mainContainer}
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}
            onScroll={(e) => {
                let paddingToBottom = 10;
                this.props.onScrollpage(e.nativeEvent.contentOffset.y);
                paddingToBottom += e.nativeEvent.layoutMeasurement.height;
                if (e.nativeEvent.contentOffset.y >= e.nativeEvent.contentSize.height - paddingToBottom) {
                // this.onGetFeedAgain();
                this.onLoadMore();
                }
              }}
              refreshControl={
                <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                />
              }
            >  
              {this.renderSearchBar()}

                {/*  */}
                <View 
                style={{ marginTop: 50, marginLeft: 12 }}
                >
                <Text 
                style={styles.totalMember}
                >{`${this.props.totalMembers} members in this circle`}</Text>
                </View>

              <FlatList
                data={this.props.membersList}
                extraData={this.props.membersList}
                renderItem={({ item }) => (
                  <Member
                    key={item.userIdentity}
                    memberItem={item}
                    onClick={this.onMemeberItemClick.bind(this)}
                  />
                  )}
                keyExtractor={(item, index) => index.toString()}
                ListFooterComponent={this.renderFooter}
              />
        </ScrollView>
      </View>
    );
}
}

const mapDispatchToProps = {
  getCircleMmbersList,
  clearCircleMembers,
  getChatId,
};
const mapStateToProps = (state) => {
  return (
    {
      membersList: state.circleMembers.membersList,
      isLoading: state.circleMembers.isLoading,
      totalMembers: state.circleMembers.totalMembers,
    }
);
};


export default connect(mapStateToProps, mapDispatchToProps)(CircleMembersContainer);
