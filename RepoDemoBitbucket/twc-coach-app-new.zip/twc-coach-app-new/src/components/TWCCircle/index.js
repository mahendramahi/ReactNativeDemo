import React, {
    Component
} from 'react';
import {
    View,
    Animated,
    TouchableOpacity,
    Text
} from 'react-native';
import { connect } from 'react-redux';
import { Container,
    Header,
    Tab, Tabs } from 'native-base';
import { Actions } from 'react-native-router-flux';
import CircleCoaches from './CircleCoaches';
import CircleMembers from './CircleMembers';
import CircleHome from './CircleHome';
import ToolBarWithBackArrow from './../../components/common/ToolBarWithBackArrow';
import { clearAllCircleDetails } from '../../actions';
import Styles from './Styles';

class CircleBase extends Component {

    constructor(props) {
        super(props);
        this.state = {
            headerAnim: new Animated.Value(56),
            headerAnimDown: new Animated.Value(0),
            isVisible: true,
            localYValue: 0,
            onScrollEnable: true,
        };
    }

    componentDidMount() {  
    }

    componentWillUnmount() {
        this.props.clearAllCircleDetails();
    }

    onOptionMenuClick = () => {
        Actions.pop();
    }

    onBackArrowPressed = () => {
        Actions.pop();
    }

    onScrollpage(yValue) {
        //console.log(yValue);
        if (this.state.onScrollEnable) {
            this.setState({
                onScrollEnable: false
              });
              if (yValue > 3 && this.state.localYValue < yValue) {
                if (this.state.isVisible) {
                    this.animatedAction();
                }
                this.setState({
                    localYValue: yValue,
                    isVisible: false,
                });
            } else if (yValue > 3 && this.state.localYValue > yValue) {
                if (!this.state.isVisible) {
                    this.animatedActionDown();
                }
                this.setState({
                    localYValue: yValue,
                    isVisible: true,
                });
            }
            //this.props.onScrollpage(e.nativeEvent.contentOffset.y);
            setTimeout(() => {
              this.setState({
                onScrollEnable: true
              });
            }, 120);
          }
    }

    animatedAction = () => {
        Animated.timing(                 // Animate over time
           this.state.headerAnim,            // The animated value to drive
           {
             toValue: 0,     
             duration: 600,              // Make it take a while
           }
         ).start();      
   }
   animatedActionDown = () => {
    Animated.timing(                 // Animate over time
       this.state.headerAnimDown,            // The animated value to drive
       {
         toValue: 56,     
         duration: 600,              // Make it take a while
       }
     ).start();      
}

    render() {
        return (
           <Container>
            {/* <Header
            hasTabs
            style={{ backgroundColor: '#fff' }}
            androidStatusBarColor='gray' 
            > */}
            <Animated.View
            style={{ 
                backgroundColor: '#fff',
                height: this.state.isVisible ? this.state.headerAnim : this.state.headerAnimDown
                }}
            >
            <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title={this.props.circleObj.circle_Name}
                rightButton=''
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
            />
            </Animated.View>
            {/* </Header>  */}
            <Tabs 
            tabBarUnderlineStyle={Styles.tabUnderLine}
            locked={true}
            >
                <Tab 
                heading='HOME' 
                tabStyle={Styles.whitebg}
                activeTabStyle={Styles.whitebg}
                textStyle={Styles.grayColor}
                activeTextStyle={Styles.blackColor}
                >
                    {/* <Home /> */}
                    <CircleHome 
                    circleCoach={this.props.circleObj}
                    onScrollpage={this.onScrollpage.bind(this)}
                    />
                </Tab>
                
                <Tab 
                heading='COACHES'
                tabStyle={Styles.whitebg}
                activeTabStyle={Styles.whitebg}
                textStyle={Styles.grayColor}
                activeTextStyle={Styles.blackColor}
                >
                <CircleCoaches 
                circleCoach={this.props.circleObj}
                onScrollpage={this.onScrollpage.bind(this)}
                />
                </Tab>
                <Tab 
                heading='MEMBERS'
                tabStyle={Styles.whitebg}
                activeTabStyle={Styles.whitebg}
                textStyle={Styles.grayColor}
                activeTextStyle={Styles.blackColor}
                >
                <CircleMembers
                circleCoach={this.props.circleObj}
                onScrollpage={this.onScrollpage.bind(this)}
                />
                </Tab>
                
                </Tabs>
            </Container>
        );
    }
}

const mapDispatchToProps = {
    clearAllCircleDetails
  };
  const mapStateToProps = (state) => {
    return (
      {

      }
  );
  };
  
export default connect(mapStateToProps, mapDispatchToProps)(CircleBase);
