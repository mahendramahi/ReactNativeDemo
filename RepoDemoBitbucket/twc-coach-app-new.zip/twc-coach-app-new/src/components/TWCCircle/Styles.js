import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    whitebg: {
        backgroundColor: '#fff'
    },
    tabUnderLine: {
        backgroundColor: '#27c5c6'
    },
    grayColor: {
        color: 'gray'
    },
    blackColor: {
        color: 'black'
    },
});
