import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
    root: {
        flex: 1,
        width: '100%',
        justifyContent: 'center',
        position: 'relative', 
    },
    mainContainer: {
        flex: 1,
        width: '100%',
        paddingTop: (Platform.OS === 'ios') ? 20 : 0,
    },
});
