import React, { Component } from 'react';
import { View } from 'react-native';
import { connect } from 'react-redux';
import CircleHome from './Component';
import { getPostList, clearCircleHome } from './../../../actions';


class CircleHomeContainer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      pageIndex: 1,
      pageSize: 10,
      refreshing: false,
    };
  }

  componentDidMount() {
    this.props.getPostList(this.state.pageIndex, this.state.pageSize, this.props.circleCoach.circleIdentity);
    this.setState({ pageIndex: (this.state.pageIndex + 1) });
  }

  onLoadMore = () => {
    this.props.getPostList(this.state.pageIndex, this.state.pageSize, this.props.circleCoach.circleIdentity);
    this.setState({ pageIndex: (this.state.pageIndex + 1) });
  };

  onRefresh = () => {
    //this.props.clearCircleHome();
    this.setState({ refreshing: true, pageIndex: 2 });
    this.props.getPostList(1, this.state.pageSize, this.props.circleCoach.circleIdentity);
    setTimeout(() => {
      this.setState({ refreshing: false });
    }, 170);
  };
  

  render() {
    return (
      <View style={{ flex: 1, height: '100%', width: '100%' }}>
        <CircleHome
        postList={this.props.postList}
        onLoadMore={this.onLoadMore.bind(this)}
        onRefresh={this.onRefresh.bind()}
        refreshing={this.state.refreshing}
        onScrollpage={this.props.onScrollpage}
        />
      </View>
    );
}

}

const mapDispatchToProps = {
  getPostList,
  clearCircleHome
};
const mapStateToProps = (state) => {
  return (
    {
      postList: state.circleHome.postList,
      isLoading: state.circleHome.isLoading
    }
);
};

export default connect(mapStateToProps, mapDispatchToProps)(CircleHomeContainer);
