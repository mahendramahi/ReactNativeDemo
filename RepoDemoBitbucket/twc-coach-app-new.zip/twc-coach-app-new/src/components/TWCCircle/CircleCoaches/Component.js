import React, { Component } from 'react';
import { View, Text, Image, FlatList } from 'react-native';
import styles from './Styles';
import Coach from './Coach';


const CircleCoachesComponent = (props) => {
    if (props.coachList && props.coachList.length > 0) {
      // the array is defined and has at least one element
          return (
          <View 
          style={{ flex: 1, }}
          >
          <FlatList
              data={props.coachList}
              extraData={props.coachList}
              renderItem={({ item }) => (
                <Coach
                key={item.userIdentity}
                coachItem={item}
                />
               )}
            keyExtractor={(item, index) => index.toString()}
          />
          </View>
          );
     } else {
       return (
        <View 
        style={{ flex: 1 }}
        ></View> 
       );
     }
};

export default CircleCoachesComponent;
