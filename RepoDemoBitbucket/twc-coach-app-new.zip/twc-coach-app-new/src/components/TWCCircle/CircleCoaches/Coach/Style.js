import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    imageroundx: {
        width: 70,
        height: 70,
        padding: 0,
        borderRadius: 100,
        overflow: 'hidden',
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        alignContent: 'center',
        marginLeft: 5,
        //marginTop: 7,
        marginRight: 10
      },
    circleimg: { 
        width: 70,
        height: 70,
        borderRadius: 24
    },
    circlecontent: {
        marginLeft: 15,
    },
    circlename: {
        fontSize: 15,
        color: 'black',
        fontWeight: '800',
        marginTop: 6
    },
    circlepost: {
        fontSize: 12,
        color: 'gray'
    },
    arrowright: {
        marginLeft: 'auto',
        marginTop: 35,
        width: 12,
        height: 12,    
    },
});
