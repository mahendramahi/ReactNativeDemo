import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Card, CardSection } from './../../../common';  //common';
import styles from './Style';
import UserAvatar from './../../../../ThirdParty/UserAvatar';

const Coach = ({ coachItem }) => {
    return (
        <View 
        style={{ margin: 7 }}
        >
        <TouchableOpacity
        onPress={() => {
        
        }}
        >
        <Card>
            <CardSection>
                <View style={styles.imageroundx}>
                        <UserAvatar 
                        name={coachItem.userName} 
                        src={coachItem.userImage} 
                        size={65} 
                        />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{coachItem.userName}</Text>
                    <Text style={styles.circlepost}>{`${coachItem.userRole}, ${coachItem.userExperience} yrs experience`}</Text>
                    <Text style={[styles.circlepost, { marginEnd: 90, color: 'black' }]} numberOfLines={2}>{coachItem.userBio}</Text>
                </View>
            </CardSection>
        </Card>
        </TouchableOpacity>
        </View>
    );
};

export default Coach;

