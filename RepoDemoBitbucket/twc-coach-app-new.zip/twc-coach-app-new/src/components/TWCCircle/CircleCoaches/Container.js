import React, { Component } from 'react';
import { RefreshControl, Platform, ScrollView, FlatList } from 'react-native';
import { connect } from 'react-redux';
//import PTRView from 'react-native-pull-to-refresh';
import { getCircleCoachesList, clearCircleCoach } from './../../../actions';
import Coach from './Coach';

import CircleCoaches from './Component';
import { View } from 'native-base';

class CircleCoachesContainer extends Component {

    constructor(props) {
      super(props);
      this.state = {
        refreshing: false,
      };
    }

    componentWillMount() {
      this.getCoachList();
    }

    // onRefresh() {
    //   this.props.clearCircleCoach();
    //     return new Promise((resolve) => {
    //         this.getCoachList();
    //         resolve(); 
    //     });
    // }

    
   onRefresh = () => {
      this.props.clearCircleCoach();
      this.setState({ refreshing: true });
      this.getCoachList();
      this.setState({ refreshing: false });
      this.forceUpdate();
   };

    getCoachList() {
      const request = {
        Id: this.props.circleCoach.circleIdentity
      };
      this.props.getCircleCoachesList(request);
    }

  render() {
    if (this.props.coachList && this.props.coachList.length > 0) {
    return (
      <View style={{ flex: 1 }}>
            {/* <PTRView
              style={{ backgroundColor: '#FFF' }}
              onRefresh={this.onRefresh.bind(this)}
            > */}
              <View style={{ flex: 1, justifyContent: 'center', position: 'relative' }}>
            <ScrollView 
            style={{
              flex: 1,
              paddingTop: (Platform.OS === 'ios') ? 20 : 0,
            }}
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}
            onScroll={(e) => {
                this.props.onScrollpage(e.nativeEvent.contentOffset.y);
              }}
              refreshControl={
                <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                />
              }
            > 
            <FlatList
              data={this.props.coachList}
              extraData={this.props.coachList}
              renderItem={({ item }) => (
                <Coach
                key={item.userIdentity}
                coachItem={item}
                />
               )}
            keyExtractor={(item, index) => index.toString()}
            /> 
          {/* <CircleCoaches
          coachList={this.props.coachList}
          /> */}
          </ScrollView>
      </View>
      {/* </PTRView> */}
      </View>
    );
    } else {
       return (
         <View></View>
       );
    }
}

}
// CircleCoachesContainer.propTypes = {
//   circleCoach: PropTypes.object.isRequired,
// }
const mapDispatchToProps = {
  getCircleCoachesList,
  clearCircleCoach
};
const mapStateToProps = (state) => {
  return (
    {
      coachList: state.circleCoach.coachList,
      isLoading: state.circleCoach.isLoading
    }
);
};

export default connect(mapStateToProps, mapDispatchToProps)(CircleCoachesContainer);
