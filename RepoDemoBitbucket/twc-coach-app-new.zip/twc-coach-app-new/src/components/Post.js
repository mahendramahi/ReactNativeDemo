import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity, Animated, TouchableHighlight
 } from 'react-native';
import { connect } from 'react-redux';
//import InViewPort from '../ThirdParty/InViewPort';
//import Video from 'react-native-video';
import VideoPlayer from 'react-native-video-controls';
import ParsedTextTWC from '../ThirdParty/ParseText/ParseTestTWC';
import { Actions } from 'react-native-router-flux';
import { updateHiFi, updateHifiFeed, updatePollOption, UpdatePoll } from '../actions';
import LinkPreviewCard from './LinkPreviewCard';
import UserAvatar from './../ThirdParty/UserAvatar';

//const LinkColor = (props) => <Text style={{ color: '#21AB9C' }}>{props.children}</Text>;

class Post extends Component {

    constructor(props) {
        super(props);
        this.onBackFromPostDetail = this.onBackFromPostDetail.bind(this);
        this.state = {
            visible: false,
            renderText: '',
            countNo: 0
        };
    }

    componentWillMount = async() => {
        const { postText, postIsHasTags, postTagList } = this.props.post;
        if (postIsHasTags) {
            let rendertextValue = postText;
            await postTagList.map((item, index) => {
                const string = '{{' + index + '}}';
                rendertextValue = rendertextValue.replace(string, `@${item.postTagName}`);
                this.setState({ renderText: rendertextValue });
            });
        } else {
            this.setState({ renderText: postText });
        }
    } 

    componentDidMount() {
        this.props.onRef(this);
      }

    componentWillUnmount() {
        this.props.onRef(undefined);
      }
    
    method = (count) => {
        this.setState({
            countNo: count
        });
        this.forceUpdate();
    }

    onBackFromPostDetail(val) {
        if (val) {
        this.forceUpdate();
        }
    }
    
    shouldComponentUpdate(nextProps, nextState) {
        return nextProps !== this.props;
    }
    
    clickOnHiFi(postItem) {
        const { postIdentity, postTotalHiFives, postMemberIsHi5 } = postItem;

        this.state = {
            post: this.props.post,
        };
        
        if (postMemberIsHi5) {
            this.state.post.postMemberIsHi5 = false;
            this.state.post.postTotalHiFives = postTotalHiFives - 1;
        } else {
            this.state.post.postMemberIsHi5 = true;
            this.state.post.postTotalHiFives = postTotalHiFives + 1;
        }
        this.props.updateHifiFeed(this.state.post);
        this.props.updateHiFi(postIdentity);
       // if (Actions.currentScene !== 'postDetail') {
        this.forceUpdate();
        // } else {
        //     this.forceUpdate();
        //     this.props.parentUpdate();
        // }
    }

    showCommentScreen = (post) => {
        if (Actions.currentScene !== 'postDetail') {
        Actions.postDetail({ postData: post, notificationData: null, callbackFunction: this.onBackFromPostDetail });
        }
    }

    onLinkShow = (url) => {
        Actions.webViewHelper({ fileData: url });
    };

    clickOnPollOption(post, item) {
        this.props.updatePollOption(post, item, this.props.position);
        this.forceUpdate();
    }

    handleatTheRatePress = (atTheRate) => {
        //alert(atTheRate);
        //Actions.hashTagsBase({ hashTag: atTheRate });
    };

    handleHashTagPress = (argHashTag) => {
        Actions.hashTagsBase({ hashTag: argHashTag });
    };

    handleUrlPress = (url) => {
        Actions.webViewHelper({ fileData: url });
    };

    renderHiFiStatus() {
        const { 
            postMemberIsHi5
        } = this.props.post;

        if (postMemberIsHi5) {
            return (
                <Image 
                style={{ width: 15, height: 17 }}
                    source={require('./images/high_five_stroke_icon-active.png')} 
                />
            );
        } return (
                <Image 
                style={{ width: 15, height: 17 }}
                    source={require('./images/hi5-icon.png')} 
                />
            );
    }

    renderPollQuestion(question) {
        return (
            <View
            style={{ flex: 1, width: '100%', margin: 5 }}
            >
                <Text
                style={{ color: 'black', fontSize: 16 }}
                >
                {question}</Text>
            </View>
        );
    }

    renderPollOptionItem(item) {
        let styleBorder = {};
        let styleText = {};
        const { answer, votePercentage, isAnswerGiven } = item;

        this.state = { 
            percentage: votePercentage,
            ans: answer,
            ansIsGiven: isAnswerGiven
        };

        if (this.state.ansIsGiven) {
            styleBorder = {
                borderColor: '#45C4BA'
            };
            styleText = {
                color: '#45C4BA'
            };
        }
        return (
            <TouchableOpacity
            key={item.identity}
            style={{ flex: 1, width: '100%', marginTop: 4, marginBottom: 4, marginEnd: 4, marginStart: 4, justifyContent: 'center' }}
            // onPress={this.clickOnPollOption.bind(this, this.props.post, item)}
            >
            <View 
            style={[styles.pollBox, { flex: 1, flexDirection: 'row', width: '100%', alignItems: 'center', padding: 4 }, styleBorder]}
            >
                <Text
                style={[styles.View_Inside_Text, { flex: 1 }, styleText]} 
                >
                {this.state.ans}
                </Text>
                <Text
                style={[styles.View_Inside_Text, { justifyContent: 'flex-end', alignSelf: 'flex-end' }, styleText]} 
                >
                {`${this.state.percentage} %`}
                </Text>
            </View>
            </TouchableOpacity>
        );
    }

    renderPollOption() {
        //const { identity } = contentData;
        if (this.props.post.contentData.answer != null) {
        const options = this.props.post.contentData.answer.map(item => {
            return (
                <Animated.View
                key={item.identity}
                style={{ flex: 1, width: '100%', justifyContent: 'center' }}
                >
                   {this.renderPollOptionItem(item)}
                </Animated.View>
            );
            }); 
            return (
                <Animated.View>
                {options}
                </Animated.View>
            );
        } else {
            return null;
        }
    }
    //     const { identity } = contentData;
    //     console.log('poll=== ans=' + JSON.stringify(contentData.answer));
    //     if (contentData.answer != null) {
    //     contentData.answer.map(item => {
    //        return (
    //            <View
    //            style={{ flex: 1, width: '100%' }}
    //            >
    //            <Text>{item.answer}</Text>
    //            {/* {this.renderPollOptionItem(item, identity)} */}
    //            </View>
    //        );
    //    });
    // } else {
    //     return null;
    // }
    

    renderPollPeriod(contentData) {
        let remainingDays = '';
        contentData.dayRemain === 1 ? remainingDays = `${contentData.dayRemain} day` : remainingDays = `${contentData.dayRemain} days`;
        return (
            <View
            style={{ flex: 1, width: '100%', marginTop: 5, marginStart: 5 }}
            >
                <Text
                style={{ color: 'gray', fontSize: 12 }}
                >
                {`This poll ends in ${remainingDays}`}</Text>
            </View>
        );
    }

    onBuffer = () => {

    }

    videoError = () => {
    }

    showHifiMemberList = (post) => {
        Actions.hifiMemberList({ data: post });
    }

    renderPollPost() {
        // this.state = {
        //     localPost: this.props.post
        // };
        const { contentData } = this.props.post;
        if (contentData != null) {
            return (
                <View 
                style={{ flex: 1, width: '100%' }}
                >
                {this.renderPollQuestion(contentData.question)}
                {this.renderPollOption()}
                {this.renderPollPeriod(contentData)}
                </View>
            );
        }
    }

    checkVisible = (isVisible) => {
        if (isVisible) {
          if (!this.state.visible) {
            this.setState({ visible: true });
          }
        } else {
          if (this.state.visible) {
            this.setState({ visible: false });
          }
        }
    }

    renderMedia() {
        const { 
            postIsHasMedia,
            postMediaList
        } = this.props.post;

        const aspectRatio = (height, width) => {
            return width / height;
        };

        if (postIsHasMedia && postMediaList.length > 0) {
            const postMediaType = postMediaList[0].postMediaType;
            const { title, desc, url, fileName, height, width } = postMediaList[0].postMediaData[0];
            if (postMediaType === 2) {
                const mediaObj = {
                        url: '' + url,
                        title: '' + title,
                        description: '' + desc,
                        images: [
                          '' + fileName
                        ],
                         };
                return (  
                <LinkPreviewCard
                media={mediaObj}
                onPreViewCross={null}
                isPostView={true}
                onPress={this.onLinkShow.bind(this, mediaObj.url)}
                />
                );
            } else if (postMediaType === 3) {
                return (
                <TouchableHighlight 
                onPress={
                    this.showCommentScreen.bind(this, this.props.post)}
                >
                <VideoPlayer
                   ref={(ref) => {
                        this.player = ref;
                    }}
                    showOnStart={true}
                    paused={true}
                    resizeMode={'cover'}
                    style={{
                        flex: 1,   
                        marginBottom: 10,
                        justifyContent: 'center',
                        paddingBottom: 30,
                        marginLeft: 1,
                        marginRight: -10,
                        aspectRatio: aspectRatio(height, width),
                    }}
                    volume={0}
                    source={{ uri: fileName }}
                    //source={{ uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' }}
                    navigator={this.props.navigator}
                    toggleResizeModeOnFullscreen={true}
                    //onEnterFullscreen={() => {
                        // alert('full Screen');
                        // this.player
                   //}}
                    //onExitFullscreen={() => {
                        //Actions.videoPlayerHelper();
                        //alert('full ScreenExit');
                  //}}
                    //controlTimeout={50}
                />
                </TouchableHighlight>
                );
            } else {
            return (
                <TouchableHighlight 
                onPress={this.showCommentScreen.bind(this, this.props.post)}
                >
                <Image 
                    style={{
                        resizeMode: 'contain',
                        flex: 1,
                        marginBottom: 10,
                        justifyContent: 'center',
                        paddingBottom: 30,
                        marginLeft: 1,
                        marginRight: -10,
                        aspectRatio: aspectRatio(height, width),
                    }} 
                    source={{ uri: fileName }} 
                />
                </TouchableHighlight>
            );
           }
        } else {
            return (
                <View
                style={{ flex: 1, width: '100%', marginTop: -15 }}
                >
                {this.renderPollPost()}
                </View>
            );
        }
    }

    renderHi5Count = () => {
        const { postTotalHiFives } = this.props.post;
        if (postTotalHiFives > 0) {
            return (
                <View style={styles.hi5Label}>                 
                    <TouchableOpacity
                    style={styles.button}
                    onPress={() => this.showHifiMemberList(this.props.post)}
                    >
                        <Image 
                        style={{ width: 10, height: 12 }}
                        source={require('./images/high_five_colored_icon.png')} />
                        <Text style={{ fontSize: 11, marginLeft: 5 }}> 
                                    {postTotalHiFives} {postTotalHiFives === 1 ? 'Hi-Five' : 'Hi-Fives' }
                        </Text>
                    </TouchableOpacity>                
                </View>
            );
        } else {
            return (
                <View style={styles.hi5Label} />   
            );              
        }
    }

    renderCommentCount() {
        const { postTotalComments } = this.props.post;
        let visibleCountNo = 0;
        if (postTotalComments => this.state.countNo) {
            visibleCountNo = postTotalComments;
        } else {
            visibleCountNo = this.state.countNo;
        }
        if (visibleCountNo > 0) {
            return (
                <View style={styles.commentLabel}>
                    <TouchableOpacity
                    onPress={this.showCommentScreen.bind(this, this.props.post)}
                    >
                            <Text style={{ fontSize: 11 }}> {postTotalComments} {postTotalComments === 1 ? 'comment' : 'comments' }</Text>
                    </TouchableOpacity>
                </View> 
            );
        }
    }

    renderUserImage(postCreatedByImage, postCreatedByName) {
    if (postCreatedByName !== null) {
        return (
            <UserAvatar
            name={postCreatedByName} 
            src={postCreatedByImage} 
            size={40} 
            />
        );
    }
    }


    render() {
        const {
            postIdentity,
            postCreatedByName, 
            postCreatedByImage, 
            postCreatedOn, 
            postText,
            postMapName,
            postIsHasTags,
            postTagList
        } = this.props.post;
        
        return (
            <View
            key={postIdentity}
            style={styles.cardStyle}
            >
            <View style={styles.cardSectionStyle}>
                <View
                key={postIdentity} 
                style={styles.activityrow}
                >
                    <View style={styles.headercol}>
                    {this.renderUserImage(postCreatedByImage, postCreatedByName)}
                        {/* <Image style={styles.userImage} source={{ uri: postCreatedByImage }} /> */}
                        <View style={styles.headercontent}>
                            <Text style={styles.userName}>{postCreatedByName}
                            <Text style={{ color: '#000' }}>{' has posted in '}
                            <Text style={styles.userName}>{postMapName}</Text>
                            </Text>
                            </Text>
                            <Text style={styles.dateadded}>{postCreatedOn}</Text>
                        </View>
                    </View> 
                    {/* <Text style={styles.postcontent}>
                        {postText}
                    </Text> */}
                    <ParsedTextTWC
                    style={styles.postcontent}
                    parse={
                    [
                    { type: 'url', style: { color: '#45c4ba', textDecorationLine: 'underline' }, onPress: (url) => this.handleUrlPress(url) },
                    { type: 'hashTag', style: { color: '#45c4ba', fontWeight: 'bold', textDecorationLine: 'underline' }, onPress: (hashTag) => this.handleHashTagPress(hashTag) },
                    { type: 'atTheRate', style: { color: '#45c4ba', fontWeight: 'bold' }, onPress: (atTheRate) => this.handleatTheRatePress(atTheRate) },
                    ]
                    }
                    childrenProps={{ allowFontScaling: false }}
                    >
                    {this.state.renderText}
                    </ParsedTextTWC>
                    {this.renderMedia()}
                    <View style={styles.labelSection}>
                        {this.renderHi5Count()}
                        {this.renderCommentCount()}
                    </View> 

                    <View style={{ height: '0.08%', backgroundColor: '#e5e5e5', width: '100%' }} />
                    
                    <View style={styles.useraction}>
                        <View style={styles.actioncol}>                
                            <TouchableOpacity 
                            style={styles.button}
                            onPress={this.clickOnHiFi.bind(this, this.props.post)}
                            >
                            {this.renderHiFiStatus()}
                            
                                <Text style={styles.actiontext}> Hi-5</Text>
                            </TouchableOpacity>                
                        </View>
                        <View style={styles.actioncol}>
                            <TouchableOpacity 
                            style={styles.button}
                            onPress={this.showCommentScreen.bind(this, this.props.post)}
                            >
                                <Image style={styles.actionicon} source={require('./images/comment-icon.png')} />
                                <Text style={styles.actiontext}> Comment</Text>
                            </TouchableOpacity>
                        </View>                
                    </View> 
                </View>
            </View>
            </View>
        );
    }
}

const styles = {
    cardStyle: {
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: '#fff',
        borderColor: '#fff',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 1,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
        paddingRight: 3,
        paddingLeft: 3
    },
    cardSectionStyle: {
        padding: 5,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        position: 'relative'
    },
    activityrow: {
        borderWidth: 0,    
        marginTop: 5,
        flex: 1,
    },
    headercol: {    
        justifyContent: 'flex-start',
        alignItems: 'center',
        borderWidth: 0,
        flexDirection: 'row',        
    },
    userImage: {
        width: 40,
        height: 40,
        borderRadius: 20,    
        borderWidth: 0,        
    },
    headercontent: {    
        borderWidth: 0,
        flexGrow: 1,    
        width: 0,
        marginLeft: 10
    },
    userName: {
        fontSize: 13,
        fontWeight: '400',
        color: '#45c4ba',
        flexWrap: 'wrap'    
    },
    dateadded: {
        fontSize: 10,
        fontWeight: '300',
        color: 'gray',
        opacity: 0.8
      },
    postcontent: {
        marginVertical: 10,
        fontSize: 14,
        lineHeight: 18,
        color: 'black',
    },
    useraction: {    
        flexDirection: 'row',
        //borderTopWidth: 1,
        //borderColor: '#ccc'    
    },
    labelSection: {
        marginTop: 4,
        marginBottom: 4,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    hi5Label: {
        paddingTop: 8,
        lineHeight: 18
    },
    commentLabel: {
        paddingTop: 8
    },
    actioncol: {    
        flexDirection: 'row',    
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        paddingVertical: 5   
    },
    button: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        paddingVertical: 5
    },
    pollBox: {
        backgroundColor: '#fff',
        borderRadius: 4,
        borderWidth: 1,
        justifyContent: 'center',
        borderColor: '#979797',
        alignSelf: 'center',
    },
    View_Inside_Text:
    {
        color: 'gray',
        fontSize: 14,
        alignSelf: 'flex-start'
    },
};

const mapStateToProps = (state) => {
    return (
        {
            postId: state.postId,
            data: state.data,
        }
    );
};

export default connect(mapStateToProps, 
    { updateHiFi, updateHifiFeed, updatePollOption, UpdatePoll })(Post);
