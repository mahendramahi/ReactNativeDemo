import React, { Component } from 'react';
import { Text, FlatList, View } from 'react-native';
import styles from './Styles';
import ChatRow from './ChatRow';
import NoDataView from './../../common/NoDataView';


const emptyList = () => {
    return (
        <NoDataView />
    );
};

const ChatListComponent = (props) => {
  return (
    // <View>
    //   <Text>Hello</Text>
    // </View>
    <FlatList 
      data={props.chatList}
      extraData={props}
      ListEmptyComponent={emptyList()}
      renderItem={({ item }) => (
        <ChatRow
          key={item.ChatId}
          chatRowItem={item}
          onResume={props.onResume}
        />
      )}
      keyExtractor={(item, index) => index.toString()}
    />
  );
};


export default ChatListComponent;
