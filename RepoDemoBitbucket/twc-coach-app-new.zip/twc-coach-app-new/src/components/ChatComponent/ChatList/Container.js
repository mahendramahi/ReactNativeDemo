import React, { Component } from 'react';
import { AppState } from 'react-native';
import { connect } from 'react-redux';
import { Container,
  Header,
  Content } from 'native-base';
import { Actions } from 'react-native-router-flux';
import ChatList from './Component';
import ChatHead from './ChatHead';
import { getChatList } from './../../../actions';

class ChatListContainer extends Component {

  constructor(props) {
    super(props);
    this.onResume = this.onResume.bind(this);
    this.state = {
      appState: AppState.currentState,
    };
  }

  componentDidMount() {
    //console.log('Chat List Did mount');
    this.onResume();
    AppState.addEventListener('change', this.handleAppStateChange);
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this.handleAppStateChange);
    this.props.callbackFunction();
  }
  // componentWillUnmount() {
  //   this.props.
  // }

  onOptionMenuClick = () => {
    Actions.pop();
  };

  onResume() {
    this.props.getChatList();
    this.forceUpdate();
  }

  handleAppStateChange = (nextAppState) => {
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      //console.log('App has come to the foreground!');
      this.onResume();
    }
    this.setState({ appState: nextAppState });
  }

  render() {
    return (
      <Container>
      <Header 
      style={{ backgroundColor: '#fff' }}
      androidStatusBarColor='#35AEA4' 
      >
      <ChatHead
        title='Messages'
        rightButton=''
        onRightButtonClick={this.onOptionMenuClick.bind(this)}
        hideCrossIcon={false}
      />
      </Header> 
      <Content padder >
       <ChatList
         chatList={this.props.chatList}
         onResume={this.onResume}
       />
      </Content>
      </Container>
      
    );
  }
}

const mapDispatchToProps = {
  getChatList,
};

const mapStateToProps = (state) => {
  return (
    {
      chatList: state.socket.chatList
    }
  );
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatListContainer);
