import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        padding: 14,
        backgroundColor: '#FFF',
        elevation: 2,
    },
    title: {
        fontSize: 16,
        color: '#000',
    },
    container_text: {
        flex: 1.3,
        flexDirection: 'column',
        marginLeft: 12,
        marginTop: 6,
        justifyContent: 'center',
    },
    description: {
        fontSize: 11,
        fontStyle: 'italic',
    },
    photo: {
        height: 50,
        width: 50,
    },
    unreadCount: {
    padding: 2,
    backgroundColor: 'red',
    zIndex: 5,
    width: 19,
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    right: 25,
    bottom: -5, 
    borderRadius: 20, 
    elevation: 10
    }
});
