import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Actions } from 'react-native-router-flux';
import ChatRow from './Component';
import { initChatFormAction } from './../../../../actions';

class ChatRowContainer extends Component {

  constructor(props) {
    super(props);
    this.onCallBackChatWindow = this.onCallBackChatWindow.bind(this);
  }


  onChatListItemCLick = (item) => {
    this.props.initChatFormAction(item.ChatId);
    Actions.chatWindow({ chatId: item.ChatId, callbackFunction: this.onCallBackChatWindow });//chatUserItem: item, callbackFunction: this.onCallBackChatWindow });
  }

  onCallBackChatWindow() {
    this.props.onResume();
  }

  render() {
    return (
      <ChatRow
      key={this.props.chatRowItem.ChatId}
      chatRowItem={this.props.chatRowItem}
      onChatListItemCLick={this.onChatListItemCLick}
      />
    );
  }
}
const mapDispatchToProps = { 
  initChatFormAction
};

const mapStateToProps = (state) => {
  return (
      {
        
      }
  );
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatRowContainer);
