import React, { Component } from 'react';
import moment from 'moment';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from './Styles';
import UserAvatar from './../../../../ThirdParty/UserAvatar';
import TouchableDebounce from '../../../../ThirdParty/TouchableDebounce';

const renderMessageType = (objMessage) => {
    if (objMessage.TypeId === 1) {
        return (
            <Text 
            style={[styles.description, { marginTop: 5 }]}
            numberOfLines={1}
            >
            {objMessage.Message}
            </Text>
        );
    } else if (objMessage.TypeId === 2) {
            return (
            <View
            style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-start', alignContent: 'center' }}
            >
            <Image 
            resizeMode={'contain'}
            style={{ marginTop: 10, padding: 2, height: 10, width: 13 }}
            source={require('./../../../images/cameraIcon.png')}
            />
            <Text
            style={{ marginTop: 5, padding: 2, fontSize: 10 }}
            > Image</Text>
            </View>
            );
    } else {
        return (
            <View
            style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-start', alignContent: 'center' }}
            >
            <Image 
            resizeMode={'contain'}
            style={{ marginTop: 10, padding: 2, height: 10, width: 13 }}
            source={require('./../../../images/pdfIcon.png')}
            />
            <Text
            style={{ marginTop: 5, padding: 2, fontSize: 10 }}
            > File</Text>
            </View>
            );
    }
};

const renderTime = (objMessage) => {
    const todayDate = new Date();
    const mydate = moment.utc(objMessage.SendOn).toDate();
	//var localTime = moment(mydate).local().format("h:mm a");
    const msgDate = new Date(moment(mydate).local());

    const seconds = Math.round((todayDate.getTime() - msgDate.getTime()) / 1000);
    const minutes = Math.round(seconds / 60);
    const hours = Math.round(minutes / 60);
    const days = Math.round(hours / 24);
    const weeks = Math.round(seconds / 604800);
    const months = Math.round(seconds / 2600640);
    const years = Math.round(seconds / 31207680);
    let timeStatus = '';
    // Seconds
    if (seconds <= 30) {
        timeStatus = 'just now';
    } else if (seconds <= 60) {
        timeStatus = `${seconds} seconds ago`;
    } else if (minutes <= 60) {
        //Minutes
        if (minutes === 1) {
            timeStatus = 'one minute ago';
        } else {
            timeStatus = `${minutes} minutes ago`;
        }
    } else if (hours <= 24) {
        //Hours
        if (hours === 1) {
            timeStatus = 'an hour ago';
        } else {
            timeStatus = `${hours} hours ago`;
        }
    } else if (days <= 7) {
        //Days
        if (days === 1) {
            timeStatus = 'yesterday';
        } else {
            timeStatus = `${days} days ago`;
        }
    } else if (weeks <= 4.3) {
            //Weeks
        if (weeks === 1) {
            timeStatus = 'a week ago';
        } else {
            timeStatus = `${weeks} weeks ago`;
        }
    } else if (months <= 12) {
        //Months
        if (months === 1) {
            timeStatus = 'a month ago';
        } else {
            timeStatus = `${months} months ago`;
        }
    } else { //Years
        if (years === 1) {
            timeStatus = 'one year ago';
        } else {
            if (months % 12 <= 6) {
                timeStatus = `${years} years ago`;
            } else {
                const y = years + 1;
                timeStatus = `${y} years ago`;
            }
        }
    }
    
    //let sendon = objMessage. 
    return (
    <View 
    style={{ flex: 0.4, marginTop: 10 }}
    >
    <Text
    style={{ justifyContent: 'flex-end', alignContent: 'flex-end', fontSize: 8 }}
    >
    {timeStatus}
    </Text>
    </View>
    );
};

const renderCountno = (Count) => {
    if (Count === 0) {
        return null;
    } else if (Count > 9) {
        return (
            <TouchableOpacity 
            activeOpacity={0.1}
            style={styles.unreadCount}
            >
            <Text
            style={{ fontSize: 10, color: 'white' }}
            >9+</Text>
            </TouchableOpacity>
        );
    } else {
        return (
            <TouchableOpacity 
            activeOpacity={0.1}
            style={styles.unreadCount}
            >
            <Text
            style={{ fontSize: 10, color: 'white' }}
            >{Count}</Text>
            </TouchableOpacity>
        );
    }
};

const renderUserImage = (chatRowItem) => {
    if (chatRowItem.Image !== null && !chatRowItem.Image.includes('initial-image.png')) {
        return (
            <UserAvatar
                    name={chatRowItem.Name}
                    src={chatRowItem.Image}
                    size={60}
            />
        );
    } else {
        return (
            <UserAvatar
                    name={chatRowItem.Name}
                    src={''}
                    size={60}
            />
        );
    }
};


const ChatRowComponent = (props) => {
  const localMessage = props.chatRowItem.Message;
  const objMessage = JSON.parse(localMessage)[0];
  const { Count } = objMessage;

  return (
    <View >
    <TouchableDebounce
    style={styles.container}
    onPress={() => props.onChatListItemCLick(props.chatRowItem)}
    >
    {/* <Image source={{ uri: props.chatRowItem.Image }} style={styles.photo} /> */}
    {renderUserImage(props.chatRowItem)}
    <View style={styles.container_text}>
        <Text style={styles.title}>
           {props.chatRowItem.Name}
        </Text>
        {renderMessageType(objMessage)}
    </View>
    {renderTime(objMessage)}
    <View 
    style={{ flex: 0.3, marginTop: 10 }}
    >
    {renderCountno(Count)}
    </View>
     </TouchableDebounce>
</View>
  );
};

export default ChatRowComponent;
