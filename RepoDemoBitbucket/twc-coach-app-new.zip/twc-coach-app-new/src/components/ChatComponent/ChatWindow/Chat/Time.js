import React from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image
} from 'react-native';

import moment from 'moment';

const renderMsgStatus = (timeProps) => {
    if (timeProps.position === 'right') {
    if (timeProps.currentMessage.Status === 0) {
        return (
            <Image 
            style={{ width: 10, height: 10, marginTop: 3, marginStart: 5 }}
                source={require('./../../../images/unread.png')}
            />
        );
       // unread
    } else if (timeProps.currentMessage.Status === 1) {
        return (
            <Image
            style={{ width: 10, height: 10, marginTop: 3, marginStart: 5 }}
                source={require('./../../../images/delivered.png')}
            />
        );
        //delivered
    } else if (timeProps.currentMessage.Status === 2) {
        return (
            <Image 
            style={{ width: 10, height: 10, marginTop: 3, marginStart: 5 }}
                source={require('./../../../images/read.png')}
            />
        );
        //read
    } else {
        return null;
    }
} else {
    return null;
}
};

const Time = (props) => {
        return (
            <View style={[styles[props.timeProps.position].container, containerStyle[props.timeProps.position]]}>
            <View 
            style={{ flexDirection: 'row', justifyContent: 'flex-end', alignContent: 'flex-end' }}
            >
                <Text style={[styles[props.timeProps.position].text, textStyle[props.timeProps.position]]}>
                {/* {props.timeProps.currentMessage.SendOn} */}
                    {moment(moment.utc(props.timeProps.currentMessage.SendOn).toDate()).local().format('hh:mm A')}
                </Text>
                {renderMsgStatus(props.timeProps)}
            </View>
            </View>
        );
};

const containerStyle = {
    marginLeft: 10,
    marginRight: 10,
    marginBottom: 5,
};

const textStyle = {
    fontSize: 10,
    backgroundColor: 'transparent',
    textAlign: 'right',
};

const styles = {
    left: StyleSheet.create({
        container: {
            ...containerStyle,
            
        },
        text: {
            color: '#aaa',
            ...textStyle,
        },
    }),
    right: StyleSheet.create({
        container: {
            ...containerStyle,
        },
        text: {
            color: '#fff',
            ...textStyle,
        },
    }),
};

export default Time;
