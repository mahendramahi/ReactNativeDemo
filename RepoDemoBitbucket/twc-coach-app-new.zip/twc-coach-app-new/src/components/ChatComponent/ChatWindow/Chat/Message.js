import React, { Component } from 'react';
import {
    View, Text,
    StyleSheet,
} from 'react-native';
import Bubble from './Bubble';

// import Avatar from './Avatar';
// import Bubble from './Bubble';
import Day from './Day';

// import {isSameUser, isSameDay} from './utils';

const renderDay = (messageProps) => {
        if (messageProps.currentMessage.SendOn) {
            return <Day dayProps={messageProps} />;
        }
        return null;
    };

const renderBubble = (messageProps) => {
        // return (
        //     <View>
        //     <Text>{message.currentMessage.Message}</Text>
        //     </View>
        // );
        // const bubbleProps = this.getInnerComponentProps();
        return <Bubble bubbleProps={messageProps} />;
    };

const renderAvatar = () => {
        return (
            <View>
            <Text>Hello Avatar</Text>
            </View>
        );
        // if (this.props.user._id !== this.props.currentMessage.user._id) {
        //     const avatarProps = this.getInnerComponentProps();
        //     return <Avatar {...avatarProps}/>;
        // }
        // return null;
    };

const Message = (props) => {
        return (
            <View>
                {renderDay(props.messageProps)}
                <View 
                style={[styles[props.messageProps.position].container, 
                {
                    marginBottom: 5,
                }]}
                >
                    {/* {this.props.position === 'left' ? this.renderAvatar() : null} */}
                    {renderBubble(props.messageProps)}
                    {/* {this.props.position === 'right' ? this.renderAvatar() : null} */}
                </View>
            </View>
        );
    };

    const styles = {
        right: StyleSheet.create({
            container: {
                flexDirection: 'row',
                alignItems: 'flex-end',
                justifyContent: 'flex-start',
                marginLeft: 8,
                marginRight: 0,
            },
        }),
        left: StyleSheet.create({
            container: {
                flexDirection: 'row',
                alignItems: 'flex-end',
                justifyContent: 'flex-end',
                marginLeft: 0,
                marginRight: 8,
            },
        }),
    };
    
 export default Message;    
