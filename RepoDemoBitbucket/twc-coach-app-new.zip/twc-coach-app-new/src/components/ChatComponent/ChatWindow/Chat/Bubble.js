import React from 'react';
import {
    StyleSheet,
    TouchableWithoutFeedback,
    TouchableOpacity,
    ImageBackground,
    View, Text, Image, ActivityIndicator
} from 'react-native';
import Video from 'react-native-video';
import { Actions } from 'react-native-router-flux';
import ParsedTextTWC from '../../../../ThirdParty/ParseText/ParseTestTWC';
import Time from './Time';


const handleUrlPress = (url, matchIndex /*: number*/) => {
    Actions.webViewHelper({ fileData: url });    
    //LinkingIOS.openURL(url);
  };

const renderTime = (bubbleProps) => {
        return <Time timeProps={bubbleProps} />;
    };
    
    const renderMessageText = (bubbleProps) => {
        if (bubbleProps.currentMessage.TypeId === 1) {
        return (
            <View
            style={{ marginLeft: 10, marginRight: 10 }}
            >
            <ParsedTextTWC 
            style={[styles[bubbleProps.position].text]}
            parse={
            [
              { type: 'url', style: styles.url, onPress: (url) => handleUrlPress(url) },
            ]
          }
          childrenProps={{ allowFontScaling: false }}
            >
            {bubbleProps.currentMessage.Message}
            </ParsedTextTWC>
                {/* <Text
                style={[styles[bubbleProps.position].text]}
                >
                {bubbleProps.currentMessage.Message}</Text> */}
            </View>
        );
        } else {
            return null;
        }
    };

    const renderMessageImage = (bubbleProps) => {
        if (bubbleProps.currentMessage.TypeId === 2) {
            const messageImage = JSON.parse(bubbleProps.currentMessage.Message);
            const isloading = bubbleProps.currentMessage.MessageId;
            return (
                <TouchableOpacity
                style={{ marginLeft: 10, marginRight: 10 }}
                onPress={() => {
                    Actions.imageDetail({ imageData: messageImage.FileName });
                }}
                >
                    <Image
                    style={[styles[bubbleProps.position].image]}
                    source={{ uri: messageImage.FileName }}
                    />
                    {isloading < 0 ? showPreogres() : null}
                </TouchableOpacity>
            );
        } else {
            return null;
        }
    };

    const showPreogres = () => {
        return (
            <ActivityIndicator
            size='large'
            color='#e5e5e5'
            style={styles.circleProgress}
            /> 
        );
    };

    const playIcon = (url) => {
        return (
            <TouchableOpacity
            onPress={() => {
            }}
            >
            <Image
            style={{ position: 'absolute', zIndex: 10, justifyContent: 'center' }}
            source={require('../../../images/play_icon.png')}
            /> 
            </TouchableOpacity>
        );
    }

    const renderMessageVideo = (bubbleProps) => {
        if (bubbleProps.currentMessage.TypeId === 3) {
            const messageVideo = JSON.parse(bubbleProps.currentMessage.Message);
            const isloading = bubbleProps.currentMessage.MessageId;
            return (
                <TouchableOpacity 
                style={{ padding: 3 }}
                onPress={() => {
                    Actions.videoPlayerHelper({ videoUrl: messageVideo.FileName });
                }}
                >
                <Video
                ref={(c) => {
                    this.player = c;
                }}
                paused={true}
                style={[styles[bubbleProps.position].file]}
                source={{ uri: messageVideo.FileName }}
                >
                {isloading < 0 ? showPreogres() : null}
                </Video>
                <TouchableOpacity
                style={{ position: 'absolute', justifyContent: 'center' }}
                onPress={() => {
                    Actions.videoPlayerHelper({ videoUrl: messageVideo.FileName });
                }}
                >
                <Image
                style={{ justifyContent: 'center' }}
                source={require('../../../images/play_icon.png')}
                />   
                </TouchableOpacity>
                </TouchableOpacity>
            );
        } else {
            return null;
        }
    };

    const renderMessageFile = (bubbleProps) => {
        if (bubbleProps.currentMessage.TypeId === 4 || bubbleProps.currentMessage.TypeId === 5) {
            const messageImage = JSON.parse(bubbleProps.currentMessage.Message);
            const isloading = bubbleProps.currentMessage.MessageId;
            return (
                <TouchableOpacity
                style={{ marginLeft: 10, marginRight: 10 }}
                onPress={() => {
                    Actions.webViewHelper({ fileData: `http://docs.google.com/gview?embedded=true&url=${messageImage.FileName}` });
                }}
                >
                    <Image
                    style={[styles[bubbleProps.position].file]}
                    source={require('./../../../images/pdfIcon.png')}
                    />
                    {isloading < 0 ? showPreogres() : null}
                </TouchableOpacity>
            );
        } else {
            return null;
        }
    };

        // if (this.props.currentMessage.text) {
        //     const {containerStyle, wrapperStyle, ...messageTextProps} = this.props;
        //     if (this.props.renderMessageText) {
        //         return this.props.renderMessageText(messageTextProps);
        //     }
        //     return <MessageText {...messageTextProps}/>;
        // }
        // return null;
    

    // renderMessageImage() {
    //     if (this.props.currentMessage.image) {
    //         const {containerStyle, wrapperStyle, ...messageImageProps} = this.props;
    //         if (this.props.renderMessageImage) {
    //             return this.props.renderMessageImage(messageImageProps);
    //         }
    //         return <MessageImage {...messageImageProps}/>;
    //     }
    //     return null;
    // }
const Bubble = (props) => {
        return (
            <View style={[styles[props.bubbleProps.position].container]}>
                <View
                    style={[styles[props.bubbleProps.position].wrapper]}
                >
                    <TouchableWithoutFeedback
                        accessibilityTraits="text"
                    >
                        <View>
                            {/* {this.renderCustomView()}
                            {this.renderMessageImage()} */}
                            {renderMessageText(props.bubbleProps)}
                            {renderMessageImage(props.bubbleProps)}
                            {renderMessageFile(props.bubbleProps)}
                            {renderMessageVideo(props.bubbleProps)}
                            {renderTime(props.bubbleProps)}
                            
                        </View>
                    </TouchableWithoutFeedback>
                </View>
            </View>
        );
    };

const styles = {
    url: {
        color: 'blue',
        textDecorationLine: 'underline',
      },
     
      email: {
        color: 'blue',
        textDecorationLine: 'underline',
      },
     
      text: {
        color: 'black',
        fontSize: 15,
      },
     
      phone: {
        color: 'blue',
        textDecorationLine: 'underline',
      },
     
      name: {
        
      },
    circleProgress: {
        position: 'absolute',
        backgroundColor: '#4000',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 100
    },
    left: StyleSheet.create({
        container: {
            flex: 1,
            alignItems: 'flex-start',
        },
        wrapper: {
            borderRadius: 15,
            backgroundColor: '#fff',
            marginRight: 60,
            marginLeft: 10,
            minHeight: 20,
            justifyContent: 'flex-end',
            borderColor: '#ddd',
            borderBottomWidth: 1,
            borderTopWidth: 0.4,
            shadowColor: '#000',
            shadowOffset: { width: 1, height: 2 },
            shadowOpacity: 0.8,
            shadowRadius: 2,
            elevation: 2,
        },
        text: {
            color: 'black',
            fontSize: 14,
        },
        image: {
            width: 150,
            height: 100,
            borderRadius: 0,
            margin: 2,
            resizeMode: 'cover',
          },
          file: {
            width: 100,
            height: 80,
            borderRadius: 12,
            margin: 3,
            resizeMode: 'cover',
          },
        containerToNext: {
            borderBottomLeftRadius: 3,
        },
        containerToPrevious: {
            borderTopLeftRadius: 3,
        },
    }),
    right: StyleSheet.create({
        container: {
            flex: 1,
            alignItems: 'flex-end',
            
        },
        wrapper: {
            borderRadius: 15,
            backgroundColor: '#45C4BA',
            marginLeft: 60,
            marginRight: 10,
            minHeight: 20,
            justifyContent: 'flex-end',
            borderColor: '#ddd',
            borderBottomWidth: 1,
            borderTopWidth: 0.4,
            shadowColor: '#000',
            shadowOffset: { width: 1, height: 2 },
            shadowOpacity: 0.8,
            shadowRadius: 2,
            elevation: 2,
        },
        text: {
            color: 'white',
            fontSize: 14,
        },
        image: {
            width: 150,
            height: 100,
            borderRadius: 0,
            margin: 2,
            resizeMode: 'cover',
          },
          file: {
            width: 100,
            height: 80,
            borderRadius: 12,
            margin: 3,
            // resizeMode: 'cover',
          },
        containerToNext: {
            borderBottomRightRadius: 3,
        },
        containerToPrevious: {
            borderTopRightRadius: 3,
        },
    }),
};

export default Bubble;
