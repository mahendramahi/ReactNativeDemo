import React, { Component } from 'react';
import { View, Image, Dimensions, TouchableOpacity } from 'react-native';
import { Container,
    Header,
    Footer, Left, Body, Right,
    Content } from 'native-base';
import { Actions } from 'react-native-router-flux';
import ImageZoom from 'react-native-image-pan-zoom';
import ToolBarWithBackArrow from '../../../common/ToolBarWithBackArrow';


export default class ImageDetail extends Component {


    onBackArrowPressed() {
        Actions.pop();
    }

    onOptionMenuClick() {

    }

    render() {
        return (
            <Container 
            style={{ backgroundColor: '#fff' }}
            >
            <Header 
                style={{ backgroundColor: '#fff' }}
                androidStatusBarColor='gray' 
            >
            <ToolBarWithBackArrow
                onPress={this.onBackArrowPressed.bind(this)}
                title=''
                rightButton=''
                onRightButtonClick={this.onOptionMenuClick.bind(this)}
                hideCrossIcon
            />
            </Header> 
            <Content padder >
            <ImageZoom 
            cropWidth={Dimensions.get('window').width}
            cropHeight={Dimensions.get('window').height - 90}
                       imageWidth={200}
                       imageHeight={200}
            >
                <Image 
                style={{ width: 200, height: 200 }}
                source={{ uri: this.props.imageData }}
                />
            </ImageZoom>
            </Content> 
            </Container>
            );
        }
}
