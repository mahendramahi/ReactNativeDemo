import React, { Component } from 'react';
import { Dimensions, View } from 'react-native';
import VideoPlayer from 'react-native-video-controls';
import { Actions } from 'react-native-router-flux';

export default class VideoPlayerHelper extends Component {

    aspectRatio = (height, width) => {
        return width / height;
    };
    render() {
        return (
            <View
            style={{ flex: 1, justifyContent: 'center' }}
            >
            <VideoPlayer
                   ref={(ref) => {
                        this.player = ref;
                    }}
                    showOnStart={true}
                    repeat={true}
                    resizeMode={'cover'}
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        //aspectRatio: this.aspectRatio(Dimensions.get('window').width, Dimensions.get('window').height)
                    }}
                    volume={0}
                    //source={{ uri: fileName }}
                    source={{ uri: this.props.videoUrl }}
                    navigator={this.props.navigator}
                    toggleResizeModeOnFullscreen={false}
                    onBack={() => {
                        Actions.pop();
                    }}
            />
            </View>
            );
        }
}
