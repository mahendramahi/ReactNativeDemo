import React, { Component } from 'react';
import { View } from 'react-native';
import { Actions } from 'react-native-router-flux';
import Webbrowser from 'react-native-custom-webview';

export default class WebViewHelper extends Component {

    render() {
        return (
            <View
            style={{ flex: 1 }}
            >
                <Webbrowser
                    url={this.props.fileData}  
                    hideHomeButton={false}
                    hideToolbar={false}
                    hideAddressBar={false}
                    hideStatusBar={false}
                    backButtonVisible={true}
                    onBackPress={() => {
                        Actions.pop();
                    }}
                    foregroundColor="#fff"
                    backgroundColor="#000"
                />
                </View>
            );
        }
}
