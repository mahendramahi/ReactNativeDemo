import { StyleSheet } from 'react-native';
import { moderateScale } from 'react-native-size-matters';

export default StyleSheet.create({
    footerContainer: {
        marginTop: 5,
        marginLeft: 10,
        marginRight: 10,
        marginBottom: 10,
      },
      footerText: {
        fontSize: 14,
        color: '#aaa',
      },
      footer: {
        height: 55,
        flexDirection: 'row',
        backgroundColor: '#fff'
      },
      input: {
        marginBottom: 8,
        marginTop: 8,
        marginLeft: 3,
        marginRight: 3,
        paddingHorizontal: 20,
        fontSize: 16,
        flex: 1,
        borderColor: '#e5e5e5',
        borderWidth: 2,
        borderRadius: 20
      },
      send: {
        alignSelf: 'center',
        color: 'lightseagreen',
        fontSize: 16,
        fontWeight: 'bold',
        padding: 20
      },
      container: {
        flex: 1,
        marginTop: 1,
        marginBottom: 1,
        backgroundColor: '#fff',
        justifyContent: 'center'
      },
      item: {
        marginVertical: moderateScale(7, 2),
        flexDirection: 'row'
     },
     itemIn: {
         marginLeft: 20
     },
     itemOut: {
        alignSelf: 'flex-end',
        marginRight: 20
     },
     balloon: {
        maxWidth: moderateScale(250, 2),
        paddingHorizontal: moderateScale(10, 2),
        paddingTop: moderateScale(5, 2),
        paddingBottom: moderateScale(7, 2),
        borderRadius: 20,
     },
     arrowContainer: {
         position: 'absolute',
         top: 0,
         left: 0,
         right: 0,
         bottom: 0,
         zIndex: -1,
         flex: 1
     },
     arrowLeftContainer: {
         justifyContent: 'flex-end',
         alignItems: 'flex-start'
     },
 
     arrowRightContainer: {
         justifyContent: 'flex-end',
         alignItems: 'flex-end',
     },
 
     arrowLeft: {
         left: moderateScale(-6, 0.5),
     },
 
     arrowRight: {
         right: moderateScale(-6, 0.5),
     }
});
