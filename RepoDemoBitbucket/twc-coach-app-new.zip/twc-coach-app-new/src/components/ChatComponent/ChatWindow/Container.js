import React, { Component } from 'react';
import Config from 'react-native-config';
import { Text, View, KeyboardAvoidingView, TextInput, TouchableOpacity
, FlatList, Image, AppState, Animated, VirtualizedList } from 'react-native';
import { connect } from 'react-redux';
import moment from 'moment';
//import { base64 } from 'file-base64';
import { DocumentPicker, DocumentPickerUtil } from 'react-native-document-picker';
import ImagePicker from 'react-native-image-picker';
//import ImgToBase64 from 'react-native-image-base64';
// import ChatWindow from './Component';
import styles from './Styles';
import ChatHead from './ChatHead';
import { setClientMessageHistory, setClientChatUser,
  setChatConversationAction, sendMsgAction, removeConversationListner,
  sendTypingStatus, mediaMsgUpload, addNewMediaMsg, actionSendMediaMsg,
  removeChatHistoryData, getUserOldMessageHistory } from './../../../actions';
import { Actions } from 'react-native-router-flux';
import Message from './Chat/Message';
import { MEDIA_TYPE_PDF, MEDIA_TYPE_IMAGE, KEY_TAKE_PHOTO } from './../../../constant/string';
import { showToast } from '../../Utility';
import Transloadit from '../../../nativeModule/Transloadit';

class ChatWindowContainer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      appState: AppState.currentState,
      messages: [],
      loadEarlier: true,
      typing: '',
      isLoadingEarlier: true,
      isOnlineUser: false,
      isUserTypingSomthing: false,
      media: {},
    };
    this.isMounted = true;
    this.isHistoryMessageLoad = false;
  }

  componentWillMount() {
    //if (this.props.chatUserItem !== null) {
    this.props.setChatConversationAction(this.props.chatId);
  }

  componentDidMount() {
    AppState.addEventListener('change', this.handleAppStateChange);
  }

  // shouldComponentUpdate(nextProps, nextState) {
  //   return this.props !== nextProps;
  // }

  componentWillUnmount() {
    /// remove Chat User Status Check
    this.props.removeConversationListner(this.props.chatId);
    this.props.setClientChatUser('');
    this.props.removeChatHistoryData();
    AppState.removeEventListener('change', this.handleAppStateChange);
    if (this.props.callbackFunction !== null) {
      this.props.callbackFunction();
      }
  }

  // onViewableItemsChanged = ({ viewableItems, changed }) => {
  //   console.log("Visible items are", viewableItems);
  //   console.log("Changed in this iteration", changed);
  // }
  
  onOptionMenuClick = () => {


    };

  onAttachmentPress = () => {
    this.selectPhotoTapped();
  }

  onUserTypeObserver = (text) => {
    this.setState({ typing: text });
    if (!this.state.isUserTypingSomthing) {
      this.setState({ isUserTypingSomthing: true });
      this.props.sendTypingStatus(this.props.chatId);
      setTimeout(() => {
        this.setState({ isUserTypingSomthing: false });
        }, 400);
    } else {
      // do something here
    }
  };

  onGoBack = () => {
    Actions.pop();
  }

  handleAppStateChange = (nextAppState) => {
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      this.props.setChatConversationAction(this.props.chatId);
    }
    this.setState({ appState: nextAppState });
  }

  selectPhotoTapped() {
    const options = {
      quality: 1.0,
      maxWidth: 500,
      maxHeight: 500,
      takePhotoButtonTitle: KEY_TAKE_PHOTO,
      chooseFromLibraryButtonTitle: 'Choose Photo from library',
      storageOptions: {
        skipBackup: true
      },
      customButtons: [
        { name: 'video_library', title: 'Choose Video from library' },
    ]
    };

    const optionsVideo = {
      storageOptions: {
          skipBackup: true,
      },
      noData: true,
      mediaType: 'video'
  };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled photo picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton === 'video_library') {
        ImagePicker.launchImageLibrary(optionsVideo, (responseVideolibrary) => {
          if (responseVideolibrary !== null) {
          this.videoResponseHandler(responseVideolibrary);
          }
      });
      } else {
        //console.log('onAttached File Uri==' + response.uri);
        //const source = { uri: response.uri };
        this.setState({
          media: {
              chatId: this.props.chatId,
              fileName: response.fileName,
              filePath: response.path,
              fileData: response.data,
              timestamp: response.timestamp,
              fileSize: response.fileSize,
              fileUri: response.uri,
              filetype: response.type,
              fileHeight: response.height,
              fileWidth: response.width,
          }
      });
      const fileObj = {
        FileName: response.uri,
        Caption: ''
      };

      const newMsg = {
        SocketId: '',
        MessageId: (Math.floor(Math.random() * 11)) * (Math.floor(Math.random() * 9) - 10),
        DisplayName: '',
        Name: '',
        Image: '',
        DisplayImage: '',
        TypeId: 2,
        Message: JSON.stringify(fileObj),
        Status: 0,
        SendOn: moment.utc(),
        mguid: ''
      };

      this.props.addNewMediaMsg(newMsg);

      const ext = this.state.media.fileName.split('.');
      this.forceUpdate();
      Transloadit.submitAssembly(Config.TRANSLOADIT_API_KEY, Config.TRANSLOADIT_SECRET_KEY,
        response.uri, response.fileName,
        `.${ext[1]}`, Transloadit.KEY_CHAT_MEDIA, Config.TEMPLATE_ID_IMAGE,
        (error, responseAssembly) => {
          if (responseAssembly !== null) {
            const assemblyResponse = JSON.parse(responseAssembly);
            if (assemblyResponse.http_code === 200) {
              //console.log('Call Back From Transloadit==200');
              this.forceUpdate();
              this.props.actionSendMediaMsg(newMsg, this.state.media);
            } else {
                showToast(assemblyResponse.message);
            }
        } else {
          showToast(error);
        }
      });
      }
    });
  }

  videoResponseHandler = (responseVideolibrary) => {
    const source = { uri: responseVideolibrary.uri };
    this.setState({ IsHasMedia: true });
    const lengthIndex = responseVideolibrary.path.length;
    const lastIndexOf = responseVideolibrary.path.lastIndexOf('/');
    const FileNameFromIndex = responseVideolibrary.path.substring(lastIndexOf + 1, lengthIndex);        
    this.setState({
      media: {
          chatId: this.props.chatId,
          fileName: FileNameFromIndex,
          filePath: responseVideolibrary.path,
          fileData: responseVideolibrary.data,
          timestamp: responseVideolibrary.timestamp,
          fileSize: responseVideolibrary.fileSize,
          fileUri: responseVideolibrary.uri,
          filetype: 'video',
          fileHeight: responseVideolibrary.height,
          fileWidth: responseVideolibrary.width,
      }
  });
  const fileObj = {
    FileName: responseVideolibrary.uri,
    Caption: ''
  };

  const newMsg = {
    SocketId: '',
    MessageId: (Math.floor(Math.random() * 11)) * (Math.floor(Math.random() * 9) - 10),
    DisplayName: '',
    Name: '',
    Image: '',
    DisplayImage: '',
    TypeId: 3,
    Message: JSON.stringify(fileObj),
    Status: 0,
    SendOn: moment.utc(),
    mguid: ''
  };

  this.props.addNewMediaMsg(newMsg);

  const ext = this.state.media.fileName.split('.');
  this.forceUpdate();
  Transloadit.submitAssembly(Config.TRANSLOADIT_API_KEY, Config.TRANSLOADIT_SECRET_KEY,
    responseVideolibrary.uri, FileNameFromIndex,
    `.${ext[1]}`, Transloadit.KEY_CHAT_MEDIA, Config.TEMPLATE_ID_VIDEO,
    (error, responseAssembly) => {
      if (responseAssembly !== null) {
        const assemblyResponse = JSON.parse(responseAssembly);
        if (assemblyResponse.http_code === 200) {
          //console.log('Call Back From Transloadit==200');
          this.forceUpdate();
          this.props.actionSendMediaMsg(newMsg, this.state.media);
        } else {
            showToast(assemblyResponse.message);
        }
    } else {
      showToast(error);
    }
  });
    // const source = { uri: responseVideolibrary.uri };
    // this.setState({ IsHasMedia: true });
    // const lengthIndex = responseVideolibrary.path.length;
    // const lastIndexOf = responseVideolibrary.path.lastIndexOf('/');
    // const FileNameFromIndex = responseVideolibrary.path.substring(lastIndexOf + 1, lengthIndex);        
  
    // this.setState({
    //     media: {
    //         templateId: Config.TEMPLATE_ID_VIDEO,
    //         fileName: FileNameFromIndex,
    //         filePath: responseVideolibrary.path,
    //         fileData: responseVideolibrary.data,
    //         timestamp: responseVideolibrary.timestamp,
    //         fileSize: responseVideolibrary.fileSize,
    //         fileUri: responseVideolibrary.uri,
    //         filetype: 'video',
    //         fileHeight: responseVideolibrary.height,
    //         fileWidth: responseVideolibrary.width
    //     }
    // });
    // this.setState({
    //   ImageSource: source
    // });
}

  newFileUploader(base64String, newMsg, mediaType) {
    const media = this.state.media;
    this.props.mediaMsgUpload(media, base64String, newMsg, mediaType);
  }

// getBase64(file) {
//   return new Promise((resolve, reject) => {
//     const reader = new FileReader();
//     reader.readAsDataURL(file);
//     reader.onload = () => resolve(reader.result);
//     reader.onerror = error => reject(error);
//   });
// }

actionAttachFile = async() => {
    // iPhone/Android
    DocumentPicker.show({
      filetype: [DocumentPickerUtil.pdf()],
    },(error,response) => {
      //console.log('file Picker ' + JSON.stringify(response));
      if (response !== null) {
      this.setState({
        media: {
            chatId: this.props.chatId,
            fileName: response.fileName,
            filePath: '',
            fileData: '',
            timestamp: '',
            fileSize: response.fileSize,
            fileUri: response.uri,
            filetype: response.type,
            fileHeight: 0,
            fileWidth: 0,
        }
    });
    const fileObj = {
      FileName: response.uri,
      Caption: ''
    };
    const newMsg = {
      SocketId: '',
      MessageId: (Math.floor(Math.random() * 11)) * (Math.floor(Math.random() * 9) - 10),
      DisplayName: '',
      Name: '',
      Image: '',
      DisplayImage: '',
      TypeId: 4,
      Message: JSON.stringify(fileObj),
      Status: 0,
      SendOn: moment.utc(),
      mguid: ''
    };
    //console.log('file Picker  new msg= ' + JSON.stringify(newMsg));
    this.props.addNewMediaMsg(newMsg);
    const ext = this.state.media.fileName.split('.');
      this.forceUpdate();
      Transloadit.submitAssembly(Config.TRANSLOADIT_API_KEY, Config.TRANSLOADIT_SECRET_KEY,
        response.uri, response.fileName,
        `.${ext[1]}`, Transloadit.KEY_CHAT_MEDIA, Config.TEMPLATE_ID_PDF,
        (errorAssembly, responseAssembly) => {
          if (responseAssembly !== null) {
            const assemblyResponse = JSON.parse(responseAssembly);
            console.log('Call Back From Transloadit==' + JSON.stringify(assemblyResponse));
            if (assemblyResponse.http_code === 200) {
              this.forceUpdate();
              this.props.actionSendMediaMsg(newMsg, this.state.media);
            } else {
                showToast(assemblyResponse.message);
            }
        } else {
          showToast(errorAssembly);
        }
      });
    // RNFS.readFile(response.uri, 'base64').then((data) => {
    //   this.forceUpdate();
    //   if (data != null) {
    //   this.newFileUploader(data, newMsg, MEDIA_TYPE_PDF);
    //   } else {
    //     showToast('File Not Upload!!!');
    //   }
    // });
    }
    });
  };


    sendMessage = async () => {
      const lengthVariable = this.state.typing.replace(/\s+/, '');
      if (this.state.typing != null && this.state.typing !== '' && lengthVariable.length > 0) {
        const data = {
          TypeId: 1,
          Message: this.state.typing,
          from: 'mobile'
        };
        this.props.sendMsgAction(data, this.props.chatId);
        this.setState({ typing: '' });
      }
      // read message from component state
    };

  renderAttachIcon() {
    return (
      <TouchableOpacity 
        style={{ justifyContent: 'center', alignContent: 'center', padding: 5 }}
        onPress={this.actionAttachFile.bind(this)}
      >
        <Image 
          source={require('./../../images/ic_attach.png')}
        />
      </TouchableOpacity>
    );
  }

  renderSendMessageIcon() {
    return (
      <TouchableOpacity 
        style={{ justifyContent: 'center', alignContent: 'center', padding: 5 }}
        onPress={this.sendMessage.bind(this)}
      >
        <Image 
          source={require('./../../images/sendEnabled.png')}
        />
        </TouchableOpacity>
    );
  }

  renderFooter() {
    return (
      <KeyboardAvoidingView>
      <Animated.View style={styles.footer}>
      <TouchableOpacity
      style={{ justifyContent: 'center', alignContent: 'center', padding: 5 }}
      onPress={this.onAttachmentPress.bind(this)}
      >
        <Image 
          source={require('./../../images/camerachat.png')}
        />
      </TouchableOpacity>
        <TextInput
          value={this.state.typing}
          style={styles.input}
          underlineColorAndroid="transparent"
          placeholder="Type something nice"
          onChangeText={(text) => {
            this.onUserTypeObserver(text);
            }}
        />
        {/* {this.renderSendMessageIcon()} */}
        {this.state.typing.length > 0 ? this.renderSendMessageIcon() : this.renderAttachIcon()}
      </Animated.View>
    </KeyboardAvoidingView>
    );
  }

  renderItem({ item }) {
    return (
      <View style={styles.row}>
        <Image style={styles.avatar} source={{ uri: item.avatar }} />
        <View style={styles.rowText}>
          <Text style={styles.sender}>{item.sender}</Text>
          <Text style={styles.message}>{item.message}</Text>
        </View>
      </View>
    );
  }

  renderRow = (message, index) => {
    const Pmessage = this.props.userMessageHistory[index - 1];  //[(this.props.userMessageHistory.length - (index + 1)) - 1];
    const Nmessage = this.props.userMessageHistory[index + 1];  //[(this.props.userMessageHistory.length - (index + 1)) + 1];

    const messageProps = {
        key: message.MessageId,
        currentMessage: message,
        previousMessage: Pmessage,
        nextMessage: Nmessage,
        selfId: this.props.clientReceiverDetail.SocketId,
        position: message.SocketId === this.props.clientReceiverDetail.SocketId ? 'left' : 'right',
    };
    return ( 
    <Message messageProps={messageProps} />
    );
}

  render() {
    return (
      <View
      style={{ flex: 1, width: '100%', height: '100%' }}
      >
      <View 
      style={{ height: 56, width: '100%', backgroundColor: 'white', elevation: 4 }}
      >
      <ChatHead 
      title={this.props.clientReceiverDetail.Name}
      rightButton=''
      onRightButtonClick={this.onOptionMenuClick.bind(this)}
      userItem={this.props.clientReceiverDetail}
      onGoBack={this.onGoBack.bind()}
      userState={this.props.clientReceiverDetail}
      userIsTyping={this.props.userIsTyping}
      clientUserOnline={this.props.clientUserOnline}
      />
      </View>
      <View style={styles.container}>

      <VirtualizedList
        ref={(ref) => this.flatList = ref}
        inverted
        data={this.props.userMessageHistory}
        getItem={(data, index) => data[index]}
        getItemCount={data => data.length}
        extraData={this.props}
        keyExtractor={(item, index) => index.toString()}
        onScroll={(e) => {
          const paddingToTop = 5;
          if (e.nativeEvent.contentSize.height <= e.nativeEvent.contentOffset.y + paddingToTop + e.nativeEvent.layoutMeasurement.height) {
              //if (!this.isHistoryMessageLoad) {
                    const lengthOFLastArray = this.props.userMessageHistory.length;
                    this.props.getUserOldMessageHistory(this.props.chatId, this.props.userMessageHistory[lengthOFLastArray - 1]);
                    //this.isHistoryMessageLoad = true;
                   // setTimeout(() => {
                     // this.isHistoryMessageLoad = false;
                   // }, 50);
            //  }
          }
        }}
        renderItem={({ item, index }) => (
               this.renderRow(item, index)  
              )}
      />
      {this.renderFooter()}
      </View>
      </View>
    );
  }
}

const mapDispatchToProps = {
  addNewMediaMsg,
  setClientMessageHistory,
  setClientChatUser,
  setChatConversationAction,
  sendMsgAction,
  removeConversationListner,
  sendTypingStatus,
  mediaMsgUpload,
  actionSendMediaMsg,
  removeChatHistoryData,
  getUserOldMessageHistory,
};

const mapStateToProps = (state) => {
  //console.log('chatWindow === ' + JSON.stringify(state));
  return (
    {
      clientReceiverDetail: state.socket.clientReceiverDetail,
      userIsTyping: state.socket.userIsTyping,
      clientUserOnline: state.socket.clientUserOnline,
      userMessageHistory: state.socket.userMessageHistory,
      isLoadMoreMessageHistory: state.socket.isLoadMoreMessageHistory,
    }
  );
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatWindowContainer);
