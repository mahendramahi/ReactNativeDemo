import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from './Styles';

const ChatWindowComponent = (props) => {
  return (
    <View></View>
  );
};


export default ChatWindowComponent;
