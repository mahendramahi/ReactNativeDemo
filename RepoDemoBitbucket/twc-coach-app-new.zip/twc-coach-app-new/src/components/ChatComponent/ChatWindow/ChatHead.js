import React from 'react';
import { TouchableOpacity, Image, Text, View } from 'react-native';
import UserAvatar from './../../../ThirdParty/UserAvatar';

const isEmpty = (obj) => {
  return (Object.getOwnPropertyNames(obj).length === 0);
};

const renderStatus = (props) => {
   if (!isEmpty(props.userIsTyping)) {
    return (
      <Text
        style={styles.belowtext}
      >
      {props.userIsTyping.text}
      </Text>
    );
  } else if (!isEmpty(props.clientUserOnline)) {
     if (props.clientUserOnline.IsOnline) {
      return (
        <Text 
        style={styles.belowtext}
        >
        online
        </Text>
        );
      } else {
        return null;
      }
  } else if (props.userState.IsOnline) {
  return (
        <Text 
        style={styles.belowtext}
        >
        online
        </Text>
   );
  } else {
    return null;
  }
};

const renderUserImage = (userItem) => {
  if (!isEmpty(userItem)) {
  return (
      <UserAvatar 
        name={userItem.Name} 
        src={userItem.Image} 
        size={40} 
      />
  );
  }
};

const ChatHead = (props) => {
    return (
        <View style={styles.main}>
        <TouchableOpacity 
        style={styles.imageContainer}
        activeOpacity={0.8}
        onPress={() => props.onGoBack()}
        >
        <Image 
        source={require('./../../../components/images/backIcon.png')} 
        />
        </TouchableOpacity>
        <View 
        style={styles.titleContainer} 
        >
        <Text 
        style={styles.titleText}
        >
        { props.title }
        </Text>
        {
        renderStatus(props)
        }
       
        </View>
        <View 
        style={{ justifyContent: 'flex-end' }} 
        >
        {renderUserImage(props.userItem)}
        </View>
        </View>
    );
};

const styles = {
main: {
    flex: 1,
    marginLeft: 10,
    marginRight: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center' 
  },
  imageContainer: {
    width: 10,
    height: 10,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center' 
  },
  titleContainer: {
    flex: 1,
    marginStart: 5,
    justifyContent: 'center',
    alignSelf: 'center'
  },
  titleText: {
    fontSize: 18,
    fontWeight: '800',
    fontStyle: 'normal',
    marginLeft: 10,
    justifyContent: 'center',
    color: '#313131'
  },
  belowtext: {
    fontSize: 9,
    fontStyle: 'normal',
    marginLeft: 10,
    justifyContent: 'center',
  },
  rightButton: {
    fontSize: 14,
    justifyContent: 'center',
    alignItems: 'center',
    color: '#22a1a1',
  }
};

export default ChatHead;
