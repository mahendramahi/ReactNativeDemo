import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { CardSection } from './common';

const LinkPreviewCard = ({ media, onPreViewCross, isPostView, onPress }) => {
    let mediaUrl = '';
    try {
        mediaUrl = media.images[0];
    } catch (error) {
        mediaUrl = '';
    }

    if (isPostView) {
        return (
            <TouchableOpacity
            style={styles.card}
            onPress={onPress}
            >
            <View style={styles.cardSection}>
                <View style={styles.imageroundx}>
                    <Image
                        style={styles.Postimg}
                        source={{ uri: mediaUrl }}
                    />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename}>{media.title}</Text>
                    <Text style={styles.circlepost}>{media.url}</Text>
                    {media.description === 'null' ?
                    null
                    :
                    <Text style={styles.circlepost}>{media.description}</Text>
                    }
                </View>
            </View>
        </TouchableOpacity>
        );
    } else {
        return (
            <View style={styles.card}>
            <CardSection>
                <View style={styles.imageroundx}>
                    <Image 
                        style={styles.circleimg} 
                        source={{ uri: mediaUrl }}
                    />
                </View>
                <View style={styles.circlecontent}>
                    <Text style={styles.circlename} numberOfLines={1} >{media.title}</Text>
                    <Text style={styles.circlepost} numberOfLines={1} >{media.url}</Text>
                    <Text style={styles.circlepostDescription} numberOfLines={1} >{media.description}</Text>
                </View>
                <TouchableOpacity 
                style={styles.arrowright}
                activeOpacity={0.1}
                onPress={() => onPreViewCross()}
                >
                <Image
                    style={styles.arrowright}
                    source={require('./images/ic_cross_black.png')}
                />
                </TouchableOpacity>
            </CardSection>
        </View>
        ); 
    }
};

const styles = {
    cardSection: {
    borderBottomWidth: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
        flexDirection: 'column',
        borderColor: '#ddd',
        position: 'relative'
    },
    card: {
        borderWidth: 1,
        borderRadius: 5,
        borderColor: '#fff',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 2,
        elevation: 1,
    },
imageroundx: {
    padding: 0,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    justifyContent: 'flex-start',
    alignItems: 'center',
    alignContent: 'center',
    marginLeft: 2,
    marginTop: 1,
    marginRight: 2
  },
  circlecontent: {
    marginLeft: 20
  },
Postimg: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    alignContent: 'center', 
    width: '100%',
    height: 140,
    borderRadius: 1
},
circleimg: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    alignContent: 'center', 
    width: 60,
    height: 40,
    borderRadius: 1
},
circlename: {
    fontSize: 15,
    color: '#000',
    fontWeight: 'normal',
    padding: 1
},
circlepost: {
    fontSize: 11,
    padding: 0
},
circlepostDescription: {
    fontSize: 9,
    padding: 0,
},
arrowright: {
    marginLeft: 'auto',
    width: 10,
    height: 10,
    padding: 2 
},
};

export default LinkPreviewCard;
