import React, { Component } from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, Platform } from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import PTRView from 'react-native-pull-to-refresh';
import { connect } from 'react-redux';
import { getNotificatios, clearNotification,
  actionPerformAfterClickItem,
  getPostDetailsById } from './../actions/';
import NotificationRow from './NotificationRow';
import NoDataView from './common/NoDataView';

class Notification extends Component {

    constructor(param) {
        super(param);
        this.state = {
          pageNoNotification: 1,
          pageSize: 20,
          loadMore: true,
          onRefresh: false,
          cards: [1, 2, 3]
        };
        this._refresh = this._refresh.bind(this);
      }

    componentWillMount() {
    }

    componentDidMount() {
     this.getNotifications(this.state.pageNoNotification);
    }

    getNotifications(pageNo) {
      this.forceUpdate();
      this.props.getNotificatios(pageNo, this.state.pageSize);
      this.setState({ pageNoNotification: (this.state.pageNoNotification + 1) });
      this.setState({ loadMore: true, onRefresh: false });
      this.forceUpdate();
    }

    shouldComponentUpdate(nextProps, nextState) {
      return this.props !== nextProps;
    }

    _ItemLoadMore = () => {
      this.getNotifications();
    };

    _refresh () {
      this.props.clearNotification();
      this.setState({ pageNoNotification: 1 });
      this.setState({ onRefresh: true });
        return new Promise((resolve) => {
            this.getNotifications(1);
            resolve(); 
        });
    }

  emptyList = () => {
      return (
          <NoDataView />
      );
  };
  

    onListItemClick(notificationItem) {
      if (!notificationItem.isRead) {
       this.props.actionPerformAfterClickItem(notificationItem);
      }
      this.props.getPostDetailsById(notificationItem);
       //Actions.postDetail({ postData: null, notificationData: notificationItem, callbackFunction: null });
    }

  render() {
    return (
      <View style={{ flex: 1 }}>
            <PTRView
              style={{ backgroundColor: '#F5FCFF' }}
              onRefresh={this._refresh}
            >
              <View style={{ flex: 1, justifyContent: 'center', position: 'relative' }}>
            {/* <ScrollView 
            style={styles.mainContainer}
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}
            onScroll={(e) => {
                let paddingToBottom = 1;
                paddingToBottom += e.nativeEvent.layoutMeasurement.height;
                console.log('notification = ' + paddingToBottom);
                if (e.nativeEvent.contentOffset.y >= e.nativeEvent.contentSize.height - paddingToBottom) {
                 //this.onGetFeedAgain();
                 console.log('notification = call');
                 //this.getNotifications();
                }
              }}
            > */}
              <Spinner
                visible={this.props.isLoading}
                textContent={''}
                textStyle={{ color: '#fff' }} 
              />
              <FlatList
                data={this.props.notificationList}
                extraData={this.props}
                ListEmptyComponent={this.emptyList.bind(this)}
                renderItem={({ item }) => (
                  <NotificationRow 
                  key={item.identity}
                  notificationItem={item}
                  onItemClick={this.onListItemClick.bind(this)}
                  />
                  )}
                onEndReachedThreshold={2}
                onEndReached={({ distanceFromEnd }) => {
                  if (this.state.loadMore && !this.state.onRefresh) {
                    this.setState({ loadMore: false });
                  this._ItemLoadMore();
                  }
                  }}
                keyExtractor={(item, index) => index.toString()}
                />   
            {/* </ScrollView> */}
            </View>
            </PTRView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    paddingTop: (Platform.OS === 'ios') ? 20 : 0,
    },
    container: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor: '#F5FCFF',
    },
    welcome: {
      fontSize: 20,
      textAlign: 'center',
      margin: 10,
    },
    instructions: {
      textAlign: 'center',
      color: '#333333',
      marginBottom: 5,
    },
    header: {
      height: 60,
      borderColor: '#f9f9f9',
      backgroundColor: '#2196F3',
      borderBottomWidth: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    headerText: {
      color: '#fff',
      fontSize: 20,
      lineHeight: 40,
    },
    card: {
      flex: 1,
      borderColor: '#fafafa',
      backgroundColor: '#2196F3',
      borderWidth: 2,
      borderRadius: 3,
      margin: 5,
    },
    card__text: {
      color: '#fafafa',
      fontSize: 20,
      textAlign: 'center',
      margin: 10,
    }
  });

  const mapDispatchToProps = {
    getNotificatios,
    clearNotification,
    actionPerformAfterClickItem,
    getPostDetailsById,
  };

  const mapStateToProps = (state) => {
    return (
      {
        isLoading: state.notification.isLoading,
        notificationList: state.notification.notificationList
      }
    );
  };


  export default connect(mapStateToProps, mapDispatchToProps)(Notification);
