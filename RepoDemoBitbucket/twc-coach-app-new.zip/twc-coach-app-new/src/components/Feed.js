import React, { Component } from 'react';
import { VirtualizedList, FlatList, ActivityIndicator, View } from 'react-native';
import { connect } from 'react-redux';
import Post from './Post';
import NoDataView from './common/NoDataView';
import { Actions } from 'react-native-router-flux';

//const { height: windowHeight } = Dimensions.get('window');
//const boxHeight = windowHeight / 3;
class Feed extends Component {

    constructor(props) {
        super(props);
    }
   
  isEmpty = (obj) => {
    if (Object.getOwnPropertyNames(obj).length === 0) {
      return true;
    } else if ((Object.getOwnPropertyNames(obj).length) % 10 === 0) {
      return false;
    } else {
      return true;
    }
  //return (Object.getOwnPropertyNames(obj).length === 0);
  };

  shouldComponentUpdate(nextProps, nextState) {
      return this.props !== nextProps;
  }

  renderFooter = () => {
     // if (!this.isEmpty(this.props.feeds)) {
      if (this.props.feeds !== null && this.props.feeds.length > 9) {
         return (
           <View
             style={{
               paddingVertical: 20,
               borderTopWidth: 1,
               borderColor: '#CED0CE'
             }}
           >
             <ActivityIndicator animating size="large" />
           </View>
         );
            } else {
             return null;
           }
     };
     
    renderSeparator = () => {
        return (
            <View
            style={{
                height: 1,
                width: '86%',
                backgroundColor: '#CED0CE',
                marginLeft: '14%',
            }}

            />
        );
    };

      emptyView = () => {
        if (Actions.currentScene === 'home') {
          return null;
        } else {
        return (
          <NoDataView />
        );
        }
      }  

    render() {
        return (
            <VirtualizedList
            data={this.props.feeds}
            renderItem={({ item, index }) => (
                    <Post
                    key={`postindex${index}`}
                    onRef={ref => (this.child = ref)}
                    post={item}
                    position={index}
                    // center={true}
                    />
            )}
            getItem={(data, index) => data[index]}
            getItemCount={data => data.length}
            extraData={this.props}
            keyExtractor={(item, index) => index.toString()}
           // ItemSeparatorComponent={this.renderSeparator}
            ListFooterComponent={this.renderFooter}
            ListEmptyComponent={this.emptyView()}
            />
        );
    }
}

const mapDispatchToProps = {
};

const mapStateToProps = (state) => {
    return (
        {
            feedList: state.feeds.feeds,
        }
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Feed);
