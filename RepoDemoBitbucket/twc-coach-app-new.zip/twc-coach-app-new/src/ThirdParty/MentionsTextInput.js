import React from 'react';
import {
  Text,
  View,
  Animated,
  TextInput,
  FlatList,
  ViewPropTypes, TouchableHighlight
} from 'react-native';
import PropTypes from 'prop-types';

export default class MentionsTextInput extends React.Component {
  constructor() {
    super();
    this.state = {
      textInputHeight: '',
      isTrackingStarted: false,
      suggestionRowHeight: new Animated.Value(0),

    };
    this.isTrackingStarted = false;
    this.previousChar = ' ';
    this.isTrackfor = ''; 
  }

  componentWillMount() {
    this.setState({
      textInputHeight: this.props.textInputMinHeight
    });
  }

  componentWillReceiveProps(nextProps) {
    if (!nextProps.value) {
      this.resetTextbox();
    } else if (this.isTrackingStarted && !nextProps.horizontal && nextProps.suggestionsData != null && nextProps.suggestionsData.length !== 0) {
      const numOfRows = nextProps.MaxVisibleRowCount >= nextProps.suggestionsData.length ? nextProps.suggestionsData.length : nextProps.MaxVisibleRowCount;
      const height = numOfRows * nextProps.suggestionRowHeight;
     // this.openSuggestionsPanel(height);
    }
  }

  startTracking() {
    this.isTrackingStarted = true;
    //this.openSuggestionsPanel();
    this.setState({
      isTrackingStarted: true,
    });
  }

  stopTracking() {
    this.isTrackingStarted = false;
    //this.closeSuggestionsPanel();
    this.setState({
      isTrackingStarted: false
    });
  }

  openSuggestionsPanel(height) {
    Animated.timing(this.state.suggestionRowHeight, {
      toValue: height ? height : this.props.suggestionRowHeight,
    }).start();
  }

  closeSuggestionsPanel() {
    Animated.timing(this.state.suggestionRowHeight, {
      toValue: 0
    }).start();
  }

  updateSuggestions(lastKeyword) {
    this.props.triggerCallback(lastKeyword);
  }

  identifyKeyword(val) {
    if (this.isTrackingStarted) {
      const boundary = this.props.triggerLocation === 'new-word-only' ? 'B' : '';
      const pattern1 = new RegExp(`\\${boundary}#[a-z0-9_-]+|\\${boundary}#`, `gi`);
     // const pattern2 = new RegExp(`\\${boundary}@[a-z0-9_-]+|\\${boundary}@`, `gi`);
     const keywordArray = val.match(pattern1);// ? val.match(pattern1) : val.match(pattern2);
     //console.log('keywordArray1 == ' + JSON.stringify(keywordArray));
     if (keywordArray && !!keywordArray.length) {
       const lastKeyword = keywordArray[keywordArray.length - 1];
       //console.log('lastKeyword1 == ' + JSON.stringify(lastKeyword));
       this.updateSuggestions(lastKeyword);
     }
    }
  }

  identifyKeywordAt(val) {
    if (this.isTrackingStarted) {
      const boundary = this.props.triggerLocation === 'new-word-only' ? 'B' : '';
      //const pattern1 = new RegExp(`\\${boundary}#[a-z0-9_-]+|\\${boundary}#`, `gi`);
      const pattern2 = new RegExp(`\\${boundary}@[a-z0-9_-]+|\\${boundary}@`, `gi`);
     const keywordArray1 = val.match(pattern2);
     //console.log('keywordArray2 == ' + JSON.stringify(keywordArray1));
     if (keywordArray1 && !!keywordArray1.length) {
       const lastKeyword = keywordArray1[keywordArray1.length - 1];
       //console.log('lastKeyword2 == ' + JSON.stringify(lastKeyword));
       this.updateSuggestions(lastKeyword);
     }
    }
  }

  onChangeText(val) {
    this.props.onChangeText(val); // pass changed text back
    //console.log('onChangeText == ' + val);
    const lastChar = val.substr(val.length - 1);
    const wordBoundry = (this.props.triggerLocation === 'new-word-only') ? this.previousChar.trim().length === 0 : true;
    //if (this.state.isTrackingStarted) {
      //this.key = this.key + lastChar;
   // }
    if (((lastChar === '#') || (lastChar === '@')) && wordBoundry) {
      if (lastChar === '#') {
        this.isTrackfor = '#';
      } else if (lastChar === '@') {
        this.isTrackfor = '@';
      } else {
        this.isTrackfor = '';
      }
      this.startTracking();
    } else if (lastChar === ' ' || !this.state.isTrackingStarted || val === '') {
      this.isTrackfor = '';
      this.stopTracking();
    }
    this.previousChar = lastChar;
    //console.log('previousChar == ' + this.previousChar);
    if (this.isTrackfor === '#') {
    this.identifyKeyword(val);
    } else if (this.isTrackfor === '@') {
    this.identifyKeywordAt(val);
    }
  }


  resetTextbox() {
    this.previousChar = ' ';
    this.stopTracking();
    this.setState({ textInputHeight: this.props.textInputMinHeight });
  }
  shouldComponentUpdate(nextProps, nextState) {
    return this.props !== nextProps;
  }

  render() {
    return (
      <TouchableHighlight
      style={{ flex: 1 }}
      >
      <View>
        <TextInput
          {...this.props}
          onContentSizeChange={(event) => {
            this.setState({
              textInputHeight: this.props.textInputMinHeight >= event.nativeEvent.contentSize.height ? this.props.textInputMinHeight : event.nativeEvent.contentSize.height + 10,
            });
          }}
          ref={component => this._textInput = component}
          onChangeText={this.onChangeText.bind(this)}
          multiline={true}
          value={this.props.value}
          style={[{ ...this.props.textInputStyle }, { height: Math.min(this.props.textInputMaxHeight, this.state.textInputHeight) }]}
          placeholder={this.props.placeholder ? this.props.placeholder : 'Write a comment...'}
        />
        { this.state.isTrackingStarted  //this.props.suggestionsData != null && this.props.suggestionsData.length > 0 
        ? 
        <TouchableHighlight
        style={{ flex: 1 }}
        >
        <Animated.View
        style={[{ ...this.props.suggestionsPanelStyle }, { height: 96, flex: 1 }]}
        >
          <FlatList
            keyboardShouldPersistTaps={'always'}
            //horizontal={this.props.horizontal}
            ListEmptyComponent={this.props.loadingComponent}
            enableEmptySections={false}
            data={this.props.suggestionsData}
            extraData={this.props}
            keyExtractor={this.props.keyExtractor}
            renderItem={(rowData) => { 
              return this.props.renderSuggestionsRow(rowData, this.stopTracking.bind(this));
              }}
          />
        </Animated.View>
        </TouchableHighlight>
        : 
        null
        }
        </View>
      </TouchableHighlight>
    );
  }
}

MentionsTextInput.propTypes = {
  textInputStyle: TextInput.propTypes.style,
  suggestionsPanelStyle: ViewPropTypes.style,
  loadingComponent: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.element,
  ]),
  textInputMinHeight: PropTypes.number,
  textInputMaxHeight: PropTypes.number,
  //trigger: PropTypes.string.isRequired,
  triggerLocation: PropTypes.oneOf(['new-word-only', 'anywhere']).isRequired,
  value: PropTypes.string.isRequired,
  onChangeText: PropTypes.func.isRequired,
  //triggerCallback: PropTypes.func.isRequired,
  renderSuggestionsRow: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.element,
  ]).isRequired,
  //suggestionsData: PropTypes.array.isRequired,
  keyExtractor: PropTypes.func.isRequired,
  horizontal: PropTypes.bool,
  suggestionRowHeight: PropTypes.number.isRequired,
  MaxVisibleRowCount: function(props, propName, componentName) {
    if(!props.horizontal && !props.MaxVisibleRowCount) {
      return new Error(
        `Prop 'MaxVisibleRowCount' is required if horizontal is set to false.`
      );
    }
  }
};

MentionsTextInput.defaultProps = {
  textInputStyle: { borderColor: '#ebebeb', borderWidth: 1, fontSize: 15 },
  //suggestionsPanelStyle: { backgroundColor: 'rgba(100,100,100,0.1)' },
  //loadingComponent: () => <Text>Loading...</Text>,
  //textInputMinHeight: 30,
  //textInputMaxHeight: 80,
  //horizontal: true,
};
