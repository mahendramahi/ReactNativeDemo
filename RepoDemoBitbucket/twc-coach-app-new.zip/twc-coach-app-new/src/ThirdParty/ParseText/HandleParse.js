import React, { Component } from 'react';
import ParsedTextTWC from './ParseTestTWC';

class HandleParse extends Component {

    constructor(props) {
        super(props);
        this.state = {
            renderText: '',
        }
    }

    componentDidMount() {

    }

    render() {
        const { argStyle, hashTagOnPress, atTheRateOnPress, id } = this.props;
        return (
            <ParsedTextTWC
            key={`${id}${this.state.renderText}`}
            style={argStyle}
            parse={
            [
            { type: 'hashTag', style: { color: '#45c4ba', fontWeight: 'bold', textDecorationLine: 'underline' }, onPress: (hashTag) => hashTagOnPress(hashTag) },
            { type: 'atTheRate', style: { color: '#45c4ba', fontWeight: 'bold' }, onPress: (atTheRate) => atTheRateOnPress(atTheRate) },
            ]
            }
            childrenProps={{ allowFontScaling: false }}
            >
            {this.state.renderText}
            </ParsedTextTWC>
        );
    }
}

export default HandleParse;
