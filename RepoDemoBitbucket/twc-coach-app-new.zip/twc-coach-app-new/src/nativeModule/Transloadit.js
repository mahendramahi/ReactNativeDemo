/**
 * This exposes the native TransloaditExample module as a JS module. This has a
 * function 'craeteAssembly' which takes the following parameters:
 * Not Defined yet 
 */
import { NativeModules } from 'react-native';

module.exports = NativeModules.Transloadit;
