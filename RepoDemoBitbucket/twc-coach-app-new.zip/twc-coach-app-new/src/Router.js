// import { createStackNavigator } from 'react-navigation';

// export const LoginNavigator = createStackNavigator({
//     Login: { screen: LoginForm }
// });

// export const HomeNavigator = createStackNavigator({
//     Home: { screen: Home }
// });

import React from 'react';
import { View, Image } from 'react-native';
import { Scene, Router, ActionConst, Actions } from 'react-native-router-flux';
import LoginForm from './components/LoginForm';
import Home from './components/Home';
import More from './components/More';
import NotificationScreen from './components/Notification';
import CreatePost from './components/CreatePost';
import SelectCircles from './components/SelectCircles';
import BeforeAfter from './components/BeforeAfter';
import SplashScreen from './components/SplashScreen';
import PostDetail from './components/PostDetail'; 
import CircleBase from './components/TWCCircle';
import HashTagsBase from './components/TWCHashTags';
import ChatList from './components/ChatComponent/ChatList';
import ChatWindow from './components/ChatComponent/ChatWindow';
import ImageDetail from './components/ChatComponent/ChatWindow/ChatHelper/ImageDetail';
import WebViewHelper from './components/ChatComponent/ChatWindow/ChatHelper/WebViewHelper';
import VideoPlayerHelper from './components/ChatComponent/ChatWindow/ChatHelper/VideoPlayerHelper';
import HifiMemberList from './components/HifiMemberList';

const TabIcon = ({ focused, title }) => {
    return (
        <View style={{ justifyContent: 'flex-end', alignSelf: 'center' }}>
        {this.showNavigationIcon(focused, title)}
        </View>
    );
};

showNavigationIcon = (focused, title) => {
    switch (title) {
        case 'Home':
        if (focused) {
            return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Image
            style={{ justifyContent: 'center' }} 
            source={require('./components/images/circlesActive.png')}
            />
            </View>
            <View
            style={{ marginEnd: 1, marginStart: 1, alignSelf: 'flex-end', backgroundColor: '#26C5C6', height: 2, width: 60 }}
            />
            </View>
            );
        } else {
            return (
                <Image source={require('./components/images/circlesInactive.png')} />
                ); 
        }
        
        case 'More':
        if (focused) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Image
                style={{ justifyContent: 'center' }} 
                source={require('./components/images/moreActive.png')}
                />
                </View>
                <View
                style={{ marginEnd: 1, marginStart: 1, alignSelf: 'flex-end', backgroundColor: '#26C5C6', height: 2, width: 60 }}
                />
                </View>
            );
        } else {
            return (
                <Image source={require('./components/images/moreInactive.png')} />
                ); 
        }

        case 'Notification':
        if (focused) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Image
                style={{ justifyContent: 'center' }} 
                source={require('./components/images/notificationsActive.png')}
                />
                </View>
                <View
                style={{ marginEnd: 1, marginStart: 1, alignSelf: 'flex-end', backgroundColor: '#26C5C6', height: 2, width: 60 }}
                />
                </View>
            );
        } else {
            return (
                <Image source={require('./components/images/notificationsNoneInactive.png')} />
                ); 
        }
        default:
        return (
            <Image source={require('./components/images/moreActive.png')} />
            );
    }
  };
 

const RouterComponent = () => {
    return (
        <Router>
            <Scene key="root" hideNavBar>
                <Scene key="auth">
                    <Scene 
                    key="login"
                    component={LoginForm}
                    title="Please Login" 
                    hideNavBar 
                    />
                </Scene>
                <Scene key="main" hideNavBar>
                    <Scene 
                        key="tabbar" 
                        tabs
                        tabBarStyle={{ backgroundColor: '#fff' }}
                        showLabel={false}
                    >
                        <Scene key='homeTab' title="Home" icon={TabIcon} initial >
                            <Scene 
                                key="home"
                                component={Home}
                                hideNavBar
                            />
                        </Scene>
                        <Scene key='notificationTab' title="Notification" icon={TabIcon}>
                            <Scene 
                                key="notification"
                                component={NotificationScreen}
                                title='Notifications'
                            />
                        </Scene>

                        <Scene key='moreTab' title="More" icon={TabIcon}>
                            <Scene 
                                key="more"
                                component={More}
                                title="More"
                            />
                        </Scene>
                    </Scene>
                </Scene>

                <Scene 
                key="createPost"
                component={CreatePost}
                title="Create Post"
                direction="vertical"
                hideNavBar
                />   
                <Scene 
                key="selectCircles"
                component={SelectCircles}
                title="Select Circles"
                hideNavBar
                /> 
                <Scene
                key='BeforeAfter'
                component={BeforeAfter}
                title='BeforeAfter'
                hideNavBar
                />
                <Scene
                key='postDetail'
                component={PostDetail}
                title='Post Detail'
                hideNavBar
                />
                <Scene
                key='circleBase'
                component={CircleBase}
                title='Twc Circle'
                hideNavBar
                />
                <Scene
                key='hashTagsBase'
                component={HashTagsBase}
                title='Twc Circle'
                hideNavBar
                />
                
                <Scene
                key='chatList'
                component={ChatList}
                // transitionConfig={() => ({
                //     screenInterpolator: CardStackStyleInterpolator.forHorizontal
                // })}
                title='ChatList'
                hideNavBar
                />

                <Scene
                key='chatWindow'
                component={ChatWindow}
                // transitionConfig={() => ({
                //     screenInterpolator: CardStackStyleInterpolator.forHorizontal
                // })}
                title='ChatWindow'
                hideNavBar
                />

                <Scene
                key='imageDetail'
                component={ImageDetail}
                // transitionConfig={() => ({
                //     screenInterpolator: CardStackStyleInterpolator.forHorizontal
                // })}
                title='ImageDetail'
                hideNavBar
                />
                <Scene
                key='webViewHelper'
                component={WebViewHelper}
                // transitionConfig={() => ({
                //     screenInterpolator: CardStackStyleInterpolator.forHorizontal
                // })}
                title='WebViewHelper'
                hideNavBar
                />
                <Scene
                key='videoPlayerHelper'
                component={VideoPlayerHelper}
                // transitionConfig={() => ({
                //     screenInterpolator: CardStackStyleInterpolator.forHorizontal
                // })}
                title='VideoPlayerHelper'
                hideNavBar
                />

                <Scene
                key='hifiMemberList'
                component={HifiMemberList}
                initial
                hideNavBar
                />

                <Scene
                key='SplashScreen'
                component={SplashScreen}
                initial
                hideNavBar
                />

            </Scene>
        </Router>
    );
};

export default RouterComponent;
