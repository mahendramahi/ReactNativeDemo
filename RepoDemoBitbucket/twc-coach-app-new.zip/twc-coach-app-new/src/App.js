import React, { Component } from 'react';

import { Provider } from 'react-redux';
import Router from './Router';
import { store, firebaseRN } from './configureStore';
import { socketInit } from './actions';

//const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

class App extends Component {

    constructor(props) {
        super(props);
        socketInit();
    }
    componentWillMount() {
        //  AsyncStorage.getItem('token').then(data => {
        //      if (data !== null) Actions.main();
        // });
    }

    checkPermission = async() => {
      
      
     console.log('app==== ' + enabled);
      if (enabled) {
        this.getToken();
         } else {
             this.requestPermission();
         }
    }

      //2
      async requestPermission() {
       // console.log('app==== request permission called');
        try {
            await firebase.messaging().requestPermission();
            // User has authorised
           // this.getToken();
        } catch (error) {
            // User has rejected permissions
            //console.log('permission rejected');
        }
      }


    render() {
    //const store = store;
        
        return (
            <Provider store={store}>
              <Router />
            </Provider>
        );
    }
}

export default App;
